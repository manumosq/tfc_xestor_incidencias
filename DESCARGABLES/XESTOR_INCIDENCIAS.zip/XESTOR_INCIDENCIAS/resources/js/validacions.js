//VALIDACIÓN FORMULARIO REXISTRO CLIENTE

$(window).on("load", function () {
    $('#rexistrar_cliente').validate({
        rules: {
            nom_comercial: {
                required: true,
                maxlength: 50
            },
            nom_fiscal: {
                required: true,
                maxlength: 50
            },
            cif: {
                required: true,
                pattern: "[A-Z]{1}\\d{8}"
            },
            direccion: {
                required: true,
                maxlength: 50
            },
            cod_postal: {
                required: true,
                pattern: "\\d{5}"
            },
            localidade: {
                required: true,
                maxlength: 50
            },
            provincia_id: {
                min: 1,
            },
            telefono: {
                required: true,
                pattern: "\\d{9}"
            },
            email: {
                required: true,
                email: true
            }
        },

        messages: {
            nom_comercial: {
                required: "O Nome Comercial non pode estar baleiro",
                maxlength: "O máximo de caracteres permitido para este campo é 50"
            },
            nom_fiscal: {
                required: "O Nome Fiscal non pode estar baleiro",
                maxlength: "O máximo de caracteres permitido para este campo é 50"
            },
            cif: {
                required: "O campo CIF non pode estar baleiro",
                pattern: "O CIF debe seguir o formato establecido, unha letra seguida de 8 díxitos X00000000",
            },
            direccion: {
                required: "O campo Dirección non pode estar baleiro",
                maxlength: "O máximo de caracteres permitido para este campo é 50."
            },
            cod_postal: {
                required: "O campo Código Postal non pode estar baleiro",
                pattern: "O Código Postal ten que estar composto por 5 díxitos numéricos"
            },
            localidade: {
                required: "O campo Localidade non pode estar baleiro",
                maxlength: "O máximo de caracteres permitido para este campo é 50."
            },
            provincia_id: {
                min: "Escolla unha Provincia do listado",
            },
            telefono: {
                required: "O campo Teléfono non pode estar baleiro",
                pattern: "O teléfono debe estar composto por 9 díxitos"
            },
            email: {
                required: "Por favor, introduza un email correcto",
                email: "Por favor, introduza un email correcto"
            }
        }
    });

});

//VALIDACIÓN FORMULARIO MODIFICACIÓN CLIENTE

$(window).on("load", function () {
    var numero = $(".modificar_cliente").length;
    for (var i = 0; i < numero; i++) {
        $('#modificar_cliente' + i).validate({
            rules: {
                nom_comercial: {
                    required: true,
                    maxlength: 50
                },
                nom_fiscal: {
                    required: true,
                    maxlength: 50
                },
                cif: {
                    required: true,
                    pattern: "[A-Z]{1}\\d{8}"
                },
                direccion: {
                    required: true,
                    maxlength: 50
                },
                cod_postal: {
                    required: true,
                    pattern: "\\d{5}"
                },
                localidade: {
                    required: true,
                    maxlength: 50
                },
                provincia_id: {
                    min: 1,
                },
                telefono: {
                    required: true,
                    pattern: "\\d{9}"
                },
                email: {
                    required: true,
                    email: true
                }
            },

            messages: {
                nom_comercial: {
                    required: "O Nome Comercial non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitido para este campo é 50"
                },
                nom_fiscal: {
                    required: "O Nome Fiscal non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitido para este campo é 50"
                },
                cif: {
                    required: "O campo CIF non pode estar baleiro",
                    pattern: "O CIF debe seguir o formato establecido, unha letra seguida de 8 díxitos X00000000",
                },
                direccion: {
                    required: "O campo Dirección non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitido para este campo é 50."
                },
                cod_postal: {
                    required: "O campo Código Postal non pode estar baleiro",
                    pattern: "O Código Postal ten que estar composto por 5 díxitos numéricos"
                },
                localidade: {
                    required: "O campo Localidade non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitido para este campo é 50."
                },
                provincia_id: {
                    min: "Escolla unha Provincia do listado",
                },
                telefono: {
                    required: "O campo Teléfono non pode estar baleiro",
                    pattern: "O teléfono debe estar composto por 9 díxitos"
                },
                email: {
                    required: "Por favor, introduza un email correcto",
                    email: "Por favor, introduza un email correcto"
                }
            }
        });
    }

});


//VALIDACIÓN FORMULARIO REXISTRO PROXECTO


$(window).on("load", function () {
    $('#rexistrar_proxecto').validate({
        rules: {
            nom_proxecto: {
                required: true,
                maxlength: 50
            },
            cliente_id: {
                min: 1,
            },
            data_inicio: {
                required: true,
                dateISO: true
            },
            data_fin: {
                dateISO: true,
            }
        },
        messages: {
            nom_proxecto: {
                required: "O campo Nome Proxecto non pode estar baleiro",
                maxlength: "O máximo de caracteres permitido para este campo é 50."
            },
            cliente_id: {
                min: "Escolla unha Provincia do listado",
            },
            data_inicio: {
                required: "O campo Data Inicio non pode estar baleiro e debe conter unha data correcta",
                dateISO: "Debes introducir unha data correcta en formato aaaa/mm/dd"
            },
            data_fin: {
                dateISO: "Debes introducir unha data correcta en formato aaaa/mm/dd"
            }
        }
    })

});

//VALIDACIÓN FORMULARIO MODIFICACIÓN PROXECTO

$(window).on("load", function () {
    var numero = $(".modificar_proxecto").length;
    for (var i = 0; i < numero; i++) {
        $('#modificar_proxecto' + i).validate({
            rules: {
                nom_proxecto: {
                    required: true,
                    maxlength: 50
                },
                cliente_id: {
                    min: 1,
                },
                data_inicio: {
                    required: true,
                    dateISO: true
                },
                data_fin: {
                    dateISO: true
                }
            },
            messages: {
                nom_proxecto: {
                    required: "O campo Nome Proxecto non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitido para este campo é 50."
                },
                cliente_id: {
                    min: "Escolla unha Provincia do listado",
                },
                data_inicio: {
                    required: "O campo Data Inicio non pode estar baleiro e debe conter unha data correcta",
                    dateISO: "Debes introducir unha data correcta en formato aaaa/mm/dd"
                },
                data_fin: {
                    dateISO: "Debes introducir unha data correcta en formato aaaa/mm/dd"
                }
            }
        })
    }

});

//VALIDACIÓN FORMULARIO REXISTRO USUARIO

$(window).on("load", function () {
    $('#rexistrar_usuario').validate({
        rules: {

            nome: {
                required: true,
                maxlength: 20
            },

            primeiro_apelido: {
                required: true,
                maxlength: 20
            },
            segundo_apelido: {
                required: true,
                maxlength: 20
            },
            email: {
                required: true,
                email: true
            },
            telefono: {
                required: true,
                pattern: "\\d{9}"
            },
            password: {
                required: true,
                minlength: 8
            },
        },

        messages: {

            nome: {
                required: "O campo Nome non pode estar baleiro",
                maxlength: "O máximo de caracteres permitidos para este campo é 20"
            },

            primeiro_apelido: {
                required: "O campo Primeiro Apelido non pode estar baleiro",
                maxlength: "O máximo de caracteres permitidos para este campo é 20"
            },
            segundo_apelido: {
                required: "O campo Segundo Apelido non pode estar baleiro",
                maxlength: "O máximo de caracteres permitidos para este campo é 20"
            },
            email: {
                required: "O campo Email non pode estar baleiro",
                email: "Por favor, introduza un email correcto"
            },
            telefono: {
                required: "O campo Teléfono non pode estar baleiro",
                pattern: "O teléfono debe estar composto por 9 díxitos"
            },
            password: {
                required: "O campo Contrasinal non pode estar baleiro",
                minlength: "O Contrasinal debe contar con con 8 caracteres ou máis"
            },
        }
    });

});

//VALIDACIÓN FORMULARIO MODIFICACIÓN USUARIO

$(window).on("load", function () {
    var numero = $(".modificar_usuario").length;
    for (var i = 0; i < numero; i++) {


        $('#modificar_usuario' + i).validate({
            rules: {

                nome: {
                    required: true,
                    maxlength: 20
                },

                primeiro_apelido: {
                    required: true,
                    maxlength: 20
                },
                segundo_apelido: {
                    required: true,
                    maxlength: 20
                },
                email: {
                    required: true,
                    email: true
                },
                telefono: {
                    required: true,
                    pattern: "\\d{9}"
                },
                password: {
                    required: true,
                    minlength: 8
                },
            },

            messages: {

                nome: {
                    required: "O campo Nome non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitidos para este campo é 20"
                },

                primeiro_apelido: {
                    required: "O campo Primeiro Apelido non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitidos para este campo é 20"
                },
                segundo_apelido: {
                    required: "O campo Segundo Apelido non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitidos para este campo é 20"
                },
                email: {
                    required: "O campo Email non pode estar baleiro",
                    email: "Por favor, introduza un email correcto"
                },
                telefono: {
                    required: "O campo Teléfono non pode estar baleiro",
                    pattern: "O teléfono debe estar composto por 9 díxitos"
                },
                password: {
                    required: "O campo Contasinal non pode estar baleiro",
                    minlength: "O Contrasinal debe contar con con 8 caracteres ou máis"
                },
            }
        });
    }

});

//VALIDACIÓN FORMULARIO REXISTRO PETICIONARIO

$(window).on("load", function () {
    $('#rexistrar_peticionario').validate({
        rules: {

            nome: {
                required: true,
                maxlength: 20
            },

            primeiro_apelido: {
                required: true,
                maxlength: 20
            },
            segundo_apelido: {
                required: true,
                maxlength: 20
            },
            email: {
                required: true,
                email: true
            },
            telefono: {
                pattern: "\\d{9}"
            },
        },

        messages: {

            nome: {
                required: "O campo Nome non pode estar baleiro",
                maxlength: "O máximo de caracteres permitidos para este campo é 20"
            },

            primeiro_apelido: {
                required: "O campo Primeiro Apelido non pode estar baleiro",
                maxlength: "O máximo de caracteres permitidos para este campo é 20"
            },
            segundo_apelido: {
                required: "O campo Segundo Apelido non pode estar baleiro",
                maxlength: "O máximo de caracteres permitidos para este campo é 20"
            },
            email: {
                required: "O campo Email non pode estar baleiro",
                email: "Por favor, introduza un email correcto"
            },
            telefono: {
                pattern: "O teléfono debe estar composto por 9 díxitos"
            },
        }
    });

});
//VALIDACIÓN FORMULARIO MODIFICACIÓN PETICIONARIO

$(window).on("load", function () {
    var numero = $(".modificar_peticionario").length;
    for (var i = 0; i < numero; i++) {

        $('#modificar_peticionario' + i).validate({

            rules: {

                nome: {
                    required: true,
                    maxlength: 20
                },

                primeiro_apelido: {
                    required: true,
                    maxlength: 20
                },
                segundo_apelido: {
                    required: true,
                    maxlength: 20
                },
                email: {
                    required: true,
                    email: true
                },
                telefono: {
                    pattern: "\\d{9}"
                },
            },

            messages: {

                nome: {
                    required: "O campo Nome non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitidos para este campo é 20"
                },

                primeiro_apelido: {
                    required: "O campo Primeiro Apelido non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitidos para este campo é 20"
                },
                segundo_apelido: {
                    required: "O campo Segundo Apelido non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitidos para este campo é 20"
                },
                email: {
                    required: "O campo Email non pode estar baleiro",
                    email: "Por favor, introduza un email correcto"
                },
                telefono: {
                    pattern: "O teléfono debe estar composto por 9 díxitos"
                },
            }
        });

    }



});



//VALIDACIÓN FORMULARIO REXISTRAR INCIDENCIA

$(window).on("load", function () {
    $('#rexistrar_incidencia').validate({
        rules: {
            cod_inc_cliente: {
                maxlength: 20
            },
            proxecto_id: {
                min: 1
            },
            peticionario_id: {
                min: 1
            },
            data_peticion: {
                required: true,
                dateITA: true
            },
            nom_incidencia: {
                required: true,
                maxlength: 50
            },
            persoa_contacto: {
                required: true,
                maxlength: 20
            },
            telefono_contacto: {
                required: true,
                pattern: "\\d{9}"
            },
            direccion_asistencia: {
                required: true,
                maxlength: 50
            },
            cod_postal: {
                required: true,
                pattern: "\\d{5}"
            },
            provincia_id: {
                min: 1
            }
        },

        messages: {
            cod_inc_cliente: {
                maxlength: "O máximo de caracteres permitidos para este campo é 20"
            },
            proxecto_id: {
                min: "Escolla un proxecto do listado"
            },
            peticionario_id: {
                min: "Escolla un peticionario do listado"
            },
            data_peticion: {
                required: "O campo Data de Petición non pode estar baleiro",
                dateITA: "Por favor, introduza unha data e hora correctas en formato dd/mm/aaaa hh:mm"
            },
            nom_incidencia: {
                required: "O campo Nome de Incidencia non pode estar baleiro",
                maxlength: "O máximo de caracteres permitidos para este campo é 50"
            },
            persoa_contacto: {
                required: "O campo Persoa de Contacto non pode estar baleiro",
                maxlength: "O máximo de caracteres permitidos para este campo é 20"
            },
            telefono_contacto: {
                required: "O campo Teléfono de Contacto non pode estar baleiro",
                pattern: "O teléfono debe estar composto por 9 díxitos"
            },
            direccion_asistencia: {
                required: "O campo Dirección de asistencia non pode estar baleiro",
                maxlength: "O máximo de caracteres permitidos para este campo é 50"
            },
            cod_postal: {
                required: "O campo Código Postal non pode estar baleiro",
                pattern: "O Código postal ten que estar composto por 5 díxitos numéricos"
            },
            provincia_id: {
                min: "Escolla unha provincia do listado"
            }
        }
    });

});


//VALIDACIÓN FORMULARIO MODIFICAR INCIDENCIA

$(window).on("load", function () {


    var numero = $(".modificar_incidencia").length;
    for (var i = 0; i < numero; i++) {

        $('#modificar_incidencia' + i).validate({
            rules: {
                cod_inc_cliente: {
                    maxlength: 20
                },
                proxecto_id: {
                    min: 1
                },
                peticionario_id: {
                    min: 1
                },
                data_peticion: {
                    required: true,
                    dateITA: true
                },
                nom_incidencia: {
                    required: true,
                    maxlength: 50
                },
                persoa_contacto: {
                    required: true,
                    maxlength: 20
                },
                telefono_contacto: {
                    required: true,
                    pattern: "\\d{9}"
                },
                direccion_asistencia: {
                    required: true,
                    maxlength: 50
                },
                cod_postal: {
                    required: true,
                    pattern: "\\d{5}"
                },
                provincia_id: {
                    min: 1
                }
            },

            messages: {
                cod_inc_cliente: {
                    maxlength: "O máximo de caracteres permitidos para este campo é 20"
                },
                proxecto_id: {
                    min: "Escolla un proxecto do listado"
                },
                peticionario_id: {
                    min: "Escolla un peticionario do listado"
                },
                data_peticion: {
                    required: "O campo Data de Petición non pode estar baleiro",
                    dateITA: "Por favor, introduza unha data e hora correctas en formato dd/mm/aaaa hh:mm"
                },
                nom_incidencia: {
                    required: "O campo Nome de Incidencia non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitidos para este campo é 50"
                },
                persoa_contacto: {
                    required: "O campo Persoa de Contacto non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitidos para este campo é 20"
                },
                telefono_contacto: {
                    required: "O campo Teléfono de Contacto non pode estar baleiro",
                    pattern: "O teléfono debe estar composto por 9 díxitos"
                },
                direccion_asistencia: {
                    required: "O campo Dirección de asistencia non pode estar baleiro",
                    maxlength: "O máximo de caracteres permitidos para este campo é 50"
                },
                cod_postal: {
                    required: "O campo Código Postal non pode estar baleiro",
                    pattern: "O Código postal ten que estar composto por 5 díxitos numéricos"
                },
                provincia_id: {
                    min: "Escolla unha provincia do listado"
                }
            }
        });
    }

});

//VALIDACIÓN FORMULARIO PLANIFICAR INCIDENCIA

$(window).on("load", function () {


    var numero = $(".planificar_incidencia").length;
    for (var i = 0; i < numero; i++) {

        $('#planificar_incidencia' + i).validate({
            rules: {
                data_planificada: {
                    required: true,
                    dateITA: true
                },
                tecnico_id: {
                    min: 1
                },
               
            },

            messages: {
                data_planificada: {
                    required: "O campo Data de Planificación non pode estar baleiro",
                    dateITA: "Por favor, introduza unha data e hora correctas en formato dd/mm/aaaa hh:mm"
                },
                tecnico_id: {
                    min: "Escolla un técnico do listado"
                },
                
            }
        });
    }

});

//TRANSFORMAR TEXTOS DE INPUT A MAYÚSCULAS

$(window).on("load", function () {
    $("input:text").on("focusout",function(){
        this.value = this.value.toUpperCase();
    });
});