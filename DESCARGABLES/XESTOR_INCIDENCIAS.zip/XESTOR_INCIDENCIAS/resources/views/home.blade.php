@extends('layouts.app')

@section('content')
    <div class="container">
    
        @if(auth()->user()->rol == 'ADMINISTRADOR')
            <div class="row">
                <div class="col-md-12">
                
                <h6>INCIDENCIAS PLANIFICADAS HOXE</h6>
                    <div class="card-body">
                        @include('listas_home.incidencias_hoxe')
                    </div>
                </div>
            </div>
            <div class="row">
                &nbsp;&nbsp;
            </div>
        @else
            <div class="row">
                <div class="col-md-12">
                
                <h5>Incidencias Planificadas {{auth()->user()->nome}} {{auth()->user()->primeiro_apelido}} {{auth()->user()->segundo_apelido}}</h5>
                    <div class="card-body">
                        @include('listas_home.incidencias_tecnico')
                    </div>
                </div>
            </div>
        @endif
    </div>
@endsection
