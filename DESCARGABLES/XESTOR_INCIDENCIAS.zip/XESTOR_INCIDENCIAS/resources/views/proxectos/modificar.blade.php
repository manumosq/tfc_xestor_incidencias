<!--VENTANA MODAL ACTUALIZAR PROXECTO-->

<div class="modal fade" id="modificar{{ $contador }}">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">MODIFICANDO PROXECTO - {{ $proxecto->cod_proxecto }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <form method="POST" id="modificar_proxecto{{ $contador }}" class="modificar_proxecto" action="{{ route('modificarProxecto') }}">
                        @csrf
                        <input type="hidden" name="id" value="{{ $proxecto->id }}">
                        <div class="row">
                            <h5>Datos Proxecto:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="nom_proxecto">Nome Proxecto:</label>
                                <input type="text" class="form-control form-control-sm" id="nom_proxecto"
                                    name="nom_proxecto" value="{{ $proxecto->nom_proxecto }}"
                                    placeholder="Nome Proxecto">
                            </div>
                            <div class="col-md-6">
                                <label for="cliente">Cliente:</label>
                                <select class="form-control form-control-sm" id="cliente_id" name="cliente_id">
                                    <option value="{{ $proxecto->clientes->id }}">{{ $proxecto->clientes->nom_comercial }}
                                    </option>
                                    @foreach ($clientes as $cliente)
                                        <option value="{{ $cliente->id }}">{{ $cliente->nom_comercial }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Estado:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="data_inicio">Data Inicio:</label>
                                <input type="date" class="form-control form-control-sm" id="data_inicio" name="data_inicio"
                                    value="{{ $proxecto->data_inicio }}">
                            </div>
                            <div class="col-md-6">
                                <label for="data_fin">Data Fin:</label>
                                <input type="date" class="form-control form-control-sm" id="data_fin"
                                    name="data_fin" value="{{ $proxecto->data_fin }}">
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-primary">Modificar Proxecto</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
