@extends('layouts.app')

@section('content')
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Proxectos</span></a></li>
                </ol>
            </nav>
        </div>
        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Proxectos</h5>
        </div>

        <form method="GET" action="{{ route('listadoProxectos') }}">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="nom_proxecto">Nome Proxecto:</label>
                        <input type="text" class="form-control form-control-sm" id="nom_proxecto" name="nom_proxecto"
                            placeholder="Nome Proxecto">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="cliente">Cliente:</label>
                        <select class="form-control form-control-sm" id="cliente" name="cliente_id">
                            <option value="0">Seleccionar Cliente</option>
                            @foreach ($clientes as $cliente)
                                <option value="{{ $cliente->id }}">{{ $cliente->nom_comercial }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="Estado">Estado:</label>
                        <select class="form-control form-control-sm" id="estado" name="estado">
                            <option value="0">Estado</option>
                            <option value="1">EN PROCESO</option>
                            <option value="2">FINALIZADO</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Proxecto" src="img\buscar.png"> Buscar Proxecto
                    </button>

                    <a href="{{ route('listadoClientes') }}"><button class="btn btn-primary">Ver Todos</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS--> 
        <div class="row">
            <h5>Proxectos Rexistrados</h5>
        </div>

        <div class="row justify-content-center">
            @if (session('mensaxe'))
                <div class="alert alert-success col-md-12">
                    {{ session('mensaxe') }}
                </div>
            @endif
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="table-primary">Código Proxecto</th>
                            <th class="table-primary">Nome Proxecto</th>
                            <th class="table-primary">Cliente</th>
                            <th class="table-primary">Data Inicio</th>
                            <th class="table-primary">Data Fin</th>
                            <th class="table-primary text-center" colspan="3">Accións</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($proxectos->count()==0) <td colspan="10">Non se atoparon proxectos.</td>
                        @else
                            @foreach ($proxectos as $proxecto)
                            <tr>
                            <td>{{ $proxecto->cod_proxecto }}</td>
                            <td>{{ $proxecto->nom_proxecto }}</td>
                            <td>{{ $proxecto->clientes->nom_comercial }}</td>
                            <td>{{ $proxecto->data_inicio_formato }}</td>
                            <td>
                            @if ($proxecto->data_fin == null) EN PROCESO @else
                                    {{ $proxecto->data_fin_formato }} @endif
                            </td>
                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#ver{{ $contador }}" title="Ver Proxecto"><img
                                        style="width:25px" alt="Ver Cliente" src="img\ver.png"></a>
                                @include('proxectos.ver')
                            </td>
                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#modificar{{ $contador }}"
                                    title="Modificar Proxecto"><img style="width:20px" alt="Editar Cliente"
                                        src="img\editar.png"></a>
                                @include('proxectos.modificar') 
                            </td>
                            <td style="max-width: 30px;">
                                <a href="#" data-toggle="modal" data-target="#eliminar{{ $contador }}"
                                    title="Eliminar Proxecto"><img style="width:15px" alt="Eliminar Cliente"
                                        src="img\eliminar.png"></a>
                                @include('proxectos.eliminar')
                            </td>
                            </tr>
                            <?php $contador++; ?>
                            @endforeach
                        @endif
                    </tbody>

                </table>
            </div>
            {{ $proxectos->links('vendor.pagination.bootstrap-4') }}

        </div>
        <div class="row">
            <a href="#" data-toggle="modal" data-target="#crear" title="Crear Proxecto">
                <button type="button" class="btn btn-primary">Engadir Novo
                    Proxecto</button></a>
                @include('proxectos.crear')
        </div>
        @if ($errors->any())
        <div class="row justify-content-start alert alert-danger col-md-6">
            <p>Non se puido completar a acción debido ao/-s seguinte/-s erro/-s:</p>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
            <p>Por favor, volva tentalo solventando os erros anteriores.</p>
        </div>
        @endif
    </div>
@endsection
