@extends('layouts.app')

@section('content')
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Clientes</span></a></li>
                </ol>
            </nav>
        </div>
        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Clientes</h5>
        </div>
        <form method="GET" action="{{ route('listadoClientes') }}">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="nom_comercial">Nome Comercial:</label>
                        <input type="text" class="form-control form-control-sm" id="nom_comercial" name="nom_comercial"
                            placeholder="Nome Comercial">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="text" class="form-control form-control-sm" id="email" name="email" placeholder="Email">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="provincia">Provincia:</label>
                        <select class="form-control form-control-sm" id="provincia" name="provincia_id"
                            placeholder="Provincia">
                            <option value="0">Seleccionar Provincia</option>
                            @foreach ($provincias as $provincia)
                                <option value="{{ $provincia->id }}">{{ $provincia->nome }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Cliente" src="img\buscar.png"> Buscar Cliente
                    </button>

                    <a href="{{ route('listadoClientes') }}"><button class="btn btn-primary">Ver Todos</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS-->
        <div class="row">
            <h5>Clientes Rexistrados</h5>
        </div>

        <div class="row justify-content-center">
            @if (session('mensaxe'))
                <div class="alert alert-success col-md-12" id="aviso">
                    {{ session('mensaxe') }}
                </div>
            @endif
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>

                            <th class="table-primary">Código Cliente</th>
                            <th class="table-primary">Nome Comercial</th>
                            <th class="table-primary">Teléfono</th>
                            <th class="table-primary">Email</th>
                            <th class="table-primary text-center" colspan="3">Accións</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($clientes->count()==0) <td colspan="10">Non se atoparon clientes.</td>
                        @else

                            @foreach ($clientes as $cliente)

                            <tr  data-id="{{$cliente->id}}">
                            <td>{{ $cliente->cod_cliente }}</td>
                            <td>{{ $cliente->nom_comercial }}</td>
                            <td>{{ $cliente->telefono }}</td>
                            <td>{{ $cliente->email }}</td>
                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#ver{{ $contador }}"
                                title="Ver Cliente"><img style="width:25px" alt="Ver Cliente"
                                    src="img\ver.png"></a>
                                    @include('clientes.ver')
                                    
                                
                            </td>
                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#modificar{{ $contador }}"
                                    title="Modificar Cliente"><img style="width:20px" alt="Editar Cliente"
                                        src="img\editar.png"></a>
                                        @include('clientes.modificar')
                                    
                            </td>
                            <td style="max-width: 30px;">
                            <a href="#" data-toggle="modal" data-target="#eliminar{{ $contador }}" data-cliente="{{ $cliente->id }}"
                                    title="Eliminar Cliente"><img style="width:15px" alt="Eliminar Cliente"
                                        src="img\eliminar.png"></a>
                                        @include('clientes.eliminar')
                            </td>
                            </tr>
                            <?php $contador++; ?>
                            @endforeach
                        @endif
                    </tbody>

                </table>
            </div>
            {{ $clientes->links('vendor.pagination.bootstrap-4') }}

        </div>
        <div class="row">
            <a href="#" data-toggle="modal" data-target="#crear" title="Crear Cliente">
                <button type="button" class="btn btn-primary">Engadir Novo
                    Cliente</button></a>
                @include('clientes.rexistrar')
        </div>

        @if ($errors->any())
        <div class="row justify-content-start alert alert-danger col-md-6">
            <p>Non se puido completar a acción debido ao/-s seguinte/-s erro/-s:</p>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
            <p>Por favor, volva tentalo solventando os erros anteriores.</p>
        </div>
        @endif
    </div>

@endsection
