<!--VENTANA MODAL ACTUALIZAR CLIENTE-->

<div class="modal fade" id="modificar{{ $contador }}">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">MODIFICANDO CLIENTE - {{ $cliente->cod_cliente }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <form method="POST"  id="modificar_cliente{{ $contador }}" class="modificar_cliente" action="{{ route('modificarCliente') }}">
                        @csrf
                        <input type="hidden" name="id" value="{{ $cliente->id }}">
                        <div class="row">
                            <h5>Datos Fiscais:</h5>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <label for="nom_comercial">Nome Comercial:</label>
                                <input type="text" class="form-control form-control-sm" id="nom_comercial"
                                    name="nom_comercial" value="{{ $cliente->nom_comercial }}"
                                    placeholder="Nome Comercial">
                            </div>
                            <div class="col-md-4">
                                <label for="nom_fiscal">Nome Fiscal:</label>
                                <input type="text" class="form-control form-control-sm" id="nom_fiscal"
                                    name="nom_fiscal" value="{{ $cliente->nom_fiscal }}" placeholder="Nome Fiscal">
                            </div>
                            <div class="col-md-4">
                                <label for="cif">CIF:</label>
                                <input type="text" class="form-control form-control-sm" id="cif" name="cif"
                                    value="{{ $cliente->cif }}" placeholder="CIF">
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Dirección:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <label for="direccion">Dirección:</label>
                                <input type="text" class="form-control form-control-sm" id="direccion" name="direccion"
                                    value="{{ $cliente->direccion }}" placeholder="Dirección">
                            </div>
                            <div class="col-md-3">
                                <label for="cod_postal">Código Postal:</label>
                                <input type="text" class="form-control form-control-sm" id="cod_postal"
                                    name="cod_postal" value="{{ $cliente->cod_postal }}" placeholder="código postal">
                            </div>
                            <div class="col-md-3">
                                <label for="Localidad">Localidade:</label>
                                <input type="text" class="form-control form-control-sm" id="localidade"
                                    name="localidade" value="{{ $cliente->localidade }}" placeholder="Localidade">
                            </div>
                            <div class="col-md-3">
                                <label for="Provincia">Provincia:</label>
                                <select class="form-control form-control-sm" id="provincia" name="provincia_id"
                                    placeholder="Provincia">
                                    <option value="{{ $cliente->provincias->id }}">{{ $cliente->provincias->nome }}
                                    </option>
                                    @foreach ($provincias as $provincia)
                                        <option value="{{ $provincia->id }}">{{ $provincia->nome }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Contacto:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-7">
                                <label for="Teléfono">Teléfono:</label>
                                <input type="tel" class="form-control form-control-sm" id="telefono" name="telefono"
                                    value="{{ $cliente->telefono }}" placeholder="Teléfono">
                            </div>
                            <div class="col-md-5">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control form-control-sm" id="email" name="email"
                                    value="{{ $cliente->email }}" placeholder="Email">
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-primary">Modificar Cliente</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
