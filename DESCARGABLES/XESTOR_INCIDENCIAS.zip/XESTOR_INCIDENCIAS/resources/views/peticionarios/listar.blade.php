@extends('layouts.app')

@section('content')
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Peticionarios</span></a></li>
                </ol>
            </nav>
        </div>
        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Peticionarios</h5>
        </div>

        <form method="GET" action="{{ route('listadoPeticionarios') }}">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="nome">Nome Peticionario:</label>
                        <input type="text" class="form-control form-control-sm" id="nome" name="nome"
                            placeholder="Nome Peticionario">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="primeiro_apelido">Primeiro Apelido:</label>
                        <input type="text" class="form-control form-control-sm" id="primeiro_apelido" name="primeiro_apelido"
                            placeholder="Primeiro Apelido">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="Segundo Apelido">Segundo Apelido:</label>
                        <input type="text" class="form-control form-control-sm" id="segundo_apelido" name="segundo_apelido"
                            placeholder="Segundo Apelido">
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Proxecto" src="img\buscar.png"> Buscar Peticionario
                    </button>

                    <a href="{{ route('listadoPeticionarios') }}"><button class="btn btn-primary">Ver Todos</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS-->
        <div class="row">
            <h5>Peticionarios Rexistrados</h5>
        </div>

        <div class="row justify-content-center">
            @if (session('mensaxe'))
                <div class="alert alert-success col-md-12">
                    {{ session('mensaxe') }}
                </div>
            @endif
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="table-primary">Nome</th>
                            <th class="table-primary">Primeiro Apelido</th>
                            <th class="table-primary">Segundo Apelido</th>
                            <th class="table-primary">Email</th>
                            <th class="table-primary">Teléfono</th>
                            <th class="table-primary text-center" colspan="3">Accións</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($peticionarios->count()==0) <td colspan="10">Non se atoparon peticionarios.</td>
                        @else
                            @foreach ($peticionarios as $peticionario)
                            <tr>
                            <td>{{ $peticionario->nome }}</td>
                            <td>{{ $peticionario->primeiro_apelido }}</td>
                            <td>{{ $peticionario->segundo_apelido }}</td>
                            <td>{{ $peticionario->email }}</td>
                            <td>{{ $peticionario->telefono }}</td>
                            <td style="max-width: 30px;">
                                <a href="#" data-toggle="modal" data-target="#ver{{ $contador }}"
                                    title="Ver Peticionario"><img style="width:25px" alt="Ver Peticionario"
                                        src="img\ver.png"></a>
                                @include('peticionarios.ver')
                            </td>
                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#modificar{{ $contador }}"
                                    title="Modificar Peticionario"><img style="width:20px" alt="Modificar Peticionario"
                                        src="img\editar.png"></a>
                                        @include('peticionarios.modificar')
                            </td>
                            <td style="max-width: 30px;">
                                <a href="#" data-toggle="modal" data-target="#eliminar{{ $contador }}"
                                    title="Eliminar Peticionario"><img style="width:15px" alt="Eliminar Peticionario"
                                        src="img\eliminar.png"></a>
                                        @include('peticionarios.eliminar')
                                
                            </td>
                            </tr>
                            <?php $contador++; ?>
                            @endforeach
                        @endif
                    </tbody>

                </table>
            </div>
            {{ $peticionarios->links('vendor.pagination.bootstrap-4') }}

        </div>
        <div class="row">
            <a href="#" data-toggle="modal" data-target="#crear" title="Crear Peticionarios">
                <button type="button" class="btn btn-primary">Engadir Novo
                    peticionario</button></a>
            @include('peticionarios.crear')
        </div>
        @if ($errors->any())
        <div class="row justify-content-start alert alert-danger col-md-6">
            <p>Non se puido completar a acción debido ao/-s seguinte/-s erro/-s:</p>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
            <p>Por favor, volva tentalo solventando os erros anteriores.</p>
        </div>
        @endif
    </div>
@endsection
