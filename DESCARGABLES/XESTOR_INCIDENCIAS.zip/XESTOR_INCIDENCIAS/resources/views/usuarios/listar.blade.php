@extends('layouts.app')

@section('content')
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Usuarios</span></a></li>
                </ol>
            </nav>
        </div>

        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Usuarios</h5>
        </div>

        <form method="GET" action="{{ route('listadoUsuarios') }}">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="nome">Nome Usuario:</label>
                        <input type="text" class="form-control form-control-sm" id="nome" name="nome"
                            placeholder="Nome Usuario">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="primeiro_apelido">Primeiro Apelido:</label>
                        <input type="text" class="form-control form-control-sm" id="primeiro_apelido"
                            name="primeiro_apelido" placeholder="Primeiro Apelido">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="Segundo Apelido">Segundo Apelido:</label>
                        <input type="text" class="form-control form-control-sm" id="segundo_apelido" name="segundo_apelido"
                            placeholder="Segundo Apelido">
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Proxecto" src="img\buscar.png"> Buscar Usuario
                    </button>

                    <a href="{{ route('listadoUsuarios') }}"><button class="btn btn-primary">Ver Todos</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS-->
        <div class="row">
            <h5>Usuarios / Técnicos Rexistrados</h5>
        </div>

        <div class="row justify-content-center">
            @if (session('mensaxe'))
                <div class="alert alert-success col-md-12">
                    {{ session('mensaxe') }}
                </div>
            @endif
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="table-primary">Nome</th>
                            <th class="table-primary">Primeiro Apelido</th>
                            <th class="table-primary">Segundo Apelido</th>
                            <th class="table-primary">Email</th>
                            <th class="table-primary">Teléfono</th>
                            <th class="table-primary">Rol</th>
                            <th class="table-primary text-center" colspan="3">Accións</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($usuarios->count()==0) <td colspan="10">Non se atoparon usuarios.</td>
                        @else
                            @foreach ($usuarios as $usuario)
                            <tr>
                            <td>{{ $usuario->nome }}</td>
                            <td>{{ $usuario->primeiro_apelido }}</td>
                            <td>{{ $usuario->segundo_apelido }}</td>
                            <td>{{ $usuario->email }}</td>
                            <td>{{ $usuario->telefono }}</td>
                            <td>{{ $usuario->rol }}</td>
                            <td style="max-width: 30px;">
                                <a href="#" data-toggle="modal" data-target="#ver{{ $contador }}" title="Ver Usuario"><img
                                        style="width:25px" alt="Ver Usuario" src="img\ver.png"></a>
                                @include('usuarios.ver')
                            </td>
                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#modificar{{ $contador }}"
                                    title="Modificar Usuario"><img style="width:20px" alt="Modificar Usuario"
                                        src="img\editar.png"></a>
                                @include('usuarios.modificar')
                            </td>
                            <td style="max-width: 30px;">
                                <a href="#" data-toggle="modal" data-target="#eliminar{{ $contador }}"
                                    title="Eliminar Usuario"><img style="width:15px" alt="Eliminar Usuario"
                                        src="img\eliminar.png"></a>
                                @include('usuarios.eliminar')

                            </td>
                            </tr>
                            <?php $contador++; ?>
                            @endforeach
                        @endif
                    </tbody>

                </table>
            </div>
            {{ $usuarios->links('vendor.pagination.bootstrap-4') }}

        </div>
        <div class="row">
            <a href="#" data-toggle="modal" data-target="#crear" title="Crear Técnicos">
                <button type="button" class="btn btn-primary">Engadir Novo
                    Usuario</button></a>
            @include('usuarios.crear')
        </div>
        @if ($errors->any())
        <div class="row justify-content-start alert alert-danger col-md-6">
            <p>Non se puido completar a acción debido ao/-s seguinte/-s erro/-s:</p>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
            <p>Por favor, volva tentalo solventando os erros anteriores.</p>
        </div>
        @endif
    </div>
@endsection