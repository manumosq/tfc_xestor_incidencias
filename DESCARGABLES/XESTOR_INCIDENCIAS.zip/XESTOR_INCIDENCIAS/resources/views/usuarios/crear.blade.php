<!--VENTANA MODAL CREAR USUARIO-->

<div class="modal fade" id="crear">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">NOVO USUARIO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <form method="POST" id="rexistrar_usuario" action="{{ route('crearUsuario') }}">
                        @csrf
                        <div class="row">
                            <h5>Datos Persoais:</h5>
                        </div> 
                        <div class="row">
                            <div class="col-md-4">
                                <label for="nome">Nome:</label>
                                <input type="text" class="form-control form-control-sm" id="nome"
                                    name="nome" value="{{ old('nome') }}" placeholder="Nome">
                            </div>
                            <div class="col-md-4">
                                <label for="primeiro_apelido">Primeiro Apelido:</label>
                                <input type="text" class="form-control form-control-sm" id="primeiro_apelido"
                                    name="primeiro_apelido" value="{{ old('primeiro_apelido') }}" placeholder="Primeiro Apelido">
                            </div>
                            <div class="col-md-4">
                                <label for="segundo_apelido">Segundo Apelido:</label>
                                <input type="text" class="form-control form-control-sm" id="segundo_apelido"
                                    name="segundo_apelido" value="{{ old('segundo_apelido') }}" placeholder="Segundo Apelido">
                            </div>
                            
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Datos de Contacto:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control form-control-sm" id="email"
                                    name="email" value="{{ old('email') }}" placeholder="Email">
                            </div>
                            <div class="col-md-6">
                                <label for="telefono">Teléfono:</label>
                                <input type="tel" class="form-control form-control-sm" id="telefono"
                                    name="telefono" value="{{ old('telefono') }}" placeholder="Teléfono">
                            </div>
                            
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Datos de acceso:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="rol">Tipo de usuario:</label>
                                <select class="form-control form-control-sm" id="rol" name="rol">
                                    <option value="TECNICO">Técnico</option>
                                    <option value="ADMINISTRADOR">Administrador</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="password">Contrasinal:</label>
                                <input type="password" class="form-control form-control-sm" id="password"
                                    name="password" value="{{ old('password') }}" placeholder="Contrasinal">
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-primary">Crear Usuario</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
