<!--VENTANA MODAL ELIMINAR USUARIO-->

<div class="modal fade" id="eliminar{{ $contador }}">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title">ELIMINANDO USUARIO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row justify-content-center">
                <h6 class="text-center">Está a punto de eliminar o usuario <b style="text-decoration: underline">{{ $usuario->nome }} {{ $usuario->primeiro_apelido }} {{ $usuario->segundo_apelido }}</b> da base de datos.</h6>
                <h6 class="text-center">Esta acción non se poderá desfacer.</h6>
                <h6 class="text-center">¿Está seguro de que quere continuar?</h6>
                <p>&nbsp;</p>
                    </div>
                    <form method="POST" action="{{ route('eliminarUsuario') }}">
                        @csrf
                        <input type="hidden" name="id" value="{{ $usuario->id }}">
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-danger">Borrar Usuario</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>