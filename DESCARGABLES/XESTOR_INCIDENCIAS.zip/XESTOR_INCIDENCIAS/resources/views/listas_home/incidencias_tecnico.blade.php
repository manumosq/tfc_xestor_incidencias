<!--TÁBOA DE RESULTADOS-->
<div class="row justify-content-center">
    @if (session('mensaxe'))
        <div class="alert alert-success col-md-12" id="aviso">
            {{ session('mensaxe') }}
        </div>
    @endif
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>

                    <th class="table-primary">INC</th>
                    <th class="table-primary">Nome Incidencia</th>
                    <th class="table-primary">Data Planificada</th>
                    <th class="table-primary">Persoa Contacto</th>
                    <th class="table-primary">Teléfono Contacto</th>
                    <th class="table-primary">Dirección</th>
                    <th class="table-primary text-center" colspan="3">Accións</th>
                </tr>
            </thead>
            <tbody>
                @if($incidencias->count()==0) <td colspan="9">Hola {{auth()->user()->nome}} polo momento non tes nada asignado para hoxe, contacta co teu coordinador para que che asigne traballos.</td>
                @else

                    @foreach ($incidencias as $incidencia)

                        <tr data-id="{{ $incidencia->id }}" @if ($contador % 2 != 0) class="table-light"
                    @endif>
                    <td>{{ $incidencia->cod_inc }}</td>
                    <td>{{ $incidencia->nom_incidencia }}</td>
                    <td>{{ $incidencia->data_planificada_formato }}</td>
                    <td>{{ $incidencia->persoa_contacto }} </td>
                    <td>{{ $incidencia->telefono_contacto }}</td>
                    <td>{{ $incidencia->direccion_asistencia }}</td>
                    <td style="max-width: 30px;">
                        <a href=# data-toggle="modal" data-target="#ver{{ $contador }}" title="Ver Incidencia"><img
                                style="width:25px" alt="Ver Cliente" src="img\ver.png"></a>
                        @include('incidencias.ver')


                    </td>
                    <td style="max-width: 30px;">
                        @if($incidencia->estado_actual < 3)
                        <a href=# data-toggle="modal" data-target="#anunciar_chegada{{ $contador }}"
                            title="Anunciar chegada Cliente"><img style="width:20px" alt="Anunciar chegada Cliente"
                                src="img\llegada.png"></a>
                        @include('incidencias.anunciar_chegada')
                        @else
                        <img style="width:20px" alt="Chegada xa anunciada" title="Chegada xa anunciada" src="img\llegada_marcada.png">
                        @endif
                    </td>
                    <td style="max-width: 30px;">
                        @if($incidencia->estado_actual < 4)
                        <a href="#" data-toggle="modal" data-target="#anunciar_finalizacion{{ $contador }}"
                            title="Anunciar Finalización Incidencia"><img style="width:24px" alt="Anunciar Finalización Incidencia"
                                src="img\finalizacion.png"></a>
                        @include('incidencias.anunciar_finalizacion')
                        @else
                            <img style="width:24px" alt="Finalización xa anunciada" title="Finalización xa anunciada" src="img\finalizacion_marcada.png">
                        @endif
                    </td>
                    </tr>
                    <?php $contador++; ?>
                    @endforeach
                @endif
            </tbody>

        </table>
    </div>
    {{ $incidencias->links('vendor.pagination.bootstrap-4') }}

</div>