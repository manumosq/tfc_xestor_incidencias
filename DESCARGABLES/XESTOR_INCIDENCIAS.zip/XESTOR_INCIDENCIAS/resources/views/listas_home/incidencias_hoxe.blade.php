<!--TÁBOA DE RESULTADOS-->
<div class="row justify-content-center">
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>

                    <th class="table-primary">INC</th>
                    <th class="table-primary">INC Cliente</th>
                    <th class="table-primary">Nome Incidencia</th>
                    <th class="table-primary">Técnico Asignado</th>
                    <th class="table-primary text-center">Data Planificación</th>
                    <th class="table-primary text-center">Data Asistencia</th>
                    <th class="table-primary text-center">Data Finalización</th>
                    <th class="table-primary text-center">Estado</th>
                    <th class="table-primary text-center" colspan="2">Accións</th>
                </tr>
            </thead>
            
            <tbody>
                @if($incidencias->count()==0) <td colspan="10">Hola {{auth()->user()->nome}} polo momento non hai nada planificado para hoxe.</td>
                @else
                    @foreach ($incidencias as $incidencia)

                    <tr>
                    <td>{{ $incidencia->cod_inc }}</td>
                    <td>{{ $incidencia->cod_inc_cliente }}</td>
                    <td>{{ $incidencia->nom_incidencia }}</td>
                    <td>{{ $incidencia->users->nome }} {{ $incidencia->users->primeiro_apelido }}<{{ $incidencia->users->segundo_apelido }}/td>
                    <td class="text-center">
                        @if ($incidencia->data_planificada == null) PENDENTE
                        @else {{ $incidencia->data_planificada_formato }}
                        @endif
                    </td>
                    <td class="text-center">
                        @if ($incidencia->data_asistencia == null) PENDENTE
                        @else {{ $incidencia->data_asistencia_formato }}
                        @endif
                    </td>
                    <td class="text-center">
                        @if ($incidencia->data_finalizacion == null) PENDENTE
                        @else {{ $incidencia->data_finalizacion_formato }}
                        @endif
                    </td>
                    <td class="text-center
                    @if ($incidencia->estado_actual == 2) table-planificada text-center
                    @elseif ($incidencia->estado_actual == 3) table-enproceso text-center
                    @elseif ($incidencia->estado_actual == 4) table-finalizada text-center
                    @elseif ($incidencia->estado_actual == 6) table-cancelada text-center                        
                    @endif
                    "
                    >{{ $incidencia->estados->last()->nome }}</td>


                    <td style="max-width: 30px;">
                        <a href=# data-toggle="modal" data-target="#ver{{ $contador }}" title="Ver Incidencia"><img
                                style="width:25px" alt="Ver Incidencia" src="img\ver.png"></a>
                        @include('incidencias.ver')


                    </td>
                    <td style="max-width: 30px;">
                        
                        <a href="#" data-toggle="modal" data-target="#ver_tecnico_asignado{{ $contador }}"
                            title="Ver datos técnico asignado"><img style="width:20px"
                                alt="Ver datos técnico asignado" src="img\tecnico_asignado.png"></a>
                        @include('incidencias.ver_tecnico_asignado')
                        
                    </td>
                    </tr>
                    <?php $contador++; ?>
                    @endforeach
                @endif
            </tbody>

        </table>
    </div>
    {{ $incidencias->links('vendor.pagination.bootstrap-4') }}
    <div class="row">
        <a href="{{ route('listadoIncidencias') }}"><button type="button" class="btn btn-primary">Ver Tódalas Incidencias</button></a>
    </div>
</div>
