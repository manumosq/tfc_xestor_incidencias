@extends('layouts.app')

@section('content')
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="{{ route('listadoIncidencias') }}"><span>Incidencias</span></a><img
                            class="ml-md-3 ml-1" src="img/flecha.png " width="20" height="20"></li>
                    <li class="breadcrumb-item"><a href="#"><span>Rexistrar Incidencia</span></a></li>
                </ol>
            </nav>
        </div>
        <div class="row justify-content-left">
            <div class="col">
                <div class="card">
                    <div class="card-header bg-primary text-white">Rexistrar Incidencia</div>
                    <div class="card-body">
                        <div class="col-md-12">
                            <form method="POST" action="{{ route('rexistrarIncidencia') }}" id="rexistrar_incidencia">
                                @csrf
                                <div class="row">
                                    <h5>Datos de Incidencia:</h5>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="cod_inc_cliente">Código Incidencia Cliente:</label>
                                        <input type="text"  class="form-control form-control-sm" id="cod_inc_cliente" name="cod_inc_cliente"
                                        value= "{{ old('cod_inc_cliente')}}" placeholder="Código Incidencia Cliente">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="proxecto">Proxecto</label>
                                        <select class="form-control form-control-sm" id="proxecto" name="proxecto_id"
                                                placeholder="Proxecto">
                                                <option value="0">Seleccionar Proxecto</option>
                                                @foreach ($proxectos as $proxecto)
                                                    @if($proxecto->data_fin == null)
                                                        <option value="{{ $proxecto->id }}" @if ($proxecto->id == old('proxecto_id')) selected
                                                        @endif>{{ $proxecto->nom_proxecto }}</option>
                                                    @endif  

                                                @endforeach
                                        </select> 
                                    </div>
                                    <div class="col-md-3"> 
                                        <label for="peticionario">Peticionario</label>
                                        <select class="form-control form-control-sm" id="peticionario" name="peticionario_id"
                                                placeholder="Peticionario">
                                                <option value="0">Seleccionar Peticionario</option>
                                                @foreach ($peticionarios as $peticionario)
                                                    <option value="{{ $peticionario->id }}" @if ($peticionario->id == old('peticionario_id')) selected
                                                @endif>{{ $peticionario->nome }} {{ $peticionario->primeiro_apelido }} {{ $peticionario->segundo }}</option>
                                                @endforeach
                                        </select>   
                                    </div>
                                    <div class="col-md-3">
                                        <label for="data_peticion">Data da Petición</label>
                                        <input type="text" class="form-control form-control-sm" id="data_peticion" name="data_peticion"
                                        value= "{{ old('data_peticion')}}" placeholder="DD/MM/AAAA HH:MM">
                                    </div>
                                </div>
                                <div class="row">
                                    &nbsp;
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="nom_incidencia">Nome Incidencia</label>
                                        <input type="text" class="form-control form-control-sm" id="nom_incidencia" name="nom_incidencia"
                                        value= "{{ old('nom_incidencia')}}" placeholder="Nome Incidencia">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="descripcion">Descripción Incidencia:</label>
                                        <textarea class="form-control form-control-sm" id="descripcion" name="descripcion" rows="6"></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    &nbsp;
                                </div>
                                <div class="row">
                                    <h5>Datos de Asistencia:</h5>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                    <label for="persoa_contacto">Persoa de Contacto:</label>
                                    <input type="text" class=" form-control form-control-sm" id="persoa_contacto" name="persoa_contacto"
                                    value= "{{ old('persoa_contacto')}}" placeholder="Persoa de Contacto">
                                    </div>
                                    <div class="col-md-6">
                                    <label for="telefono_contacto">Teléfono de Contacto</label>
                                    <input type="tel" class="form-control form-control-sm" id="telefono_contacto" name="telefono_contacto"
                                    value="{{ old('telefono_contacto')}}" placeholder="Teléfono de Contacto">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="direccion_asistencia">Dirección de Asistencia:</label>
                                        <input type="text" class="form-control form-control-sm" id="direccion_asistencia"
                                        name="direccion_asistencia" value="{{ old('direccion_asistencia') }}" placeholder="Dirección de Asistencia">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="cod_postal">Código Postal</label>
                                        <input type="text" class="form-control form-control-sm" id="cod_postal"
                                            name="cod_postal" value="{{ old('cod_postal') }}" placeholder="Código postal">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="Provincia">Provincia</label>
                                        <select class="form-control form-control-sm" id="provincia" name="provincia_id"
                                            placeholder="Provincia">
                                            <option value="0">Seleccionar Provincia</option>
                                            @foreach ($provincias as $provincia)
                                                <option value="{{ $provincia->id }}" @if ($provincia->id == old('provincia_id')) selected
                                            @endif>{{ $provincia->nome }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    &nbsp;
                                </div>
                                <div class="row justify-content-center">
                            
                                            <button type="submit" id="rexistrar" name = "rexistrar" value="rexistrar" class="btn btn-primary">Rexistrar Incidencia</button>                                  
                            </form>
                        </div>
                        @if ($errors->any())
                        <div class="row justify-content-start alert alert-danger col-md-6">
                            <p>Non se puido completar a acción debido ao/-s seguinte/-s erro/-s:</p>
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                            <p>Por favor, volva tentalo solventando os erros anteriores.</p>
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
 
@endsection

