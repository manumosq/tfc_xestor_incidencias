<!--VENTANA MODAL ANUNCIAR CHEGADA-->

<div class="modal fade" id="anunciar_chegada{{ $contador }}">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">CHEGADA A INCIDENCIA - {{ $incidencia->cod_inc }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row justify-content-center">
                <h6 class="text-center">Anunciar chegada a incidencia <b style="text-decoration: underline">{{ $incidencia->cod_inc }}</b> planificada para as <b style="text-decoration: underline">{{$incidencia->data_planificada_formato}}</b></h6>
                    <h6 class="text-center"></h6>
                <h6 class="text-center">¿Está seguro de que quere continuar?</h6>
                <p>&nbsp;</p>
                    </div>
                    <form method="POST" action="{{ route('anunciarChegada') }}">
                        @csrf
                        <input type="hidden" name="id" value="{{ $incidencia->id }}">
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-success">Anunciar Chegada</button>
                            &nbsp;&nbsp;&nbsp;
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>