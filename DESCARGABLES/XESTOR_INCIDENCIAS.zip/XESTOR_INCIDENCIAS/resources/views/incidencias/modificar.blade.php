<!--VENTANA MODAL MODIFICAR INCIDENCIA-->

<div class="modal fade" id="modificar{{ $contador }}">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">VER {{ $incidencia->cod_inc }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <form method="POST" id="modificar_incidencia{{ $contador }}" class = "modificar_incidencia" action="{{ route('modificarIncidencia') }}">
                        @csrf
                        <input type="hidden" name="id" value="{{ $incidencia->id }}">
                        <div class="row">
                            <h5>Datos Incidencia:</h5>
                        </div>
                        <div class="row">

                            <div class="col-md-3">
                                <label for="cod_inc_cliente">Código Incidencia Cliente:</label>
                                <input type="text" class="form-control form-control-sm" id="cod_inc_cliente"
                                    name="cod_inc_cliente" value="{{ $incidencia->cod_inc_cliente }}">
                            </div>

                            <div class="col-md-3">
                                <label for="proxecto">Proxecto:</label>
                                <select class="form-control form-control-sm" id="proxecto" name="proxecto_id">
                                    <option value="{{ $incidencia->proxectos->id }}">
                                        {{ $incidencia->proxectos->nom_proxecto }}
                                    </option>
                                    @foreach ($proxectos as $proxecto)
                                        <option value="{{ $proxecto->id }}">{{ $proxecto->nom_proxecto }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label for="peticionario">Peticionario:</label>
                                <select class="form-control form-control-sm" id="peticionario" name="peticionario_id">
                                    <option value="{{ $incidencia->peticionarios->id }}">
                                        {{ $incidencia->peticionarios->nome }}
                                        {{ $incidencia->peticionarios->primeiro_apelido }}
                                        {{ $incidencia->peticionarios->segundo_apelido }}
                                    </option>
                                    @foreach ($peticionarios as $peticionario)
                                        <option value="{{ $peticionario->id }}">{{ $peticionario->nome }}
                                            {{ $peticionario->primeiro_apelido }}
                                            {{ $peticionario->segundo_apelido }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label for="data_peticion">Data Petición:</label>
                                <input type="text" class="form-control form-control-sm" id="data_peticion"
                                    name="data_peticion" value="{{ $incidencia->data_peticion_formato }}"
                                    @if($incidencia->data_planificada != null) readonly title = "A incidencia está planificada, non se pode cambiar a data de petición"@endif>
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>

                        <div class="row">

                            <div class="col-md-12">
                                <label for="nom_incidencia">Nome Incidencia:</label>
                                <input type="text" class="form-control form-control-sm" id="nom_incidencia"
                                    name="nom_incidencia" value="{{ $incidencia->nom_incidencia }}">
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <label for="descripcion">Descripción:</label>
                                <textarea class="form-control form-control-sm" id="descripcion" name="descripcion"
                                    rows="6">{{ $incidencia->descripcion }}</textarea>
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Datos de Asistencia:</h5>
                        </div>
                        <div class="row">

                            <div class="col-md-6">
                                <label for="persoa_contacto">Persoa de Contacto:</label>
                                <input type="text" class="form-control form-control-sm" id="persoa_contacto"
                                    name="persoa_contacto" value="{{ $incidencia->persoa_contacto }}">
                            </div>
                            <div class="col-md-6">
                                <label for="telefono_contacto">Teléfono de Contacto:</label>
                                <input type="text" class="form-control form-control-sm" id="telefono_contacto"
                                    name="telefono_contacto" value="{{ $incidencia->telefono_contacto }}">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label for="direccion_asistencia">Dirección de Asistencia:</label>
                                <input type="text" class="form-control form-control-sm" id="direccion_asistencia"
                                    name="direccion_asistencia" value="{{ $incidencia->direccion_asistencia }}">
                            </div>
                            <div class="col-md-4">
                                <label for="cod_postal">Código Postal:</label>
                                <input type="text" class="form-control form-control-sm" id="cod_postal"
                                    name="cod_postal" value="{{ $incidencia->cod_postal }}">
                            </div>
                            <div class="col-md-4">
                                <label for="provincia">Provincia:</label>
                                <select class="form-control form-control-sm" id="provincia" name="provincia_id">
                                    <option value="{{ $incidencia->provincias->id }}">
                                        {{ $incidencia->provincias->nome }}
                                    </option>
                                    @foreach ($provincias as $provincia)
                                        <option value="{{ $provincia->id }}">{{ $provincia->nome }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-primary">Modificar Incidencia</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
