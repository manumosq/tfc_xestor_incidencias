<!--VENTANA MODAL PLANIFICAR INCIDENCIA-->

<div class="modal fade" id="planificar{{ $contador }}">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">PLANIFICANDO INCIDENCIA - {{ $incidencia->cod_inc }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                <form method="POST" id = "planificar_incidencia{{$contador}}" class = "planificar_incidencia" action="{{ route('planificarIncidencia') }}">
                        @csrf
                        <input type="hidden" name="id" value="{{ $incidencia->id }}">
                        <input type="hidden" name="data_peticion" value="{{ $incidencia->data_peticion }}">
                        <div class="row">
                            <h5>Datos Incidencia:</h5>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <label for="nom_incidencia">Nome Incidencia:</label>
                                <input type="text" class="form-control form-control-sm" id="nom_comercial"
                                    name="nom_comercial" value="{{ $incidencia->nom_incidencia }}"
                                    placeholder="Nome Comercial" readonly>
                            </div>
                            <div class="col-md-4">
                                <label for="nom_proxecto">Proxecto:</label>
                                <input type="text" class="form-control form-control-sm" id="nom_proxecto"
                                    name="nom_proxecto" value="{{ $incidencia->proxectos->nom_proxecto }}"
                                    placeholder="Nome Proxecto" readonly>
                            </div>
                            <div class="col-md-4">
                                <label for="provincia">Provincia:</label>
                                <input type="text" class="form-control form-control-sm" id="provincia" name="provincia"
                                    value="{{ $incidencia->provincias->nome }}" placeholder="Provincia" readonly>
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Planificación:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="data_planificada">Data Planificación:</label>
                                <input type="text" class="form-control form-control-sm" id="data_planificada"
                                    name="data_planificada" value="@if ($incidencia->data_planificada == null)@else {{ $incidencia->data_planificada_formato }} @endif" placeholder="DD/MM/AAAA HH:MM">

                                    
                            </div>
                            <div class="col-md-6">
                                <label for="tecnico_id">Técnico Asignado:</label>
                                <select class="form-control form-control-sm" id="tecnico_id"
                                    name="tecnico_id" placeholder="Técnico Asignado">
                                    @if($incidencia->tecnico_id != null)
                                        <option value="{{ $incidencia->users->id }}">{{ $incidencia->users->nome }} {{ $incidencia->users->primeiro_apelido }} {{ $incidencia->users->segundo_apelido }}</option>
                                    @else
                                    <option value="0">Seleccionar Técnico</option>
                                    @endif
                                    @foreach ($tecnicos as $tecnico)
                                        <option value="{{ $tecnico->id }}">{{ $tecnico->nome }}
                                            {{ $tecnico->primeiro_apelido }} {{ $tecnico->segundo_apelido }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-primary">Planificar Incidencia</button>

                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
