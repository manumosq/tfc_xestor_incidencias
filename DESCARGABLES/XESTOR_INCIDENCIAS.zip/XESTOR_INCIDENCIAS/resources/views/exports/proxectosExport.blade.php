<table>
    <thead>
        <tr>
            <th>Código Proxecto</th>
            <th>Nome Proxecto</th>
            <th>Cliente Responsable</th>
            <th>Data Inicio Proxecto</th>
            <th>Data Fin Proxecto</th>
        </tr>
    </thead>
    <tbody>
        @foreach($proxectos as $proxecto)
        <tr>
            <td>{{ $proxecto->cod_proxecto }}</td>
            <td>{{ $proxecto->nom_proxecto }}</td>
            <td>{{ $proxecto->clientes->nom_comercial }}</td>
            <td>{{ $proxecto->data_inicio_formato }}</td>
            <td>
                @if($proxecto->data_fin == null) EN PROCESO
                @else {{ $proxecto->data_fin_formato }}
                @endif
            </td>
        </tr>
            
        @endforeach
    </tbody>
</table>