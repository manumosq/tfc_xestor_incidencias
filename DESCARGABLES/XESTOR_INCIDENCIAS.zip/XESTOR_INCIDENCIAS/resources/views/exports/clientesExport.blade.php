<table>
    <thead>
        <tr>
            <th>Código Cliente</th>
            <th>Nome Fiscal</th>
            <th>Nome Comercial</th>
            <th>Teléfono de Contacto</th>
            <th>Email</th>
            <th>CIF</th>
            <th>Dirección</th>
            <th>Código Postal</th>
            <th>Localidade</th>
            <th>Provincia</th>

        </tr>
    </thead>
    <tbody>
        @foreach($clientes as $cliente)
        <tr>
            <td>{{ $cliente->cod_cliente }}</td>
            <td>{{ $cliente->nom_fiscal }}</td>
            <td>{{ $cliente->nom_comercial }}</td>
            <td>{{ $cliente->telefono }}</td>
            <td>{{ $cliente->email }}</td>
            <td>{{ $cliente->cif }}</td>
            <td>{{ $cliente->direccion }}</td>
            <td>{{ $cliente->cod_postal }}</td>
            <td>{{ $cliente->localidade }}</td>
            <td>{{ $cliente->provincias->nome }}</td>
        </tr>
            
        @endforeach
    </tbody>
</table>