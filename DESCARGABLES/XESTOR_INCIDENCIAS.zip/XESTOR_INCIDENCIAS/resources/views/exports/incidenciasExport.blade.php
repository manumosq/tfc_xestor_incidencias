<table>
    <thead>
        <tr>
            <th>Código Incidencia</th>
            <th>Provincia Asistencia</th>
            <th>Cliente</th>
            <th>Proxecto</th>
            <th>Técnico Asignado</th>
            <th>Data Petición</th>
            <th>Data Planificada</th>
            <th>Data Asistencia</th>
            <th>Data Finalizada</th>
            <th>Estado</th>
        </tr>
    </thead>
    <tbody>
        @foreach($incidencias as $incidencia)
        <tr>
            <td>{{ $incidencia->cod_inc }}</td>
            <td>{{ $incidencia->provincias->nome }}</td>
            <td>{{ $incidencia->proxectos->clientes->nom_comercial }}</td>
            <td>{{ $incidencia->proxectos->nom_proxecto }}</td>
            
            <td>
                @if  ($incidencia->tecnico_id == null) PENDENTE ASIGNAR 
                @else {{ $incidencia->users->nome }} {{ $incidencia->users->primeiro_apelido }} {{ $incidencia->users->segundo_apelido }}
                @endif
            </td>
            <td>{{ $incidencia->data_peticion_formato }}</td>
            <td>
                @if ($incidencia->data_planificada == null) PENDENTE
                @else {{ $incidencia->data_planificada_formato }}
                @endif
            </td>
            <td>
                @if ($incidencia->data_asistencia == null) PENDENTE
                @else {{ $incidencia->data_asistencia_formato }}
                @endif
            </td>
            <td>
                @if ($incidencia->data_finalizacion == null) PENDENTE
                @else {{ $incidencia->data_finalizacion_formato }}
                @endif
            </td>
            <td>{{ $incidencia->estados->last()->nome }}</td>
        </tr>
            
        @endforeach
    </tbody>
</table>