<table>
    <thead>
        <tr>
            <th>Nome</th>
            <th>Primeiro Apelido</th>
            <th>Segundo Apelido</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Rol</th>
        </tr>
    </thead>
    <tbody>
        @foreach($usuarios as $usuario)
        <tr>
            <td>{{ $usuario->nome }}</td>
            <td>{{ $usuario->primeiro_apelido }}</td>
            <td>{{ $usuario->segundo_apelido }}</td>
            <td>{{ $usuario->email }}</td>
            <td>{{ $usuario->telefono }}</td>
            <td>{{ $usuario->rol }}</td>
        </tr>
            
        @endforeach
    </tbody>
</table>