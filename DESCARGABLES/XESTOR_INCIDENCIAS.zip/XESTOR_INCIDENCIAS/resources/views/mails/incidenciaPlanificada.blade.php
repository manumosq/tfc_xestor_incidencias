<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
        <title>Incidencia Planificada</title>
    </head>
    <body>
    <p>Hola {{$datos['peticionario']}}, incidencia <b>PLANIFICADA:</b></p>
    <h3><u>DATOS DE PLANIFICACIÓN:</u></h3>
    <p><b><i>CÓDIGO INCIDENCIA CLIENTE:</i></b> <i>{{$datos['codigo_inc_cliente']}}</i></p>
    <p><b><i>CÓDIGO INCIDENCIA INTERNO:</i></b> <i>{{$datos['codigo_inc_interno']}}</i></p>
    <p><b><i>DATA PLANIFICADA:</i></b> <i>{{$datos['data_planificada']}}</i></p>
    <p><b><i>TÉCNICO ASIGNADO:</i></b> <i>{{$datos['tecnico_asignado']}}</i></p>
    <hr>
    <h3><u>DATOS DA INCIDENCIA:</u></h3>
    <p><b><i>DATA DE SOLICITUDE:</i></b> <i>{{$datos['data_peticion']}}</i></p> 
    <p><b><i>PROXECTO:</i></b> <i>{{$datos['proxecto']}}</i></p> 
    <h3><u>DATOS DA SOLICITUDE:</u></h3>
    <p><b><i>NOME INCIDENCIA:</i></b> <i>{{$datos['incidencia_ nome']}}</i></p> 
    <p><b><i>DESCRIPCIÓN INCIDENCIA:</i></b></p>
    <p><i>{{$datos['incidencia_ descripcion']}}</i></p> 
    <h3><u>DATOS DE CONTACTO:</u></h3>
    <p><b><i>PERSOA DE CONTACTO:</i></b> <i>{{$datos['persoa_contacto']}}</i></p> 
    <p><b><i>DIRECCIÓN DE ASISTENCIA:</i></b> <i> {{$datos['direccion_asistencia']}}</i></p> 
    <p><b><i>CÓDIGO POSTAL:</i></b> <i>{{$datos['codigo_postal']}}</i></p> 
    <p><b><i>PROVINCIA:</i></b> <i>{{$datos['provincia']}}</i></p> 


    <p>Se ten algunha dúbida contacte connosco neste mesmo email.</p>
    <p>Un saúdo,</p>   

    </body>
</html>