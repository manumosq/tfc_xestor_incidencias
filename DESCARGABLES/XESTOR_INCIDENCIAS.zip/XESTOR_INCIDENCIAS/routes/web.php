<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Models;
use App\Models\Cliente;
use App\Models\Incidencia;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*

Route::get('/', function () {
    return view('home');*/
   /*
    $clientes = Cliente::all();
    $incidencias = Incidencia::all();
    foreach($clientes as $cliente){
        echo $cliente->nom_comercial." <br/>";
        foreach($cliente->proxectos as $proxecto){
            echo $proxecto->nom_proxecto."<br/>";
            foreach($proxecto->incidencias as $incidencia){
                echo $incidencia->nom_incidencia."<br/><br/><br/>";
            }
        }
        echo "<br/>";
        

        
    }
    echo"<br/><br/>";

    //var_dump($incidencias->proxectos());
    //die;
    
    foreach($incidencias as $incidencia){
        echo $incidencia->nom_incidencia."</br>";
        echo $incidencia->proxectos->nom_proxecto."</br>";
        echo $incidencia->proxectos->clientes->nom_comercial."</br>";

        echo"<br/><br/>";
    }
    */
//});

/*Route::get('/rexistro', function (){
return view('rexistro_clientes');
});*/

Route::get('/prueba', function () {
    $incidencia = App\Models\Incidencia::find(74);
    //$estado = App\Models\Estado::find(1);
    //$incidencia->estados()->sync(2);
    //if($incidencia->estados()->id)
    //dd($incidencia->estados);
    $historicos = $incidencia->estados;
    $contador = count($historicos);
    //dd($contador);
    for ($i = 0; $i<$contador;  $i++){
        
        echo( $historicos[$i]->nome);
        echo(' -> '. $historicos[$i]["pivot"]->created_at);
        echo('<br/>');
    }
    return $historicos;

    //return $historicos[3]->updated_at;
    /*foreach($historicos as $historico ){
        return $historico->nome;
    }
    */
    //return $incidencia->estados;
});


Auth::routes();
//Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('/');
//Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


//Rutas para a Xestión de Clientes
Route::group(['middleware' =>'admin'], function(){
    route::get('/clientes', [App\Http\Controllers\ClienteController::class, 'listar'])->name('listadoClientes');
    route::get('/rexistrarcliente', [App\Http\Controllers\ClienteController::class, 'rexistro'])->name('rexistrarCliente');
    route::post('/clientes/novo', [App\Http\Controllers\ClienteController::class, 'rexistrar'])->name('novoCliente');
    route::post('/clientes/modificar', [App\Http\Controllers\ClienteController::class, 'modificar'])->name('modificarCliente');
    route::post('/clientes/eliminar', [App\Http\Controllers\ClienteController::class, 'eliminar'])->name('eliminarCliente');
    route::get('/clientes/exportar', [App\Http\Controllers\ClienteController::class, 'exportarClientes'])->name('exportarClientes');
});



//Rutas para a xestión de Proxectos
Route::group(['middleware' =>'admin'], function(){
    route::get('/proxectos', [\App\Http\Controllers\ProxectoController::class, 'listar'])->name('listadoProxectos');
    route::post('/proxectos/modificar', [App\Http\Controllers\ProxectoController::class, 'modificar'])->name('modificarProxecto');
    route::post('/proxectos/eliminar', [App\Http\Controllers\ProxectoController::class, 'eliminar'])->name('eliminarProxecto');
    route::post('/proxectos/novo', [App\Http\Controllers\ProxectoController::class, 'rexistrar'])->name('crearProxecto');
    route::get('/proxectos/exportar', [App\Http\Controllers\ProxectoController::class, 'exportarProxectos'])->name('exportarProxectos');
});
//Rutas para a xestión de Estados
Route::group(['middleware' =>'admin'], function(){
    route::get('/estados', [\App\Http\Controllers\EstadoController::class, 'listar'])->name('listadoEstados');
    route::post('/estados/eliminar', [App\Http\Controllers\EstadoController::class, 'eliminar'])->name('eliminarEstado');
    route::post('/estados/novo', [App\Http\Controllers\EstadoController::class, 'crear'])->name('crearEstado');
});

//Rutas para a xestión de Peticionarios
Route::group(['middleware' =>'admin'], function(){
    route::get('/peticionarios', [\App\Http\Controllers\PeticionarioController::class, 'listar'])->name('listadoPeticionarios');
    route::post('/peticionarios/modificar', [App\Http\Controllers\PeticionarioController::class, 'modificar'])->name('modificarPeticionario');
    route::post('/peticionarios/eliminar', [App\Http\Controllers\PeticionarioController::class, 'eliminar'])->name('eliminarPeticionario');
    route::post('/peticionarios/novo', [App\Http\Controllers\PeticionarioController::class, 'rexistrar'])->name('crearPeticionario');
});

//Rutas para a xestión de Incidencias
Route::group(['middleware' =>'admin'], function(){
    route::get('/incidencias', [\App\Http\Controllers\IncidenciaController::class, 'listar'])->name('listadoIncidencias');
    route::get('/rexistroincidencia', [App\Http\Controllers\IncidenciaController::class, 'rexistro'])->name('formRexistroIncidencia');
    route::post('/rexistrarincidencia', [App\Http\Controllers\IncidenciaController::class, 'rexistrar'])->name('rexistrarIncidencia');
    route::post('/incidencias/planificar', [App\Http\Controllers\IncidenciaController::class, 'planificar'])->name('planificarIncidencia');
    route::post('/incidencias/modificar', [App\Http\Controllers\IncidenciaController::class, 'modificar'])->name('modificarIncidencia');
    route::post('/incidencias/cancelar', [App\Http\Controllers\IncidenciaController::class, 'cancelarIncidencia'])->name('cancelarIncidencia');
    route::get('/incidencias/exportar', [App\Http\Controllers\IncidenciaController::class, 'exportarIncidencias'])->name('exportarIncidencias');
});

//Rutas para a xestión de Usuarios
Route::group(['middleware' =>'admin'], function(){
    route::get('/usuarios', [\App\Http\Controllers\UserController::class, 'listar'])->name('listadoUsuarios');
    route::post('/usuarios/novo', [App\Http\Controllers\UserController::class, 'rexistrar'])->name('crearUsuario');
    route::post('/usuarios/modificar', [App\Http\Controllers\UserController::class, 'modificar'])->name('modificarUsuario');
    route::post('/usuarios/eliminar', [App\Http\Controllers\UserController::class, 'eliminar'])->name('eliminarUsuario');
    route::get('/usuarios/exportar', [App\Http\Controllers\UserController::class, 'exportarUsuarios'])->name('exportarUsuarios');

});
//Rutas vistas home

    route::get('/', [\App\Http\Controllers\IncidenciaController::class, 'listarHome'])->name('home');
    route::post('/incidencias/chegada', [App\Http\Controllers\IncidenciaController::class, 'anunciarChegada'])->name('anunciarChegada');
    route::post('/incidencias/finalizacion', [App\Http\Controllers\IncidenciaController::class, 'anunciarFinalizacion'])->name('anunciarFinalizacion');

