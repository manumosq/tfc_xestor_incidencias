<?php

namespace App\Exports;

use App\Models\Incidencia;
use App\Models\Proxecto;
use App\Models\Provincia;
use App\Models\User;
use App\Models\Estado;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;


class IncidenciasExport implements FromView
{
    /**
    * @return \Illuminate\Support\Collection
    */

    public function view(): View
    {
        return view('exports.incidenciasExport', [
            'incidencias'=>Incidencia::get(),
            'proxectos'=>Proxecto::get(),
            'provincias'=>Provincia::get(),
            'users'=>User::get(),
            'estados'=>Estado::get()
        ]);
    }    
}