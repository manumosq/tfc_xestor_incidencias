<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Models\Incidencia;

class IncidenciaRexistrada extends Mailable
{
    use Queueable, SerializesModels;

   public $datos;

    /**
     * Create a new message instance.
     *
     * @return void
     */

    //Pasamos a variable ao constructor
    
    public function __construct($datos)
    {
        //dd($datos);
       $this->datos = $datos;
       
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        
        return $this->view('mails.incidenciaRexistrada');
    }
}
