<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PeticionarioRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nome' => 'required|string|max:20',
            'primeiro_apelido' => 'required|string|max:20',
            'segundo_apelido' => 'required|string|max:20',
            'telefono' => 'nullable|numeric|digits:9',
            'email' => 'required|max:50|email:filter',
        ];
    }
    public function messages()
    {
        return[
            'nome.required' => 'O campo Nome non pode estar baleiro.',
            'nome.max' => 'O campo Nome non pode sobrepasar os 20 caracteres.',
            'primeiro_apelido.required' => 'O campo Primeiro Apelido non pode estar baleiro.',
            'primeiro_apelido.max' => 'O campo Primeiro Apelido non pode sobrepasar os 20 caracteres.',
            'segundo_apelido.required' => 'O campo Segundo Apelido non pode estar baleiro.',
            'segundo_apelido.max' => 'O campo Segundo Apelido non pode sobrepasar os 20 caracteres.',
            'email.required' => 'O campo email non pode estar baleiro.',
            'email.email' => 'O email debe ser correcto.',
            'email.max' => 'O campo Nome non pode sobrepasar os 50 caracteres.',
            'telefono.numeric' => 'O campo Teléfono deben ser números.',
            'telefono.digits' => 'O campo Teléfono ten que ter 9 díxitos.',
        ];
    }
}
