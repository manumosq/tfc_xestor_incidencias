<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ClienteRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Obén as reglas de validación que se aplican na solicitude.
     *
     * @return array
     */
    public function rules()
    {
       //OLLO, o campo CIF ten que ser único, polo que hai que contemplalo á hora de mofificar ($this->id).
        return [
            'nom_fiscal' => 'required|string|max:50',
            'nom_comercial' => 'required|string|max:50',
            'cif' => 'required|string|max:9|unique:clientes,cif,'.$this->id,
            'direccion' => 'required|string|max:50',
            'cod_postal'=>'required|numeric|digits:5',
            'localidade' => 'required|string|max:50',
            'provincia_id' => 'required|gt:0',
            'telefono'=>'required|numeric|digits:9',
            'email' => 'required|max:50|email:filter',
        ];
    }

        /**
     * Obén as mensaxes de validación que se aplican na solicitude.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'nom_fiscal.required' => 'O campo Nome Fiscal non pode estar baleiro.',
            'nom_fiscal.max' => 'O campo Nome fiscal non pode sobrepasar os 50 caracteres',            
            'nom_comercial.required' => 'O campo Nome Comercial non pode estar baleiro.',
            'nom_comercial.max' => 'O campo Nome Comercial non pode sobrepasar os 50 caracteres.',
            'cif.required' => 'O campo CIF non pode estar baleiro.',
            'cif.max' => 'O campo CIF non pode sobrepasar os 9 caracteres.',
            'cif.unique' => 'O campo CIF xa existe na base de datos, por favor, verifique que é correcto.',
            'direccion.required' => 'O campo Dirección non pode estar baleiro.',
            'direccion.max' => 'O campo Dirección non pode sobrepasar os 50 caracteres.',
            'cod_postal.required' => 'O campo Código Postal non pode estar baleiro.',
            'cod_postal.numeric' => 'O campo Código Postal debe estar composto por 5 caracteres numéricos.',
            'cod_postal.digits'=>'O campo Código Postal debe estar composto por 5 caracteres numéricos.',
            'localidade.required' => 'O campo Localidade non pode estar baleiro.',
            'localidade.max' => 'O campo Localidade non pode sobrepasar os 50 caracteres.',
            'provincia_id.required' => 'Ten que seleccionar ao menos unha provincia.',
            'provincia_id.gt' => 'Ten que seleccionar ao menos unha provincia',
            'telefono.required' => 'O campo telefono non pode estar baleiro.',
            'telefono.numeric' => 'O campo teléfono debe ter 9 díxitos numéricos.',
            'telefono.digits' => 'O campo teléfono debe ter 9 díxitos numéricos',          
            'email.required' => 'O camo email non pode estar baleiro.',            
            'email.max' => 'O campo email non pode sobrepasar os 50 caracteres.',
            'email.email'=>'Por favor, introduza un mail correcto'
        ];
    }
}
