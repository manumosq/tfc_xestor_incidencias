<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class IncidenciaPlanificarRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'data_planificada' => 'required|after:data_peticion|date_format:d/m/Y H:i',
            'tecnico_id' => 'required|gt:0'
        ];
    }
    public function messages()
    {
        return [
            'data_planificada.required' => 'O campo Data Planificación non pode estar baleiro.',
            'data_planificada.date_format' => 'Ten que indicar unha data e a hora da petición correcta en formato dd/mm/aaaa HH:MM.',
            'data_planificada.after' => 'A data de planificación non pode ser anterior á de petición.',
            'tecnico_id.required' => 'Ten que seleccionar un técnico.',
            'tecnico_id.gt' => 'Ten que seleccionar un técnico.'
        ];
    }
}
