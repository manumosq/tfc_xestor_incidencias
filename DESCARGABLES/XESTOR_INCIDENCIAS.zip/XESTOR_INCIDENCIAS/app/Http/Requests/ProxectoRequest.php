<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProxectoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nom_proxecto' => 'required|string|max:50',
            'cliente_id' => 'required|gt:0',
            'data_inicio' => 'required|date',
            'data_fin' => 'nullable|date|after:data_inicio'
        ];
    }
    public function messages()
    {
        return[
            'nom_proxecto.required' => 'O campo Nome Proxecto non pode estar baleiro.',
            'nom_proxecto.max' => 'O campo Nome Proxecto non pode sobrepasar os 50 caracteres.',
            'cliente_id.required' => 'Ten que seleccionar un cliente.',
            'cliente_id.gt' => 'Ten que seleccionar un cliente',
            'data_inicio.required' => 'O campo Data Inicio non pode estar baleiro.',
            'data_inicio.date' => 'O campo Data Inicio ten que ser unha data.',
            'data_fin.date' => 'O campo Data Fin ten que ser unha data.',
            'data_fin.after' => 'A data de fin non pode ser anterior á de inicio.',
        ];
    }
}