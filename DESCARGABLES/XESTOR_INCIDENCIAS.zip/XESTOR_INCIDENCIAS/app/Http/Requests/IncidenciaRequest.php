<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class IncidenciaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'cod_inc_cliente' => 'nullable|string|max:20',
            'proxecto_id' => 'required|gt:0',
            'peticionario_id' => 'required|gt:0',
            'data_peticion' => 'required|date_format:d/m/Y H:i',
            'nom_incidencia' => 'required|string|max:50',
            'descripcion' => 'nullable|string',
            'persoa_contacto' => 'required|string|max:20',
            'telefono_contacto' => 'required|numeric|digits:9',
            'direccion_asistencia' => 'required|string|max:50',
            'cod_postal' => 'required|numeric|digits:5',
            'provincia_id' => 'required|gt:0',
        ];
    }

    public function messages()
    {
        return[
            'cod_inc_cliente.max' => 'O tamaño máximo do campo Código Incidencia Cliente son 20 caracteres.',
            'proxecto_id.required' => 'Ten que seleccionar ao menos un proxecto.',
            'proxecto_id.gt' => 'Ten que seleccionar ao menos un proxecto.',
            'peticionario_id.required' => 'Ten que seleccionar ao menos un peticionario.',
            'peticionario_id.gt' => 'Ten que seleccionar ao menos un peticionario.',
            'data_peticion.required' => 'O campo Data da Petición non pode estar baleiro.',
            'data_peticion.date_format' => 'Ten que indicar unha data e a hora da petición correcta en formato dd/mm/aaaa HH:MM.',
            'nom_incidencia.required' => 'O campo Nome Incidencia non pode estar baleiro.',
            'nom_incidencia.max' => 'O tamaño máximo do campo Nome Incidencia son 50 caracteres.',
            'persoa_contacto.required' => 'O campo Persoa de Contacto non pode estar baleiro.',
            'persoa_contacto.max' => 'O tamaño máximo do campo Persoa de Contacto son 20 caracteres.',
            'telefono_contacto.required' => 'O campo Teléfono de Contacto non pode estar baleiro.',
            'telefono_contacto.numeric' => 'O campo Teléfono de Contacto deben ser 9 números.',
            'telefono_contacto.digits' => 'O campo Teléfono de Contacto deben ser 9 números.',
            'direccion_asistencia.required' => 'O campo Dirección de Asistencia non pode estar baleiro.',
            'direccion_asistencia_max' => 'O tamaño máximo do campo Dirección de Asistencia son 50 caracteres.',
            'cod_postal.required' => 'O campo Código Postal non pode estar baleiro.',
            'cod_postal.numeric' => 'O campo Código Postal debe estar composto por 5 números.',
            'cod_postal.digits' => 'O campo Código Postal debe estar composto por 5 números',
            'provincia_id.required' => 'Ten que seleccionar ao menos unha provincia',
            'provincia_id.gt' => 'Ten que seleccionar ao menos unha provincia'
        ];
    }
}
