<?php

namespace App\Http\Controllers;

use App\Exports\UsersExport;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use App\Models\Incidencia;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Validation\Rule;
use App\Http\Requests\UserRequest;



class UserController extends Controller
{

    //Engadimos o middleware para que non se poida accede a menos que estemos autenticados.
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Método que recibe como parámetros os campos do formulario de rexistro de usuairos,
     * valídaos e se son correctos insértaos na base de datos.
     * 
     * @param Request Recibe os datos do formulario de rexistro de usuarios e valídaos.
     * @return redirect Redirixe á páxina listado de usuarios (no caso de que se validen os datos insertados) pasándolle unha mensaxe de éxito.
     */
    public function rexistrar(UserRequest $request)
    {

        //Obtemos datos do formulario
        $nome = $request->input('nome');
        $primeiro_apelido = $request->input('primeiro_apelido');
        $segundo_apelido = $request->input('segundo_apelido');
        $email = $request->input('email');
        $telefono = $request->input('telefono');
        $rol = $request->input('rol');
        $password = Hash::make($request->input('password'));

        //Gardamos os datos obtidos na base de datos
        $usuario = new User();

        $usuario->nome = $nome;
        $usuario->primeiro_apelido = $primeiro_apelido;
        $usuario->segundo_apelido = $segundo_apelido;
        $usuario->email = $email;
        $usuario->telefono = $telefono;
        $usuario->rol = $rol;
        $usuario->password = $password;

        $usuario->save();

        //Voltamos á páxina de usuarios e pasamos unha mensaxe de éxito.
        return redirect()->route('listadoUsuarios')->with(['mensaxe' => 'Novo usuario creado correctamente']);
    }

    /**
     * Método que recibe como parámetro os campos do buscador e devolve a táboa
     * de resultados en forma de listado de usuarios.
     * 
     * No caso de que non haxa campos para buscar/filtrar devolve tódolos resultados.
     * 
     * @param Request Recibe os datos do formulario de búsqueda de usuarios.
     * @return view Devolve a vista de listado de usuarios pasándolle as variables usuarios e contador necesarias para mostrar os datos.
     */
    public function listar(Request $request)
    {
        //Creamos as variables contador e usuarios que pasaremos á vista para mostrar as ventás modais e facer os select de clientes.
        $usuarios = User::all()->sortBy('nome');
        $contador = 0;


        //Obtemos os parámetros de formulario de búsqueda para filtrar por eles.

        $nome = $request->get('nome');
        $primeiro_apelido = $request->get('primeiro_apelido');
        $segundo_apelido = $request->get('segundo_apelido');

        /*
        Aplicamos os métodos scope que definimos no modelo para facer o filtrado de usuarios por campos.
        OLLO os métodos scope chámanse sen indicar "scope diante", é dicir, o método scope
        para filtrar por Primeiro Apelido é scopePrimeiroApelido($query, $primeiro_apelido), nos só indicamos PrimeiroApelido($primeiro_apelido)
        */

        $usuarios = User::NomUsuario($nome)
            ->PrimeiroApelido($primeiro_apelido)
            ->SegundoApelido($segundo_apelido)
            ->paginate(9);

        //Devolvemos a vista listar (da carpeta usuarios) pasándolle como variables usuarios e contador.
        return view('usuarios.listar')->with(compact('usuarios', 'contador'));
    }


    /**
     * Método que recibe como parámetro os campos do formulario de modificación de usuarios,
     * valídaos e se son correctos realiza o update da base de datos.
     * Devole unha táboa de resultados en forma de listado de usuarios.
     * 
     * @param Request Recibe os datos do formulario de modificación de usuarios.
     * @return redirect Redirixe á páxina listadoUsuarios (no caso de que se validen os datos insertados) pasándolle unha mensaxe de éxito.
     */
    public function modificar(UserRequest $request)
    {
        //Datos obtidos do formulario
        $id = $request->input('id');
        $nome = $request->input('nome');
        $primeiro_apelido = $request->input('primeiro_apelido');
        $segundo_apelido = $request->input('segundo_apelido');
        $email = $request->input('email');
        $telefono = $request->input('telefono');
        $rol = $request->input('rol');
        $password = Hash::make($request->input('password'));


        //Obtemos o tecnico que queremos modificar
        $usuario = User::find($id);

        //Asignamos novos valores ao obxeto usuario
        $usuario->nome = $nome;
        $usuario->primeiro_apelido = $primeiro_apelido;
        $usuario->segundo_apelido = $segundo_apelido;
        $usuario->email = $email;
        $usuario->telefono = $telefono;
        $usuario->rol = $rol;
        $usuario->password = $password;

        $usuario->update();

        //Accedemos á páxina de listado de usuarios e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoUsuarios')->with(['mensaxe' => 'Usuario modificado correctamente']);
    }

    /**
     * Método que recibe como parámetro o id do usuario a eliminar,
     * comproba se se pode borrar e, se se pode borrar mostra unha mensaxe de éxito.
     * 
     * @param Request Recibe o id do usuario a eliminar.
     * @return  redirect Redirixe á páxina listadoUsuarios (no caso de que se valide que o usuario se pode eliminar) pasándolle unha mensaxe de éxito.
     */
    public function eliminar(Request $request)
    {
        //Obtemos o ID de usuario que queremos eliminar
        $id = $request->input('id');

        $usuario = User::find($id);
        $incidencias = Incidencia::all();

        //Comprobamos se o usuario ten incidencias asignadas, de ser así mostraremos unha mensaxe indicando que non se pode borrar.
        if (count($incidencias->where('tecnico_id', '=', $id)) > 0) {
            return redirect()->route('listadoUsuarios')->withErrors(array('message' => 'Non se pode eliminar o usuario xa que ten incidencias asignadas.'));
        }

        //Se todo foi ben borramos o usuario da base de datos.
        $usuario->delete();
        //Accedemos á páxina de listado de usuarios e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoUsuarios')->with(['mensaxe' => 'Usuario eliminado correctamente']);
    }

    /**
     * Método que exporta e descarga un listado de usuarios en formato xslx
     *
     * @return Descarga_documento
     */
    public function exportarUsuarios()
    {
        return Excel::download(new UsersExport, 'usuarios.xlsx');
    }
}
