<?php

namespace App\Http\Controllers;

use App\Exports\ProxectosExport;
use App\Http\Controllers\Controller;
use App\Models\Cliente;
use App\Models\Proxecto;
use App\Models\Incidencia;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\ProxectoRequest;

class ProxectoController extends Controller
{

    //Engadimos o middleware para que non se poida acceder a menos que estemos autenticados.    
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Método que recibe como parámetro os campos do buscador e devolve a táboa
     * de resultados en forma de listado de proxectos.
     * 
     * No caso de que non haxa campos para buscar/filtrar devolve tódolos resultados.
     * 
     * @param Request Recibe os datos do formulario de busqueda de proxectos.
     * @return view Devolve a vista de listado de proxectos pasándolle as variables clientes, proxectos e contador necesarias para mostrar os datos.
     */
    public function listar(Request $request)
    {
        //Creamos as variables contador e clientes que pasaremos á vista para mostrar as ventás modais e facer os select de clientes.
        $clientes = Cliente::all()->sortBy('nome');
        $contador = 0;

        //Obtemos os parámetros do formulario de búsqueda para filtrar por eles.

        $nom_proxecto = $request->get('nom_proxecto');
        $cliente = $request->get('cliente_id');
        $estado = $request->get('estado');

        /*
        Aplicamos os métodos scope que definimos no modelo para facer o filtrado de proxectos por campos.
        OLLO os métodos scope chámanse sen indicar "scope diante", é dicir, o método scope
        para filtrar por cliente é scopeClientes($query, $cliente), nos só indicamos cliente($cliente)
        */

        $proxectos = Proxecto::NomProxecto($nom_proxecto)
            ->cliente($cliente)
            ->estado($estado)
            ->paginate(9);

        //Devolvemos a vista listar (da carpeta proxectos) pasándolle como variables proxectos, clientes e contador para que poida mostrar os datos.
        return view('proxectos.listar')->with(compact('proxectos', 'clientes', 'contador'));
    }


    /**
     * Método que recibe como parámetro os campos do formulario de modificación de proxectos,
     * valídaos e se son correctos realiza o update da base de datos.
     * Devolve unha táboa de resultados en forma de listado de proxectos.
     * 
     * @param Request Recibe os datos do formulario de modificación de proxectos.
     * @return  redirect Redirixe á páxina listadoProxectos (no caso de que se validen os datos insertados) pasándolle unha mensaxe de éxito.
     */
    public function modificar(ProxectoRequest $request)
    {
        //Datos obtidos do formulario
        $id = $request->input('id');
        $nom_proxecto = $request->input('nom_proxecto');
        $cliente = $request->input('cliente_id');
        $data_inicio = $request->input('data_inicio');
        $data_fin = $request->input('data_fin');

        //Obtemos o cliente que queremos modificar
        $proxecto = Proxecto::find($id);

        //Asignamos novos valores ao obxeto proxecto e actualizamos os datos.
        $proxecto->nom_proxecto = $nom_proxecto;
        $proxecto->cliente_id = $cliente;
        $proxecto->data_inicio = $data_inicio;
        $proxecto->data_fin = $data_fin;

        $proxecto->update();

        //Accedemos á páxina de listado de proxectos e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoProxectos')->with(['mensaxe' => 'Proxecto modificado correctamente']);
    }

    /**
     * Método que recibe como parámetro o id do proxecto a eliminar,
     * comproba se se pode borrar e, se se pode borrar mostra unha mensaxe de éxito.
     * 
     * @param Request Recibe o id do cliente a eliminar.
     * @return  redirect Redirixe á páxina listadoProxectos (no caso de que se valide que o proxecto se pode eliminar) pasándolle unha mensaxe de éxito.
     */
    public function eliminar(Request $request)
    {
        //Obtemos o ID de proxecto que queremos eliminar
        $id = $request->input('id');

        $proxecto = Proxecto::find($id);
        $incidencias = Incidencia::all();

        //Comprobamos se o proxecto ten incidencias asociadas, de ser así mostraremos unha mensaxe indicando que non se pode borrar.
        if (count($incidencias->where('proxecto_id', '=', $id)) > 0) {
            return redirect()->route('listadoProxectos')->withErrors(array('message' => 'Non se pode eliminar o proxecto xa que ten incidencias asignadas.'));
        }

        //Se todo foi ben borramos o proxecto da base de datos.

        $proxecto->delete();
        //Accedemos á páxina de listado de proxectos e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoProxectos')->with(['mensaxe' => 'Proxecto eliminado correctamente']);
    }

    /**
     * Método que recibe os campos do formulario de rexistro de proxectos, 
     * valídaos e se son correctos insértaos na base de datos.
     * 
     * @param Request Recibe os datos do formulario de rexistro de proxectos e valídaos.
     * @return redirect Redirixe á páxina listadoProxectos (no caso de que se validen os datos insertados) pasándolle unha mensaxe de éxito.
     */
    public function rexistrar(ProxectoRequest $request)
    {

        //Obtemos datos do formulario
        $nom_proxecto = $request->input('nom_proxecto');
        $cliente_id = $request->input('cliente_id');
        $data_inicio = $request->input('data_inicio');
        $data_fin = $request->input('data_fin');

        //Gardamos os datos obtidos na base de datos
        $proxecto = new Proxecto();

        $proxecto->nom_proxecto = $nom_proxecto;
        $proxecto->cliente_id = $cliente_id;
        $proxecto->data_inicio = $data_inicio;
        $proxecto->data_fin = $data_fin;

        $proxecto->save();

        //Voltamos á páxina de proxectos e pasamos unha mensaxe de éxito.
        return redirect()->route('listadoProxectos')->with(['mensaxe' => 'Novo proxecto creado correctamente']);
    }

    /**
     * Método que exporta e descarga un listado de proxectos en formato xslx
     *
     * @return Descarga_documento
     */
    public function exportarProxectos()
    {
        return Excel::download(new ProxectosExport, 'proxectos.xlsx');
    }
}
