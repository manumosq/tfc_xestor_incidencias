<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Peticionario;
use App\Models\Incidencia;
use App\Http\Requests\PeticionarioRequest;

class PeticionarioController extends Controller
{
    //Engadimos o middleware para que non se poida acceder a menos que estemos autenticados.    
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Método que recibe como parámetro os campos do buscador e devolve a táboa
     * de resultados en forma de listado de peticionarios.
     * 
     * No caso de que non haxa campos para buscar/filtrar devolve tódolos resultados.
     * 
     * @param Request Recibe os datos do formulario de búsqueda de peticionarios.
     * @return view Devolve a vista de listado de peticionarios pasándolle as variables peticionarios e contador necesarias para mostrar os datos.
     */
    public function listar(Request $request)
    {
        //Creamos as variables contador e peticionarios que pasaremos á vista para mostrar as ventás modais e facer os select de clientes.
        $peticionarios = Peticionario::all()->sortBy('nome');
        $contador = 0;

        //Obtemos os parámetros do formulario de búsqueda para filtrar por eles.

        $nome = $request->get('nome');
        $primeiro_apelido = $request->get('primeiro_apelido');
        $segundo_apelido = $request->get('segundo_apelido');

        /*
        Aplicamos os métodos scope que definimos no modelo para facer o filtrado de peticionarios por campos.
        OLLO os métodos scope chámanse sen indicar "scope diante", é dicir, o método scope
        para filtrar por Primeiro Apelido é scopePrimeiroApelido($query, $primeiro_apelido), nos só indicamos PrimeiroApelido($primeiro_apelido)
        */

        $peticionarios = Peticionario::NomPeticionario($nome)
            ->PrimeiroApelido($primeiro_apelido)
            ->SegundoApelido($segundo_apelido)
            ->paginate(9);

        //Devolvemos a vista listar (da carpeta peticionarios) pasándolle como variables peticionarios e contador.
        return view('peticionarios.listar')->with(compact('peticionarios', 'contador'));
    }

    /**
     * Método que recibe como parámetro os campos do formulario de modificación de peticionarios,
     * valídaos e se son correctos realiza o update da base de datos.
     * Devole unha táboa de resultados en forma de listado de peticionarios.
     * 
     * @param Request Recibe os datos do formulario de modificación de peticionarios.
     * @return void Redirixe á páxina listadoPeticionarios (no caso de que se validen os datos insertados) pasándolle unha mensaxe de éxito
     */
    public function modificar(PeticionarioRequest $request)
    {
        //Datos obtidos do formulario
        $id = $request->input('id');
        $nome = $request->input('nome');
        $primeiro_apelido = $request->input('primeiro_apelido');
        $segundo_apelido = $request->input('segundo_apelido');
        $telefono = $request->input('telefono');
        $email = $request->input('email');


        //Obtemos o peticionario que queremos modificar
        $peticionario = Peticionario::find($id);

        //Asignamos novos valores ao obxeto peticionario
        $peticionario->nome = $nome;
        $peticionario->primeiro_apelido = $primeiro_apelido;
        $peticionario->segundo_apelido = $segundo_apelido;
        $peticionario->telefono = $telefono;
        $peticionario->email = $email;

        $peticionario->update();

        //Accedemos á páxina de listado de peticionarios e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoPeticionarios')->with(['mensaxe' => 'Peticionario modificado correctamente']);
    }

    /**
     * Método que recibe como parámetro o id do peticionario a eliminar,
     * comproba se se pode borrar e, se se pode borrar mostra unha mensaxe de éxito.
     * 
     * @param Request Recibe o id do peticionario a eliminar.
     * @return  redirect Redirixe á páxina listadoPeticionarios (no caso de que se valide que o peticionario se pode eliminar) pasándolle unha mensaxe de éxito.
     */
    public function eliminar(Request $request)
    {
        //Obtemos o ID de proxecto que queremos eliminar
        $id = $request->input('id');

        $peticionario = Peticionario::find($id);
        $incidencias = Incidencia::all();

        //Comprobamos se o peticionario ten incidencias asignadas, de ser así mostraremos unha mensaxe indicando que non se pode borrar.
        if (count($incidencias->where('peticionario_id', '=', $id)) > 0) {
            return redirect()->route('listadoPeticionarios')->withErrors(array('message' => 'Non se pode eliminar o peticionario xa que ten incidencias asignadas.'));
        }

        $peticionario->delete();
        //Accedemos á páxina de listado de clientes e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoPeticionarios')->with(['mensaxe' => 'Peticionario eliminado correctamente']);
    }

    /**
     * Método que recibe como parámetros os campos do formulario de rexistro de peticionarios,
     * valídaos e se son correctos insértaos na base de datos.
     * 
     * @param Request Recibe os datos do formulario de rexistro de peticionarios.
     * @return redirect Redirixe á páxina listado de peticionarios (no caso de que se validen os datos insertados) pasándolle unha mensaxe de éxito.
     */
    public function rexistrar(PeticionarioRequest $request)
    {

        //Obtemos datos do formulario
        $nome = $request->input('nome');
        $primeiro_apelido = $request->input('primeiro_apelido');
        $segundo_apelido = $request->input('segundo_apelido');
        $telefono = $request->input('telefono');
        $email = $request->input('email');

        //Gardamos os datos obtidos na base de datos
        $peticionario = new Peticionario();

        $peticionario->nome = $nome;
        $peticionario->primeiro_apelido = $primeiro_apelido;
        $peticionario->segundo_apelido = $segundo_apelido;
        $peticionario->telefono = $telefono;
        $peticionario->email = $email;

        $peticionario->save();

        //Voltamos á páxina de peticionarios e pasamos unha mensaxe de éxito.
        return redirect()->route('listadoPeticionarios')->with(['mensaxe' => 'Novo peticionario creado correctamente']);
    }
}
