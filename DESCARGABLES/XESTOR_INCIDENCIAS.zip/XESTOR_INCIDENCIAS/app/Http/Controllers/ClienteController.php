<?php

namespace App\Http\Controllers;

use App\Exports\ClientesExport;
use App\Http\Controllers\Controller;
use App\Models\Provincia;
use App\Models\Cliente;
use App\Models\Proxecto;
use Facade\FlareClient\Http\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\ClienteRequest;

class ClienteController extends Controller
{

    //Engadimos o middleware para que non se poida acceder a menos que estemos autenticados.    
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Método que devolve a vista de rexistro de usuarios.
     * Definimos as variables necesarias para a vista.
     * Pasámoslle as variables necesarias á vista con (->with(compact('nombreVariable'))
     *
     * @return view
     */

    public function rexistro()
    {
        $provincias = Provincia::all()->sortBy('nome');
        return view('clientes.rexistrar')->with(compact('provincias'));
    }

    /**
     * Método que recibe os campos do formulario de rexistro de clientes, 
     * valídaos e se son correctos insértaos na base de datos.
     * 
     * @param Request Recibe os datos do formulario de rexistro de clientes a través de ClienteRequest, clase que creamos para validar xa os datos.
     * @return redirect Redirixe á páxina listadoClientes (no caso de que se validen os datos insertados) pasándolle unha mensaxe de éxito.
     */

    public function rexistrar(ClienteRequest $request)
    {

        //Datos obtidos do formulario
        $nom_fiscal = $request->input('nom_fiscal');
        $nom_comercial = $request->input('nom_comercial');
        $cif = $request->input('cif');
        $direccion = $request->input('direccion');
        $cod_postal = $request->input('cod_postal');
        $localidade = $request->input('localidade');
        $provincia = $request->input('provincia_id');
        $telefono = $request->input('telefono');
        $email = $request->input('email');

        //Gardamos os datos obtidos na base de datos.

        $cliente = new Cliente();

        $cliente->nom_fiscal = $nom_fiscal;
        $cliente->nom_comercial = $nom_comercial;
        $cliente->cif = $cif;
        $cliente->direccion = $direccion;
        $cliente->cod_postal = $cod_postal;
        $cliente->localidade = $localidade;
        $cliente->provincia_id = $provincia;
        $cliente->telefono = $telefono;
        $cliente->email = $email;

        $cliente->save();

        //Accedemos á páxina de listado de clientes e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoClientes')->with(['mensaxe' => 'Novo cliente creado correctamente']);
    }


    /**
     * Método que recibe como parámetro os campos do buscador e devolve a táboa
     * de resultados en forma de listado de clientes.
     * 
     * No caso de que non haxa campos para buscar/filtrar devolve tódolos resultados.
     * 
     * @param Request Recibe os datos do formulario de busqueda de clientes.
     * @return view Devolve a vista de listado de clientes pasándolle as variables clientes, contador e provincias necesarias para mostrar os datos.
     */

    public function listar(Request $request)
    {
        //Creamos as variables contador e provincias que pasaremos á vista para mostrar as ventás modais e facer os select de provincias.
        $contador = 0;
        $provincias = Provincia::all()->sortBy('nome');


        //Obtemos os parámetros do formulario de búsqueda para filtrar por eles.

        $nom_comercial = $request->get('nom_comercial');
        $email = $request->get('email');
        $provincia = $request->get('provincia_id');

        /*
        Aplicamos os métodos scope que definimos no modelo para facer o filtrado de por campos.
        OLLO os métodos scope chámanse sen indicar "scope diante", é dicir, o método scope
        para filtrar por email é scopeEmail($query, $email), nos só indicamos email($email)
        */

        $clientes = Cliente::NomComercial($nom_comercial)
            ->email($email)
            ->provincia($provincia)
            ->paginate(9);

        //Devolvemos a vista listado (da carpeta clientes) pándolle como variables clientes, contador e provincias para que poida mostrar os datos.
        return view('clientes.listado')->with(compact('clientes', 'contador', 'provincias'));
    }

    /**
     * Método que recibe como parámetro os campos do formulario de modificación de clientes,
     * valídaos e se son correctos realiza o update da base de datos.
     * Devolve unha táboa de resultados en forma de listado de clientes.
     * 
     * @param Request Recibe os datos do formulario de modificación de clientes a través de ClienteRequest, clase que creamos para validar xa os datos.
     * @return  redirect Redirixe á páxina listadoClientes (no caso de que se validen os datos insertados) pasándolle unha mensaxe de éxito.
     */

    public function modificar(ClienteRequest $request)
    {

        //Datos obtidos do formulario
        $id = $request->input('id');
        $nom_fiscal = $request->input('nom_fiscal');
        $nom_comercial = $request->input('nom_comercial');
        $cif = $request->input('cif');
        $direccion = $request->input('direccion');
        $cod_postal = $request->input('cod_postal');
        $localidade = $request->input('localidade');
        $provincia = $request->input('provincia_id');
        $telefono = $request->input('telefono');
        $email = $request->input('email');

        //Obtemos o cliente que queremos modificar

        $cliente = Cliente::find($id);


        //Asignamos novos valores ao obxeto cliente e actualizámolo
        $cliente->nom_fiscal = $nom_fiscal;
        $cliente->nom_comercial = $nom_comercial;
        $cliente->cif = $cif;
        $cliente->direccion = $direccion;
        $cliente->cod_postal = $cod_postal;
        $cliente->localidade = $localidade;
        $cliente->provincia_id = $provincia;
        $cliente->telefono = $telefono;
        $cliente->email = $email;

        $cliente->update();

        //Accedemos á páxina de listado de clientes e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoClientes')->with(['mensaxe' => 'Cliente modificado correctamente']);
    }


    /**
     * Método que recibe como parámetro o id do cliente a aliminar,
     * comproba se se pode borrar e, se se pode borrar mostra unha mensaxe de éxito.
     * 
     * @param Request Recibe o ide do cliente a eliminar.
     * @return  redirect Redirixe á páxina listadoClientes (no caso de que se valide que o cliente se pode eliminar) pasándolle unha mensaxe de éxito.
     */

    public function eliminar(Request $request)
    {
        //Obtemos o ID de cliente que queremos eliminar
        $id = $request->input('id');

        $cliente = Cliente::find($id);
        $proxectos = Proxecto::all();

        //Comprobamos se o cliente ten proxectos asignados, de ser así mostramos unha mensaxe indicándoo
        if (count($proxectos->where('cliente_id', '=', $id)) > 0) {
            return redirect()->route('listadoClientes')->withErrors(array('message' => 'Non se pode eliminar o cliente xa que ten proxectos asignados.'));
        }

        //Se todo foi ben borramos o cliente da base de datos.        

        $cliente->delete();
        //Accedemos á páxina de listado de clientes e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoClientes')->with(['mensaxe' => 'Cliente eliminado correctamente']);
    }

    /**
     * Método que exporta e descarga un listado de clientes en formato xslx
     *
     * @return Descarga_documento
     */
    public function exportarClientes()
    {
        return Excel::download(new ClientesExport, 'clientes.xlsx');
    }
}
