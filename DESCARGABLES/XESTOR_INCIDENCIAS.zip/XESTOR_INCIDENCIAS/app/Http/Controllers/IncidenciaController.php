<?php

namespace App\Http\Controllers;

use App\Exports\IncidenciasExport;
use App\Mail\IncidenciaCancelada;
use App\Mail\IncidenciaEnProceso;
use App\Mail\IncidenciaFinalizada;
use App\Mail\IncidenciaPlanificada;
use App\Mail\IncidenciaRexistrada;
use Illuminate\Http\Request;
use App\Models\Incidencia;
use App\Models\Proxecto;
use App\Models\Provincia;
use App\Models\Peticionario;
use App\Models\User;
use App\Models\Estado;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\IncidenciaRequest;
use App\Http\Requests\IncidenciaPlanificarRequest;



class IncidenciaController extends Controller
{
    //Engadimos o middleware para que non se poida acceder a menos que estemos autenticados.    
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Método que devolve o formulario de rexistro de incidencias.
     * Definimos as variables necesarias para a vista (proxectos, peticionarios, e provincias.)
     *
     * @return view Vista rexistrar do cartafol incidencias.
     */
    public function rexistro()
    {
        $proxectos = Proxecto::all();
        $peticionarios = Peticionario::all();
        $provincias = Provincia::all();
        return view('incidencias.rexistrar')->with(compact('proxectos', 'peticionarios', 'provincias'));
    }

    /**
     * Método que recibe os campos do formulario de rexistro de incidencias,
     * valídaos, se son correctos insértaos na base de datos, envía un email de 
     * confirmación de incidencia rexistrada e redirixe ao listado de incidencias.
     *
     * @param Request Recibe os datos do formulario de rexistro de incidencias.
     * @return redirect Redirixe á páxina listadoIncidencias.
     */
    public function rexistrar(IncidenciaRequest $request)
    {

        //Datos obtidos do formulario
        $cod_inc_cliente = $request->input('cod_inc_cliente');
        $proxecto_id = $request->input('proxecto_id');
        $peticionario_id = $request->input('peticionario_id');
        $data_peticion = $request->input('data_peticion');
        $nom_incidencia = $request->input('nom_incidencia');
        $descripcion = $request->descripcion;
        $persoa_contacto = $request->input('persoa_contacto');
        $telefono_contacto = $request->input('telefono_contacto');
        $direccion_asistencia = $request->input('direccion_asistencia');
        $cod_postal = $request->input('cod_postal');
        $provincia_id = $request->input('provincia_id');
        $estado_actual = 1;

        //TRANSFORMAMOS A DATA DD/MM/AAA HH:MM EN FORMATO DE MYSQL
        $data_peticion = Carbon::createFromFormat('d/m/Y H:i', $data_peticion)->format('Y-m-d H:i');

        //Gardamos os datos obtidos na base de datos.
        $incidencia = new Incidencia();


        $incidencia->cod_inc_cliente = $cod_inc_cliente;
        $incidencia->proxecto_id = $proxecto_id;
        $incidencia->peticionario_id = $peticionario_id;
        $incidencia->data_peticion = $data_peticion;
        $incidencia->nom_incidencia = $nom_incidencia;
        $incidencia->descripcion = $descripcion;
        $incidencia->persoa_contacto = $persoa_contacto;
        $incidencia->telefono_contacto = $telefono_contacto;
        $incidencia->direccion_asistencia = $direccion_asistencia;
        $incidencia->cod_postal = $cod_postal;
        $incidencia->provincia_id = $provincia_id;
        $incidencia->estado_actual = $estado_actual;


        $incidencia->save();

        //ENGADIMOS HISTÓRICO DE ESTADOS

        $incidencia->estados()->attach($estado_actual);


        //ENVIAMOS EMAIL DE INCIDENCIA REXISTRADA

        $email_peticionario = $incidencia->peticionarios->email;

        $codigo_inc_cliente = $incidencia->cod_inc_cliente;
        $data_peticion = $incidencia->data_peticion_formato;
        $peticionario = $incidencia->peticionarios->nome . ' ' . $incidencia->peticionarios->primeiro_apelido . ' ' . $incidencia->peticionarios->segundo_apelido;
        $proxecto = $incidencia->proxectos->nom_proxecto;
        $incidencia_nome = $incidencia->nom_incidencia;
        $incidencia_descripcion = $incidencia->descripcion;
        $persoa_contacto = $incidencia->persoa_contacto;
        $direccion_asistencia = $incidencia->direccion_asistencia;
        $codigo_postal = $incidencia->cod_postal;
        $provincia = $incidencia->provincias->nome;

        $datos = array(
            'codigo_inc_cliente' => "$codigo_inc_cliente",
            'data_peticion' => "$data_peticion",
            'peticionario' => "$peticionario",
            'proxecto' => "$proxecto",
            'incidencia_ nome' => "$incidencia_nome",
            'incidencia_ descripcion' => "$incidencia_descripcion",
            'persoa_contacto' => "$persoa_contacto",
            'direccion_asistencia' => "$direccion_asistencia",
            'codigo_postal' => "$codigo_postal",
            'provincia' => "$provincia"
        );

        Mail::to($email_peticionario)->send(new IncidenciaRexistrada($datos));

        //Accedemos á páxina de listado de Indicencias e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoIncidencias')->with(['mensaxe' => 'Nova incidencia creada correctamente. Email de rexistro enviado ao peticionario.']);
    }

    /**
     * Función que recibe como parámetros a data de planificación e o técnico que
     * asistirá á incidencia, valida os parámetros e, se son correctos, engade 
     * a planificación á incidencia.
     *
     * @param Request Recibe os datos do formulario de planificación de incidencias.
     * @return Redirect Redirixe á páxina de listado de incidencias.
     */
    public function planificar(IncidenciaPlanificarRequest $request)
    {

        //Obtemos os parámetros
        $id = $request->input('id');
        $data_planificada = $request->input('data_planificada');
        $data_peticion = $request->input('data_peticion');

        $tecnico_id = $request->input('tecnico_id');
        
        

        //Obtemos a incidencia que queremos planificar
        $incidencia = Incidencia::find($id);

        //TRANSFORMAMOS A DATA DD/MM/AAA HH:MM EN FORMATO DE MYSQL
        $data_planificada = Carbon::createFromFormat('d/m/Y H:i', $data_planificada)->format('Y-m-d H:i');

        //Asignamos os parámetros á incidencia
        $incidencia->data_planificada = $data_planificada;
        $incidencia->tecnico_id = $tecnico_id;

        //Asignamoslle o estado de planificada
        //Obtemos o estado que ten actualmente
        $estado_actual = $incidencia->estado_actual;
        //Se o estado actual non é planificado
        if ($estado_actual != 2) {
            //Poñemos como estado actual planificado
            $estado_actual = 2;
            //Engadímolo ao histórico
            $incidencia->estados()->attach($estado_actual);
            $incidencia->estado_actual = $estado_actual;
        }

        //Actualizamos a incidencia
        $incidencia->update();


        //Enviamos email incidencia rexistrada

        //ENVIAMOS EMAIL DE INCIDENCIA REXISTRADA

        $email_peticionario = $incidencia->peticionarios->email;
        $email_tecnico = $incidencia->users->email;

        $codigo_inc_cliente = $incidencia->cod_inc_cliente;
        $codigo_inc_interno = $incidencia->cod_inc;
        $data_peticion = $incidencia->data_peticion_formato;
        $peticionario = $incidencia->peticionarios->nome . ' ' . $incidencia->peticionarios->primeiro_apelido . ' ' . $incidencia->peticionarios->segundo_apelido;
        $proxecto = $incidencia->proxectos->nom_proxecto;
        $incidencia_nome = $incidencia->nom_incidencia;
        $incidencia_descripcion = $incidencia->descripcion;
        $persoa_contacto = $incidencia->persoa_contacto;
        $direccion_asistencia = $incidencia->direccion_asistencia;
        $codigo_postal = $incidencia->cod_postal;
        $provincia = $incidencia->provincias->nome;
        $data_planificacion = $incidencia->data_planificada_formato;
        $tecnico_asignado = $incidencia->users->nome . ' ' . $incidencia->users->primeiro_apelido . ' ' . $incidencia->users->segundo_apelido;

        $datos = array(
            'codigo_inc_cliente' => "$codigo_inc_cliente",
            'codigo_inc_interno' => "$codigo_inc_interno",
            'data_peticion' => "$data_peticion",
            'peticionario' => "$peticionario",
            'proxecto' => "$proxecto",
            'incidencia_ nome' => "$incidencia_nome",
            'incidencia_ descripcion' => "$incidencia_descripcion",
            'persoa_contacto' => "$persoa_contacto",
            'direccion_asistencia' => "$direccion_asistencia",
            'codigo_postal' => "$codigo_postal",
            'provincia' => "$provincia",
            'data_planificada' => "$data_planificacion",
            'tecnico_asignado' => "$tecnico_asignado"
        );
        $destinatarios = ["$email_peticionario", "$email_tecnico"];

        Mail::to($destinatarios)->send(new IncidenciaPlanificada($datos));

        //Accedemos á páxina de listado de clientes e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoIncidencias')->with(['mensaxe' => 'Incidencia planificada correctamente. Email enviado ao peticionario e ao técnico asignado.']);
    }

    /**
     * Método que recibe como parámetro os campos do buscador e devolve a táboa
     * de resultados en forma de listado de incidencias.
     * 
     * No caso de que non haxa campos para buscar/filtrar devolve tódolos resultados.
     * 
     * @param Request Recibe os datos do formulario de busqueda de incidencias.
     * @return view Devolve a vista de listado de incidencias pasándolle as variables 
     * incidencias, provincias, tecnicos, estados, contador, proxectos e peticionarios.
     */
    public function listar(Request $request)
    {

        $incidencias = Incidencia::all()->sortBy('cod_incidencia');
        $provincias = Provincia::all()->sortBy('nome');
        $proxectos = Proxecto::all()->sortBy('nom_proxecto');
        $peticionarios = Peticionario::all()->sortBy('nome');
        $tecnicos = User::all()->sortBy('nome');
        $estados = Estado::all()->sortBy('id');
        $contador = 0;

        //OBTEMOS OS PARÁMETROS GET PARA FILTRAR

        $cod_inc = $request->get('cod_inc');
        $cod_inc_cliente = $request->get('cod_inc_cliente');
        $tecnico_id = $request->get('tecnico_id');
        $provincia_id = $request->get('provincia_id');
        $estado_actual = $request->get('estado_actual');
        $proxecto_id = $request->get('proxecto_id');

        //APLICAMOS OS SCOPE DEFINIDOS NO MODELO

        $incidencias = Incidencia::CodInc($cod_inc)
            ->CodIncCliente($cod_inc_cliente)
            ->TecnicoAsignado($tecnico_id)
            ->Provincia($provincia_id)
            ->Estado($estado_actual)
            ->Proxecto($proxecto_id)
            ->OrderBy('id', 'DESC')
            ->paginate(9);


        return view('incidencias.listar')->with(compact('incidencias', 'provincias', 'tecnicos', 'estados', 'contador', 'proxectos', 'peticionarios'));
    }

    /**
     * Método que devolve a lista de incidencias da data actual na páxina de inicio.
     * Se o usuario ten o rol de TECNICO só devolve as súas incidencias, senon
     * devolve tódalas incidencias que haxa asignadas para esa data.
     *
     * @param Request $request
     * @return void
     */
    public function listarHome()
    {

        $provincias = Provincia::all()->sortBy('nome');
        $proxectos = Proxecto::all()->sortBy('nom_proxecto');
        $peticionarios = Peticionario::all()->sortBy('nome');
        $tecnicos = User::all()->sortBy('nome');
        $estados = Estado::all()->sortBy('id');
        $contador = 0;

        $tecnico_id = auth()->user()->id;
        //Data actual.
        $fecha = Carbon::today()->toDateString();

        if (auth()->user()->rol == "TECNICO") {
            $incidencias = Incidencia::where('tecnico_id', 'LIKE', "$tecnico_id")
                ->where('data_planificada', 'LIKE', "$fecha%")
                ->orderBy('data_planificada', 'ASC')
                ->paginate(9);
        } else {
            $incidencias = Incidencia::where('data_planificada', 'LIKE', "$fecha%")
                ->orderBy('data_planificada', 'ASC')
                ->paginate(9);
        }


        return view('home')->with(compact('incidencias', 'provincias', 'tecnicos', 'estados', 'contador', 'proxectos', 'peticionarios'));
    }

    /**
     * Método que actualiza a data de asistencia da incidencia.
     *
     * @param Request $request
     * @return void
     */
    public function anunciarChegada(Request $request)
    {

        //Obtemos o ID da incidencia que queremos actualizar
        $id = $request->input('id');
        //Engadimos a data actual
        $data_actual = Carbon::now();

        $incidencia = Incidencia::find($id);

        $incidencia->data_asistencia = $data_actual;

        //Asignamoslle o estado de en proceso
        //Obtemos o estado que ten actualmente
        $estado_actual = $incidencia->estado_actual;
        //Se o estado actual non é en procerso
        if ($estado_actual != 3) {
            //Poñemos como estado actual en proceso
            $estado_actual = 3;
            //Engadímolo ao histórico
            $incidencia->estados()->attach($estado_actual);
            $incidencia->estado_actual = $estado_actual;
        }

        //Actualizamos a incidencia
        $incidencia->update();


        //Enviamos email incidencia en proceso

        //ENVIAMOS EMAIL DE INCIDENCIA EN PROCESO

        $email_peticionario = $incidencia->peticionarios->email;

        $codigo_inc_cliente = $incidencia->cod_inc_cliente;
        $codigo_inc_interno = $incidencia->cod_inc;
        $data_peticion = $incidencia->data_peticion_formato;
        $peticionario = $incidencia->peticionarios->nome . ' ' . $incidencia->peticionarios->primeiro_apelido . ' ' . $incidencia->peticionarios->segundo_apelido;
        $proxecto = $incidencia->proxectos->nom_proxecto;
        $incidencia_nome = $incidencia->nom_incidencia;
        $incidencia_descripcion = $incidencia->descripcion;
        $persoa_contacto = $incidencia->persoa_contacto;
        $direccion_asistencia = $incidencia->direccion_asistencia;
        $codigo_postal = $incidencia->cod_postal;
        $provincia = $incidencia->provincias->nome;
        $data_planificacion = $incidencia->data_planificada_formato;
        $tecnico_asignado = $incidencia->users->nome . ' ' . $incidencia->users->primeiro_apelido . ' ' . $incidencia->users->segundo_apelido;
        $data_asistencia = $incidencia->data_asistencia_formato;


        $datos = array(
            'codigo_inc_cliente' => "$codigo_inc_cliente",
            'codigo_inc_interno' => "$codigo_inc_interno",
            'data_peticion' => "$data_peticion",
            'peticionario' => "$peticionario",
            'proxecto' => "$proxecto",
            'incidencia_ nome' => "$incidencia_nome",
            'incidencia_ descripcion' => "$incidencia_descripcion",
            'persoa_contacto' => "$persoa_contacto",
            'direccion_asistencia' => "$direccion_asistencia",
            'codigo_postal' => "$codigo_postal",
            'provincia' => "$provincia",
            'data_planificada' => "$data_planificacion",
            'tecnico_asignado' => "$tecnico_asignado",
            'data_asistencia' => "$data_asistencia",
        );
        $destinatarios = ["$email_peticionario"];

        Mail::to($destinatarios)->send(new IncidenciaEnProceso($datos));

        return redirect()->route('home')->with(['mensaxe' => 'Hora de chegada actualizada correctamente']);
    }
    /**
     * Método que actualiza a data de finalización da incidencia.
     *
     * @param Request $request
     * @return void
     */
    public function anunciarFinalizacion(Request $request)
    {

        //Obtemos o ID da incidencia que queremos actualizar
        $id = $request->input('id');
        //Engadimos a data actual
        $data_actual = Carbon::now();

        $incidencia = Incidencia::find($id);

        $incidencia->data_finalizacion = $data_actual;

        //Asignamoslle o estado de finalizada
        //Obtemos o estado que ten actualmente
        $estado_actual = $incidencia->estado_actual;
        //Se o estado actual non é en finalizado
        if ($estado_actual != 4) {
            //Poñemos como estado actual en finalizado
            $estado_actual = 4;
            //Engadímolo ao histórico
            $incidencia->estados()->attach($estado_actual);
            $incidencia->estado_actual = $estado_actual;
        }

        //Actualizamos a incidencia
        $incidencia->update();

        //Enviamos email incidencia finalizada

        //ENVIAMOS EMAIL DE INCIDENCIA FINALIZADA

        $email_peticionario = $incidencia->peticionarios->email;

        $codigo_inc_cliente = $incidencia->cod_inc_cliente;
        $codigo_inc_interno = $incidencia->cod_inc;
        $data_peticion = $incidencia->data_peticion_formato;
        $peticionario = $incidencia->peticionarios->nome . ' ' . $incidencia->peticionarios->primeiro_apelido . ' ' . $incidencia->peticionarios->segundo_apelido;
        $proxecto = $incidencia->proxectos->nom_proxecto;
        $incidencia_nome = $incidencia->nom_incidencia;
        $incidencia_descripcion = $incidencia->descripcion;
        $persoa_contacto = $incidencia->persoa_contacto;
        $direccion_asistencia = $incidencia->direccion_asistencia;
        $codigo_postal = $incidencia->cod_postal;
        $provincia = $incidencia->provincias->nome;
        $data_planificacion = $incidencia->data_planificada_formato;
        $tecnico_asignado = $incidencia->users->nome . ' ' . $incidencia->users->primeiro_apelido . ' ' . $incidencia->users->segundo_apelido;
        $data_asistencia = $incidencia->data_asistencia_formato;
        $data_finalizacion = $incidencia->data_finalizacion_formato;


        $datos = array(
            'codigo_inc_cliente' => "$codigo_inc_cliente",
            'codigo_inc_interno' => "$codigo_inc_interno",
            'data_peticion' => "$data_peticion",
            'peticionario' => "$peticionario",
            'proxecto' => "$proxecto",
            'incidencia_ nome' => "$incidencia_nome",
            'incidencia_ descripcion' => "$incidencia_descripcion",
            'persoa_contacto' => "$persoa_contacto",
            'direccion_asistencia' => "$direccion_asistencia",
            'codigo_postal' => "$codigo_postal",
            'provincia' => "$provincia",
            'data_planificada' => "$data_planificacion",
            'tecnico_asignado' => "$tecnico_asignado",
            'data_asistencia' => "$data_asistencia",
            'data_finalizacion' => "$data_finalizacion"
        );
        $destinatarios = ["$email_peticionario"];

        Mail::to($destinatarios)->send(new IncidenciaFinalizada($datos));

        return redirect()->route('home')->with(['mensaxe' => 'Hora de finalización actualizada correctamente']);
    }
    /**
     * Método para modificar os datos dunha incidencia.
     * Valida antes de actualizar.
     *
     * @param Request $request
     * @return void
     */
    public function modificar(IncidenciaRequest $request)
    {

        //Obtemos os parámetros
        $id = $request->input('id');
        $proxecto_id = $request->input('proxecto_id');
        $peticionario_id = $request->input('peticionario_id');
        $nom_incidencia = $request->input('nom_incidencia');
        $data_peticion = $request->input('data_peticion');
        $descripcion = $request->descripcion;
        $persoa_contacto = $request->input('persoa_contacto');
        $telefono_contacto = $request->input('telefono_contacto');
        $direccion_asistencia = $request->input('direccion_asistencia');
        $cod_postal = $request->input('cod_postal');
        $provincia_id = $request->input('provincia_id');
        $cod_incidencia_cliente = $request->input('cod_inc_cliente');

       


        //Obtemos a incidencia que queremos planificar
        $incidencia = Incidencia::find($id);

 
        //TRANSFORMAMOS A DATA DD/MM/AAA HH:MM EN FORMATO DE MYSQL
         $data_peticion = Carbon::createFromFormat('d/m/Y H:i', $data_peticion)->format('Y-m-d H:i');

        //Asignamos novos valores ao obxeto cliente
        $incidencia->cod_inc_cliente = $cod_incidencia_cliente;
        $incidencia->proxecto_id = $proxecto_id;
        $incidencia->peticionario_id = $peticionario_id;
        $incidencia->nom_incidencia = $nom_incidencia;
        $incidencia->descripcion = $descripcion;
        $incidencia->persoa_contacto = $persoa_contacto;
        $incidencia->telefono_contacto = $telefono_contacto;
        $incidencia->direccion_asistencia = $direccion_asistencia;
        $incidencia->cod_postal = $cod_postal;
        $incidencia->provincia_id = $provincia_id;
        $incidencia->data_peticion = $data_peticion;

        $incidencia->update();

        //Accedemos á páxina de listado de clientes e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoIncidencias')->with(['mensaxe' => 'Incidencia modificada correctamente']);

        //Actualizamos a incidencia
        $incidencia->update();


        //Accedemos á páxina de listado de clientes e pasamos unha variable con mensaxe de exito.
        return redirect()->route('listadoIncidencias')->with(['mensaxe' => 'Incidencia planificada correctamente']);
    }

    /**
     * Método para cancelar unha incidencia.
     *
     * @param Request $request
     * @return void
     */
    public function cancelarIncidencia(Request $request)
    {

        //Obtemos o ID da incidencia que queremos cancelar
        $id = $request->input('id');

        $incidencia = Incidencia::find($id);

        //POÑEMOS A DATA PLANIFICADA A NULL
        $incidencia->data_planificada = null;

        //POÑEMOS O TÉCNICO ASIGNADO A NULL
        $incidencia->tecnico_id = null;

        //POÑEMOS O ESTADO ACTUAL COMO CANCELADO
        $incidencia->estado_actual = 5;

        //ENGADIMOS O ESTADO AO HISTÓRICO
        $incidencia->estados()->attach(5);

        $incidencia->update();


        //ENVIAMOS EMAIL DE INCIDENCIA CANCELADA

        $email_peticionario = $incidencia->peticionarios->email;

        $codigo_inc_cliente = $incidencia->cod_inc_cliente;
        $codigo_inc_interno = $incidencia->cod_inc;
        $data_peticion = $incidencia->data_peticion_formato;
        $peticionario = $incidencia->peticionarios->nome . ' ' . $incidencia->peticionarios->primeiro_apelido . ' ' . $incidencia->peticionarios->segundo_apelido;
        $proxecto = $incidencia->proxectos->nom_proxecto;
        $incidencia_nome = $incidencia->nom_incidencia;
        $incidencia_descripcion = $incidencia->descripcion;
        $persoa_contacto = $incidencia->persoa_contacto;
        $direccion_asistencia = $incidencia->direccion_asistencia;
        $codigo_postal = $incidencia->cod_postal;
        $provincia = $incidencia->provincias->nome;


        $datos = array(
            'codigo_inc_cliente' => "$codigo_inc_cliente",
            'codigo_inc_interno' => "$codigo_inc_interno",
            'data_peticion' => "$data_peticion",
            'peticionario' => "$peticionario",
            'proxecto' => "$proxecto",
            'incidencia_ nome' => "$incidencia_nome",
            'incidencia_ descripcion' => "$incidencia_descripcion",
            'persoa_contacto' => "$persoa_contacto",
            'direccion_asistencia' => "$direccion_asistencia",
            'codigo_postal' => "$codigo_postal",
            'provincia' => "$provincia",
        );
        $destinatarios = ["$email_peticionario"];

        Mail::to($destinatarios)->send(new IncidenciaCancelada($datos));

        return redirect()->route('listadoIncidencias')->with(['mensaxe' => 'Incidencia cancelada correctamente']);
    }
    /**
     * Método para exportar ficheiro de incidencias
     *
     * @return void
     */
    public function exportarIncidencias()
    {
        return Excel::download(new IncidenciasExport, 'incidencias.xlsx');
    }
}
