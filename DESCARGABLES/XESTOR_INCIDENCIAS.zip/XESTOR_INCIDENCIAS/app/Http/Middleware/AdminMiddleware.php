<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if(auth()->user()->rol != 'ADMINISTRADOR'){//Si el usuario no es administrador lo redirigimos a home
            return redirect()->route('home');
           
        }
        
        
        return $next($request);

    }
}
