<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use phpDocumentor\Reflection\Types\This;
use PhpParser\Builder\Function_;

class Proxecto extends Model
{
    use HasFactory;

    //Indicamos ao modelo a táboa á que facemos referencia na DB.
    protected $table = 'proxectos';

    //RELACIONS PROXECTOS
    
    //Relación N:1 con clientes
    public function clientes(){
        return $this->belongsTo('App\Models\Cliente', 'cliente_id');
    }
    //Relación 1:N con incidencias
    public function incidencias(){
        return $this->hasMany('App\Models\Incidencia');
    }

    //ACCESOR PARA OBTER A DATA DE INICIO DO PROXECTO NO FORMATO DD/MM/YYYY.
    public function getDataInicioFormatoAttribute(){

       return Carbon::parse($this->data_inicio)->format('d/m/Y');
    }

    //ACCESOR PARA OBTER A DATA DE FIN DO PROXECTO NO FORMATO QUE DESEXAMOS.
    public function getDataFinFormatoAttribute(){

        return Carbon::parse($this->data_fin)->format('d/m/Y');
        }

        /*
    SCOPES FILTRADO
    Los Scopes sirven para filtar por varios campos.
    Su nombre ha de empezar por scope.
    En la llamada al método desde el controlador se utiliza el nombre sin scope.
    */
    
    //SCOPE PARA FILTRAR POR NOME DE PROXECTO

    public function scopeNomProxecto($query, $nom_proxecto){
        if($nom_proxecto){
            return $query->where('nom_proxecto', 'LIKE', "%$nom_proxecto%");
        }
    }
    
    //SCOPE PARA FILTRAR POR NOME DE CLIENTE

    public function scopeCliente($query, $cliente){
        if($cliente){
            return $query->where('cliente_id', '=', "$cliente");
        }
    }

    //SCOPE PARA FILTRAR POR ESTADO EN PROCESO/FINALIZADO

    public function scopeEstado($query, $estado){
        if($estado==1){
            return $query->whereNull('data_fin');
        }
        if($estado==2){
            return $query->whereNotNull('data_fin');
        }
        if($estado==0){
            return $query;
        }
    }

}
