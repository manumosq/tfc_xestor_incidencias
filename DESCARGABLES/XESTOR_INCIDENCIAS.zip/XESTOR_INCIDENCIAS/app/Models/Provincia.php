<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Provincia extends Model
{
    use HasFactory;
    //Indicamos ao modelo a táboa á que facemos referencia na DB.
    protected $table = 'provincias';

    //RELACIONS PROVINCIAS

    //Relación 1:N con clientes
    public function clientes(){
        return $this->hasMany('App\Models\Cliente');
    }

    //Relación 1:N con incidencias
    public function incidencias(){
        return $this->hasMany('App\Models\Incidencia');
    }


}
