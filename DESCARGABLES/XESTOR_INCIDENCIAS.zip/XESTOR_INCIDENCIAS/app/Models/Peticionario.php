<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Peticionario extends Model
{
    use HasFactory;
    //Indicamos ao modelo a táboa á que facemos referencia na DB.
    protected $table = 'peticionarios';

    //RELACIONS PROVINCIAS

    //Relación 1:N con Incidencias
    public function incidencias()
    {
        return $this->hasMany('App\Models\Incidencia');
    }

    /*
    SCOPES FILTRADO
    Los Scopes sirven para filtar por varios campos.
    Su nombre ha de empezar por scope.
    En la llamada al método desde el controlador se utiliza el nombre sin scope.
    */
    
    //SCOPE PARA FILTRAR POR NOME DE TÉCNICO

    public function scopeNomPeticionario($query, $nome){
        if($nome){
            return $query->where('nome', 'LIKE', "%$nome%");
        }
    }
    
    //SCOPE PARA FILTRAR POR PRIMEIRO APELIDO

    public function scopePrimeiroApelido($query, $primeiro_apelido){
        if($primeiro_apelido){
            return $query->where('primeiro_apelido', 'LIKE', "%$primeiro_apelido%");
        }
    }

    //SCOPE PARA FILTRAR POR SEGUNDO APELIDO

    public function scopeSegundoApelido($query, $segundo_apelido){
        if($segundo_apelido){
            return $query->where('segundo_apelido', 'LIKE', "%$segundo_apelido%");
        }
    }
}
