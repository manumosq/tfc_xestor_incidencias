<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Estado extends Model
{
    use HasFactory;
    //Indicamos ao modelo a táboa á que facemos referencia na DB.
    protected $table = 'estados';

    //RELACIONS CAMBIOS DE ESTADO

    //Relación N:N con Incidencias
    public function incidencias()
    {
        return $this->belongsToMany('App\Models\Incidencia', 'estados_incidencias')->withTimestamps();
    }
}
