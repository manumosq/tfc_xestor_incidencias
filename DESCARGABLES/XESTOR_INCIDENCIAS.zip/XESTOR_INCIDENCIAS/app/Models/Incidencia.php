<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Incidencia extends Model
{
    use HasFactory;
    
    //Indicamos ao modelo a táboa á que facemos referencia na DB.
    protected $table = 'incidencias';

    //RELACIONS INCIDENCIAS
    
    //Relación N:1 con proxectos
    public function proxectos(){
        return $this->belongsTo('App\Models\Proxecto', 'proxecto_id');
    }
    //Relación N:1 con peticionarios
    public function peticionarios(){
        return $this->belongsTo('App\Models\Peticionario', 'peticionario_id');
    }
     //Relación N:N con Estado
     public function estados(){
        return $this->belongsToMany('App\Models\Estado', 'estados_incidencias')->withTimestamps();
    }

    //Relación N:1 con users
    public function users(){
        return $this->belongsTo('App\Models\User', 'tecnico_id');
    }

    //Relación N:1 con provincias
    public function provincias(){
        return $this->belongsTo('App\Models\Provincia', 'provincia_id');
    }

    /*
    SCOPES FILTRADO
    Los Scopes sirven para filtar por varios campos.
    Su nombre ha de empezar por scope.
    En la llamada al método desde el controlador se utiliza el nombre sin scope.
    */
    
    //SCOPE PARA FILTRAR POR CÓDIGO DE INCIDENCIA

    public function scopeCodInc($query, $cod_inc){
        if($cod_inc){
            return $query->where('cod_inc', 'LIKE', "%$cod_inc%");
        }
    }
    
    //SCOPE PARA FILTRAR POR CÓDIGO DE INCIDENCIA CLIENTE

    public function scopeCodIncCliente($query, $cod_inc_cliente){
        if($cod_inc_cliente){
            return $query->where('cod_inc_cliente', 'LIKE', "%$cod_inc_cliente%");
        }
    }

    //SCOPE PARA FILTRAR POR TÉCNICO ASIGNADO

    public function scopeTecnicoAsignado($query, $tecnico_id){
        if($tecnico_id){
            return $query->where('tecnico_id', '=', "$tecnico_id");
        }
    }

    public function scopeProvincia($query, $provincia_id){
        if($provincia_id){
            return $query->where('provincia_id', '=', "$provincia_id");
        }
    }

    public function scopeEstado($query, $estado_id){
        
        if($estado_id){
            return $query->where('estado_actual', '=', "$estado_id");
            
        }
    }
    public function scopeProxecto($query, $proxecto_id){
        
        if($proxecto_id){
            return $query->where('proxecto_id', '=', "$proxecto_id");
            
        }
    }

        //ACCESOR PARA OBTER A DATA DE PETICION DA INCIDENCIA NO FORMATO DD/MM/YYYY.
        public function getDataPeticionFormatoAttribute(){

            return Carbon::parse($this->data_peticion)->format('d/m/Y H:i');
        }

        public function getDataPlanificadaFormatoAttribute(){


            return Carbon::parse($this->data_planificada)->format('d/m/Y H:i');
         }

         public function getDataAsistenciaFormatoAttribute(){


            return Carbon::parse($this->data_asistencia)->format('d/m/Y H:i');
         }
         public function getDataFinalizacionFormatoAttribute(){


            return Carbon::parse($this->data_finalizacion)->format('d/m/Y H:i');
         }



}
