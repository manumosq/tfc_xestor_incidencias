<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    use HasFactory;
    //Indicamos ao modelo a táboa á que facemos referencia na DB.
    protected $table = 'clientes';

    //RELACIONS CLIENTES
    
    //Relación 1:N con proxectos
    public function proxectos(){
        return $this->hasMany('App\Models\Proxecto');
    }

    //Relación N:1 con provincias
    public function provincias(){
        return $this->belongsTo('App\Models\Provincia', 'provincia_id');
    }

    
    /*
    SCOPES FILTRADO
    Los Scopes sirven para filtar por varios campos.
    Su nombre ha de empezar por scope.
    En la llamada al método desde el controlador se utiliza el nombre sin scope.
    */
    
    //SCOPE PARA FILTRAR POR NOMBRE COMERCIAL

    public function scopeNomComercial($query, $nom_comercial){
        if($nom_comercial){
            return $query->where('nom_comercial', 'LIKE', "%$nom_comercial%");
        }
    }
    
    //SCOPE PARA FILTRAR POR EMAIL

    public function scopeEmail($query, $email){
        if($email){
            return $query->where('email', 'LIKE', "%$email%");
        }
    }

    //SCOPE PARA FILTRAR POR PROVINCIA

    public function scopeProvincia($query, $provincia){
        if($provincia){
            return $query->where('provincia_id', '=', "$provincia");
        }
    }


}
