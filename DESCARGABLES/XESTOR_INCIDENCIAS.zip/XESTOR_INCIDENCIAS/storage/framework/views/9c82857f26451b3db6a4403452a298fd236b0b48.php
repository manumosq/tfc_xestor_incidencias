<table>
    <thead>
        <tr>
            <th>Código Cliente</th>
            <th>Nome Fiscal</th>
            <th>Nome Comercial</th>
            <th>Teléfono de Contacto</th>
            <th>Email</th>
            <th>CIF</th>
            <th>Dirección</th>
            <th>Código Postal</th>
            <th>Localidade</th>
            <th>Provincia</th>

        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cliente->cod_cliente); ?></td>
            <td><?php echo e($cliente->nom_fiscal); ?></td>
            <td><?php echo e($cliente->nom_comercial); ?></td>
            <td><?php echo e($cliente->telefono); ?></td>
            <td><?php echo e($cliente->email); ?></td>
            <td><?php echo e($cliente->cif); ?></td>
            <td><?php echo e($cliente->direccion); ?></td>
            <td><?php echo e($cliente->cod_postal); ?></td>
            <td><?php echo e($cliente->localidade); ?></td>
            <td><?php echo e($cliente->provincias->nome); ?></td>
        </tr>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/exports/clientesExport.blade.php ENDPATH**/ ?>