<!--VENTANA MODAL VER PROXECTO-->

<div class="modal fade" id="ver<?php echo e($contador); ?>">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">VER <?php echo e($proxecto->cod_proxecto); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row">
                        <h5>Datos Proxecto:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <label for="nom_proxecto">Nome Proxecto:</label>
                            <input type="text" class="form-control form-control-sm" id="nom_proxecto"
                                name="nom_proxecto" value=" <?php echo e($proxecto->nom_proxecto); ?>" readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="nom_comercial">Cliente:</label>
                            <input type="text" class="form-control form-control-sm" id="nom_comercial"
                                name="nom_comercial" value=" <?php echo e($proxecto->clientes->nom_comercial); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                    <div class="row">
                        <h5>Estado:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="data_inicio">Data de inicio:</label>
                            <input type="text" class="form-control form-control-sm" id="data_inicio"
                                name="data_inicio" value=" <?php echo e($proxecto->data_inicio_formato); ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label for="data_fin">Data de Fin:</label>
                            <input type="text" class="form-control form-control-sm" id="data_fin"
                                name="data_fin" value=" <?php if($proxecto->data_fin == null): ?> PROXECTO EN PROCESO <?php else: ?> <?php echo e($proxecto->data_fin_formato); ?> <?php endif; ?>" readonly>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Pechar Ventá</button>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/proxectos/ver.blade.php ENDPATH**/ ?>