<!--VENTANA MODAL VER CLIENTE-->

<div class="modal fade" id="ver<?php echo e($contador); ?>">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">VER <?php echo e($cliente->cod_cliente); ?> - <span
                        class="text-uppercase"><?php echo e($cliente->nom_comercial); ?></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row">
                        <h5>Datos Fiscais:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label for="nom_comercial">Nome Comercial:</label>
                            <input type="text" class="form-control form-control-sm" id="nom_comercial"
                                name="nom_comercial" value=" <?php echo e($cliente->nom_comercial); ?>" readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="nom_fiscal">Nome Fiscal:</label>
                            <input type="text" class="form-control form-control-sm" id="nom_fiscal"
                                name="nom_fiscal" value=" <?php echo e($cliente->nom_fiscal); ?>" readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="cif">CIF:</label>
                            <input type="text" class="form-control form-control-sm" id="cif"
                                name="cif" value=" <?php echo e($cliente->cif); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                    <div class="row">
                        <h5>Dirección:</h5>
                    </div>
                    <div class="row">

                        <div class="col-md-3">
                            <label for="direccion">Dirección:</label>
                            <input type="text" class="form-control form-control-sm" id="direccion"
                                name="direccion" value=" <?php echo e($cliente->direccion); ?>" readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="cod_postal">Código Postal:</label>
                            <input type="text" class="form-control form-control-sm" id="cod_postal"
                                name="cod_postal" value=" <?php echo e($cliente->cod_postal); ?>" readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="localidade">Localidade:</label>
                            <input type="text" class="form-control form-control-sm" id="localidade"
                                name="localidade" value=" <?php echo e($cliente->localidade); ?>" readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="provincia">Provincia:</label>
                            <input type="text" class="form-control form-control-sm" id="provincia"
                                name="provincia" value=" <?php echo e($cliente->provincias->nome); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                    <div class="row">
                        <h5>Contacto:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="telefono">Teléfono:</label>
                            <input type="text" class="form-control form-control-sm" id="telefono"
                                name="telefono" value=" <?php echo e($cliente->telefono); ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label for="email">Email:</label>
                            <input type="text" class="form-control form-control-sm" id="email"
                                name="email" value=" <?php echo e($cliente->email); ?>" readonly>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Pechar Ventá</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/clientes/ver.blade.php ENDPATH**/ ?>