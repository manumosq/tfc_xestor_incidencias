<!--VENTANA MODAL VER PROXECTO-->

<div class="modal fade" id="ver<?php echo e($contador); ?>">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">VER <?php echo e($proxecto->cod_proxecto); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row">
                        <h5>Datos Proxecto:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <span class="text-difuminado">Nome Proxecto:</span><?php echo e($proxecto->nom_proxecto); ?>

                        </div>
                        <div class="col-md-4">
                            <span class="text-difuminado">Cliente:</span> <?php echo e($proxecto->clientes->nom_comercial); ?>

                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                    <div class="row">
                        <h5>Estado:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-7">
                            <span class="text-difuminado">Data de inicio:</span> <?php echo e($proxecto->data_inicio_formato); ?>

                        </div>
                        <div class="col-md-5">
                            <span class="text-difuminado">Data de Fin: </span> <?php if($proxecto->data_fin == null): ?> EN PROCESO <?php else: ?> <?php echo e($proxecto->data_fin_formato); ?> <?php endif; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar Ventana</button>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/proxectos/ver.blade.php ENDPATH**/ ?>