<table>
    <thead>
        <tr>
            <th>Código Proxecto</th>
            <th>Nome Proxecto</th>
            <th>Cliente Responsable</th>
            <th>Data Inicio Proxecto</th>
            <th>Data Fin Proxecto</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $proxectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proxecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($proxecto->cod_proxecto); ?></td>
            <td><?php echo e($proxecto->nom_proxecto); ?></td>
            <td><?php echo e($proxecto->clientes->nom_comercial); ?></td>
            <td><?php echo e($proxecto->data_inicio_formato); ?></td>
            <td>
                <?php if($proxecto->data_fin == null): ?> EN PROCESO
                <?php else: ?> <?php echo e($proxecto->data_fin_formato); ?>

                <?php endif; ?>
            </td>
        </tr>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/exports/proxectosExport.blade.php ENDPATH**/ ?>