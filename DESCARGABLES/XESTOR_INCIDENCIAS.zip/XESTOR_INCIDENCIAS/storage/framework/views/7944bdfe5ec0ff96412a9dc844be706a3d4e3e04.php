<!--VENTANA MODAL VER INCIDENCIA-->

<div class="modal fade" id="ver<?php echo e($contador); ?>">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">VER <?php echo e($incidencia->cod_inc); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row">
                        <h5>Datos Incidencia:</h5>
                    </div>
                    <div class="row">

                        <div class="col-md-3">
                            <label for="cod_inc_cliente">Código Incidencia Cliente:</label>
                            <input type="text" class="form-control form-control-sm" id="cod_inc_cliente"
                                name="cod_inc_cliente" value="<?php echo e($incidencia->cod_inc_cliente); ?>" readonly>
                        </div>

                        <div class="col-md-3">
                            <label for="proxecto">Proxecto:</label>
                            <input type="text" class="form-control form-control-sm" id="proxecto" name="proxecto"
                                value="<?php echo e($incidencia->proxectos->nom_proxecto); ?>" readonly>
                        </div>

                        <div class="col-md-3">
                            <label for="peticionario">Peticionario:</label>
                            <input type="text" class="form-control form-control-sm" id="peticionario"
                                name="peticionario"
                                value="<?php echo e($incidencia->peticionarios->nome); ?> <?php echo e($incidencia->peticionarios->primeiro_apelido); ?> <?php echo e($incidencia->peticionarios->segundo_apelido); ?>"
                                readonly>
                        </div>

                        <div class="col-md-3">
                            <label for="data_peticion">Data Petición:</label>
                            <input type="text" class="form-control form-control-sm" id="data_peticion"
                                name="data_peticion" value="<?php echo e($incidencia->data_peticion_formato); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>

                    <div class="row">

                        <div class="col-md-12">
                            <label for="nom_incidencia">Nome Incidencia:</label>
                            <input type="text" class="form-control form-control-sm" id="nom_incidencia"
                                name="nom_incidencia" value="<?php echo e($incidencia->nom_incidencia); ?>" readonly>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <label for="descripcion">Descripción:</label>
                            <textarea class="form-control form-control-sm" id="descripcion" name="descripcion" rows="6"
                                readonly><?php echo e($incidencia->descripcion); ?></textarea>
                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                    <div class="row">
                        <h5>Datos de Asistencia:</h5>
                    </div>
                    <div class="row">

                        <div class="col-md-6">
                            <label for="persoa_contacto">Persoa de Contacto:</label>
                            <input type="text" class="form-control form-control-sm" id="persoa_contacto"
                                name="persoa_contacto" value="<?php echo e($incidencia->persoa_contacto); ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label for="telefono_contacto">Teléfono de Contacto:</label>
                            <input type="text" class="form-control form-control-sm" id="telefono_contacto"
                                name="telefono_contacto" value="<?php echo e($incidencia->telefono_contacto); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label for="direccion_asistencia">Dirección de Asistencia:</label>
                            <input type="text" class="form-control form-control-sm" id="direccion_asistencia"
                                name="direccion_asistencia" value="<?php echo e($incidencia->direccion_asistencia); ?>" readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="cod_postal">Código Postal:</label>
                            <input type="text" class="form-control form-control-sm" id="cod_postal" name="cod_postal"
                                value="<?php echo e($incidencia->cod_postal); ?>" readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="provincia">Provincia:</label>
                            <input type="text" class="form-control form-control-sm" id="provincia" name="provincia"
                                value="<?php echo e($incidencia->provincias->nome); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                    <div class="row">
                        <h5>Datos de Planificación:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <label for="tecnico">Técnico Asignado:</label>
                            <input type="text" class="form-control form-control-sm" id="tecnico" name="tecnico"
                                value="<?php echo e($incidencia->users->nome); ?> <?php echo e($incidencia->users->primeiro_apelido); ?> <?php echo e($incidencia->users->segundo_apelido); ?>"
                                readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="data_planificada">Data Planificada:</label>
                            <input type="text" class="form-control form-control-sm" id="data_planificada"
                                name="data_planificada" value="<?php echo e($incidencia->data_planificada_formato); ?>" readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="data_asistencia">Data Asistencia:</label>
                            <input type="text" class="form-control form-control-sm" id="data_asistencia"
                                name="data_asistencia" value="<?php echo e($incidencia->data_asistencia_formato); ?>" readonly>
                        </div>
                        <div class="col-md-3">
                            <label for="data_finalizacion">Data Finalización:</label>
                            <input type="text" class="form-control form-control-sm" id="data_finalizacion"
                                name="data_finalizacion" value="<?php echo e($incidencia->data_finalizacion_formato); ?>" readonly>
                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar Ventana</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/incidencias/ver.blade.php ENDPATH**/ ?>