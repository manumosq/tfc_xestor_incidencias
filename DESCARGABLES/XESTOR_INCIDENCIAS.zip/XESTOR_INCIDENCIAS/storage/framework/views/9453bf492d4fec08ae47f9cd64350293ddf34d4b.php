<!--VENTANA MODAL ANUNCIAR CHEGADA-->

<div class="modal fade" id="anunciar_chegada<?php echo e($contador); ?>">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">CHEGADA A INCIDENCIA - <?php echo e($incidencia->cod_inc); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row justify-content-center">
                <h6 class="text-center">Anunciar chegada a incidencia <b style="text-decoration: underline"><?php echo e($incidencia->cod_inc); ?></b> planificada para as <b style="text-decoration: underline"><?php echo e($incidencia->data_planificada_formato); ?></b></h6>
                    <h6 class="text-center"></h6>
                <h6 class="text-center">¿Está seguro de que quere continuar?</h6>
                <p>&nbsp;</p>
                    </div>
                    <form method="POST" action="<?php echo e(route('anunciarChegada')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($incidencia->id); ?>">
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-success">Anunciar Chegada</button>
                            &nbsp;&nbsp;&nbsp;
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/incidencias/anunciar_chegada.blade.php ENDPATH**/ ?>