<!--TÁBOA DE RESULTADOS-->
<div class="row justify-content-center">
    <?php if(session('mensaxe')): ?>
        <div class="alert alert-success col-md-12" id="aviso">
            <?php echo e(session('mensaxe')); ?>

        </div>
    <?php endif; ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>

                    <th class="table-primary">INC</th>
                    <th class="table-primary">Nome Incidencia</th>
                    <th class="table-primary">Data Planificada</th>
                    <th class="table-primary">Persoa Contacto</th>
                    <th class="table-primary">Teléfono Contacto</th>
                    <th class="table-primary">Dirección</th>
                    <th class="table-primary text-center" colspan="3">Accións</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr data-id="<?php echo e($incidencia->id); ?>" <?php if($contador % 2 != 0): ?> class="table-light"
                <?php endif; ?>>
                <td><?php echo e($incidencia->cod_inc); ?></td>
                <td><?php echo e($incidencia->nom_incidencia); ?></td>
                <td><?php echo e($incidencia->data_planificada_formato); ?></td>
                <td><?php echo e($incidencia->persoa_contacto); ?> </td>
                <td><?php echo e($incidencia->telefono_contacto); ?></td>
                <td><?php echo e($incidencia->direccion_asistencia); ?></td>
                <td style="max-width: 30px;">
                    <a href=# data-toggle="modal" data-target="#ver<?php echo e($contador); ?>" title="Ver Incidencia"><img
                            style="width:25px" alt="Ver Cliente" src="img\ver.png"></a>
                    <?php echo $__env->make('incidencias.ver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                </td>
                <td style="max-width: 30px;">
                    <?php if($incidencia->estado_actual < 3): ?>
                    <a href=# data-toggle="modal" data-target="#anunciar_chegada<?php echo e($contador); ?>"
                        title="Anunciar chegada Cliente"><img style="width:20px" alt="Anunciar chegada Cliente"
                            src="img\llegada.png"></a>
                    <?php echo $__env->make('incidencias.anunciar_chegada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>
                    <img style="width:20px" alt="Chegada xa anunciada" title="Chegada xa anunciada" src="img\llegada_marcada.png">
                    <?php endif; ?>
                </td>
                <td style="max-width: 30px;">
                    <?php if($incidencia->estado_actual < 4): ?>
                    <a href="#" data-toggle="modal" data-target="#anunciar_finalizacion<?php echo e($contador); ?>"
                        title="Anunciar Finalización Incidencia"><img style="width:24px" alt="Anunciar Finalización Incidencia"
                            src="img\finalizacion.png"></a>
                    <?php echo $__env->make('incidencias.anunciar_finalizacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>
                        <img style="width:24px" alt="Finalización xa anunciada" title="Finalización xa anunciada" src="img\finalizacion_marcada.png">
                    <?php endif; ?>
                </td>
                </tr>
                <?php $contador++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
    <?php echo e($incidencias->links('vendor.pagination.bootstrap-4')); ?>


</div><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/listas_home/incidencias_tecnico.blade.php ENDPATH**/ ?>