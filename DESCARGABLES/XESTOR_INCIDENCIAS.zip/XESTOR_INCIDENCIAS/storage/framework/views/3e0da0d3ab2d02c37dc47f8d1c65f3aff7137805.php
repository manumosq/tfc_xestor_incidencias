<!--VENTANA MODAL VER CLIENTE-->

<div class="modal fade" id="ver<?php echo e($contador); ?>">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">VER <?php echo e($cliente->cod_cliente); ?> - <span
                        class="text-uppercase"><?php echo e($cliente->nom_comercial); ?></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row">
                        <h5>Datos Fiscais:</h5>
                    </div>

                    <div class="row">
                        <div class="col-md-7">
                            <span class="text-difuminado">Nome Fiscal:</span> <?php echo e($cliente->nom_fiscal); ?>

                        </div>
                        <div class="col-md-5">
                            <span class="text-difuminado">CIF:</span> <?php echo e($cliente->cif); ?>

                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                    <div class="row">
                        <h5>Dirección:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-7">
                            <span class="text-difuminado">Dirección:</span> <?php echo e($cliente->direccion); ?>

                        </div>
                        <div class="col-md-5">
                            <span class="text-difuminado">C.P.:</span> <?php echo e($cliente->cod_postal); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-7">
                            <span class="text-difuminado">Localidade:</span> <?php echo e($cliente->localidade); ?>

                        </div>
                        <div class="col-md-5">
                            <span class="text-difuminado">Provincia:</span> <?php echo e($cliente->provincias->nome); ?>

                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                    <div class="row">
                        <h5>Contacto:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-7">
                            <span class="text-difuminado">Teléfono:</span> <?php echo e($cliente->telefono); ?>

                        </div>
                        <div class="col-md-5">
                            <span class="text-difuminado">Email:</span> <?php echo e($cliente->email); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar Ventana</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/clientes/ver.blade.php ENDPATH**/ ?>