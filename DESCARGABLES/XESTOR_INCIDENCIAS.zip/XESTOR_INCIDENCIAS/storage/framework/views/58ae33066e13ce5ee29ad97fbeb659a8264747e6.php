<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
        <title>Prueba correo</title>
    </head>
    <body>
    <p>Hola <?php echo e($datos['peticionario']); ?>,
     a incidencia que nos enviou <b>REXISTROUSE</b> cos seguintes datos:</p>
    <h3><u>DATOS DA INCIDENCIA:</u></h3>
    <p><b><i>CÓDIGO INCIDENCIA CLIENTE:</i></b> <i><?php echo e($datos['codigo_inc_cliente']); ?></i></p>
    <p><b><i>DATA DE SOLICITUDE:</i></b> <i><?php echo e($datos['data_peticion']); ?></i></p> 
    <p><b><i>CÓDIGO INCIDENCIA INTERNO:</i></b> <i><?php echo e($datos['codigo_incidencia']); ?></i></p> 
    <p><b><i>PROXECTO:</i></b> <i><?php echo e($datos['proxecto']); ?></i></p> 
    <h3><u>DATOS DA SOLICITUDE:</u></h3>
    <p><b><i>NOME INCIDENCIA:</i></b> <i><?php echo e($datos['incidencia_ nome']); ?></i></p> 
    <p><b><i>DESCRIPCIÓN INCIDENCIA:</i></b></p>
    <p><i><?php echo e($datos['incidencia_ descripcion']); ?></i></p> 
    <h3><u>DATOS DE CONTACTO:</u></h3>
    <p><b><i>PERSOA DE CONTACTO:</i></b> <i><?php echo e($datos['persoa_contacto']); ?></i></p> 
    <p><b><i>DIRECCIÓN DE ASISTENCIA:</i></b> <i> <?php echo e($datos['direccion_asistencia']); ?></i></p> 
    <p><b><i>CÓDIGO POSTAL:</i></b> <i><?php echo e($datos['codigo_postal']); ?></i></p> 
    <p><b><i>PROVINCIA:</i></b> <i><?php echo e($datos['provincia']); ?></i></p> 
    <p><b><i>CÓDIGO INCIDENCIA CLIENTE:</i></b> <i><?php echo e($datos['codigo_inc_cliente']); ?></i></p> 


    <p>Atenderemos a incidencia o máis pronto posible. Se ten algunha dúbida contacte connosco neste mesmo email</p>
    <p>Un saúdo,</p>   

    </body>
</html><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/mails/incidencia.blade.php ENDPATH**/ ?>