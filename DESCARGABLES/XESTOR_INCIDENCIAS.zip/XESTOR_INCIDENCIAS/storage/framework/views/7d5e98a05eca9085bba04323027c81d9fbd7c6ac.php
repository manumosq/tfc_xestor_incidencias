<!--TÁBOA DE RESULTADOS-->
<div class="row justify-content-center">
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>

                    <th class="table-primary">INC</th>
                    <th class="table-primary">INC Cliente</th>
                    <th class="table-primary">Nome Incidencia</th>
                    <th class="table-primary">Técnico Asignado</th>
                    <th class="table-primary text-center">Data Planificación</th>
                    <th class="table-primary text-center">Data Asistencia</th>
                    <th class="table-primary text-center">Data Finalización</th>
                    <th class="table-primary text-center">Estado</th>
                    <th class="table-primary text-center" colspan="2">Accións</th>
                </tr>
            </thead>
            
            <tbody>
                <?php if($incidencias->count()==0): ?> <td colspan="10">Hola <?php echo e(auth()->user()->nome); ?> polo momento non hai nada planificado para hoxe.</td>
                <?php else: ?>
                    <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                    <td><?php echo e($incidencia->cod_inc); ?></td>
                    <td><?php echo e($incidencia->cod_inc_cliente); ?></td>
                    <td><?php echo e($incidencia->nom_incidencia); ?></td>
                    <td><?php echo e($incidencia->users->nome); ?> <?php echo e($incidencia->users->primeiro_apelido); ?><<?php echo e($incidencia->users->segundo_apelido); ?>/td>
                    <td class="text-center">
                        <?php if($incidencia->data_planificada == null): ?> PENDENTE
                        <?php else: ?> <?php echo e($incidencia->data_planificada_formato); ?>

                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?php if($incidencia->data_asistencia == null): ?> PENDENTE
                        <?php else: ?> <?php echo e($incidencia->data_asistencia_formato); ?>

                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?php if($incidencia->data_finalizacion == null): ?> PENDENTE
                        <?php else: ?> <?php echo e($incidencia->data_finalizacion_formato); ?>

                        <?php endif; ?>
                    </td>
                    <td class="text-center
                    <?php if($incidencia->estado_actual == 2): ?> table-planificada text-center
                    <?php elseif($incidencia->estado_actual == 3): ?> table-enproceso text-center
                    <?php elseif($incidencia->estado_actual == 4): ?> table-finalizada text-center
                    <?php elseif($incidencia->estado_actual == 6): ?> table-cancelada text-center                        
                    <?php endif; ?>
                    "
                    ><?php echo e($incidencia->estados->last()->nome); ?></td>


                    <td style="max-width: 30px;">
                        <a href=# data-toggle="modal" data-target="#ver<?php echo e($contador); ?>" title="Ver Incidencia"><img
                                style="width:25px" alt="Ver Incidencia" src="img\ver.png"></a>
                        <?php echo $__env->make('incidencias.ver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                    </td>
                    <td style="max-width: 30px;">
                        
                        <a href="#" data-toggle="modal" data-target="#ver_tecnico_asignado<?php echo e($contador); ?>"
                            title="Ver datos técnico asignado"><img style="width:20px"
                                alt="Ver datos técnico asignado" src="img\tecnico_asignado.png"></a>
                        <?php echo $__env->make('incidencias.ver_tecnico_asignado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                    </td>
                    </tr>
                    <?php $contador++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>

        </table>
    </div>
    <?php echo e($incidencias->links('vendor.pagination.bootstrap-4')); ?>

    <div class="row">
        <a href="<?php echo e(route('listadoIncidencias')); ?>"><button type="button" class="btn btn-primary">Ver Tódalas Incidencias</button></a>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/listas_home/incidencias_hoxe.blade.php ENDPATH**/ ?>