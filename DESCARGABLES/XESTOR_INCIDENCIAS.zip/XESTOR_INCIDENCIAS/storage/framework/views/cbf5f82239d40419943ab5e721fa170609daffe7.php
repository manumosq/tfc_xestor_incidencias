

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Incidencias</span></a></li>
                </ol>
            </nav>
        </div>
        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Incidencias</h5>
        </div>
        <form method="GET" action="<?php echo e(route('listadoIncidencias')); ?>">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="cod_inc">Código Incidencia:</label>
                        <input type="text" class="form-control form-control-sm" id="cod_inc" name="cod_inc"
                            placeholder="Código Incidencia" onkeyup="javascript:this.value=this.value.toUpperCase();">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="cod_inc_cliente">Código Incidencia Cliente:</label>
                        <input type="text" class="form-control form-control-sm" id="cod_inc_cliente" name="cod_inc_cliente"
                            placeholder="Código Incidencia Cliente" onkeyup="javascript:this.value=this.value.toUpperCase();">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="tecnico">Técnico Asignado:</label>
                        <select class="form-control form-control-sm" id="tecnico_id" name="tecnico_id"
                            placeholder="Técnico Asignado">
                            <option value="0">Seleccionar Técnico</option>
                            <?php $__currentLoopData = $tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tecnico->id); ?>"><?php echo e($tecnico->nome); ?> <?php echo e($tecnico->primeiro_apelido); ?>

                                    <?php echo e($tecnico->segundo_apelido); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="provincia">Provincia:</label>
                        <select class="form-control form-control-sm" id="provincia" name="provincia_id"
                            placeholder="Provincia">
                            <option value="0">Seleccionar Provincia</option>
                            <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($provincia->id); ?>"><?php echo e($provincia->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="estado">Estado:</label>
                        <select class="form-control form-control-sm" id="estado_actual" name="estado_actual"
                            placeholder="Estado">
                            <option value="0">Seleccionar Estado</option>
                            <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="proxecto">Proxecto:</label>
                        <select class="form-control form-control-sm" id="proxecto_id" name="proxecto_id"
                            placeholder="Proxecto">
                            <option value="0">Seleccionar Proxecto</option>
                            <?php $__currentLoopData = $proxectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proxecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($proxecto->id); ?>"><?php echo e($proxecto->nom_proxecto); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Incidencia" src="img\buscar.png"> Buscar Incidencia
                    </button>

                    <a href="<?php echo e(route('listadoIncidencias')); ?>"><button class="btn btn-primary">Ver Todas</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS-->
        <div class="row">
            <h5>Incidencias Rexistradas</h5>
        </div>

        <div class="row justify-content-center">
            <?php if(session('mensaxe')): ?>
                <div class="alert alert-success col-md-12" id="aviso">
                    <?php echo e(session('mensaxe')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>

                            <th class="table-primary">INC</th>
                            <th class="table-primary">INC Cliente</th>
                            <th class="table-primary">Proxecto</th>
                            <th class="table-primary">Nome Incidencia</th>
                            <th class="table-primary">Data Petición</th>
                            <th class="table-primary text-center">Data Planificación</th>
                            <th class="table-primary text-center">Estado</th>
                            <th class="table-primary text-center" colspan="4">Accións</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($incidencias->count()==0): ?> <td colspan="10">Non se atoparon incidencias.</td>
                        <?php else: ?>

                            <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                            <td><?php echo e($incidencia->cod_inc); ?></td>
                            <td><?php echo e($incidencia->cod_inc_cliente); ?></td>
                            <td><?php echo e($incidencia->proxectos->nom_proxecto); ?></td>
                            <td><?php echo e($incidencia->nom_incidencia); ?></td>
                            <td><?php echo e($incidencia->data_peticion_formato); ?></td>
                            <td class="text-center">
                                <?php if($incidencia->data_planificada == null): ?> PENDENTE
                                <?php else: ?> <?php echo e($incidencia->data_planificada_formato); ?>

                                <?php endif; ?>
                            </td>
                            <td class="text-center
                            <?php if($incidencia->estado_actual == 2): ?> table-planificada text-center
                            <?php elseif($incidencia->estado_actual == 3): ?> table-enproceso text-center
                            <?php elseif($incidencia->estado_actual == 4): ?> table-finalizada text-center
                            <?php elseif($incidencia->estado_actual == 5): ?> table-cancelada text-center                        
                            <?php endif; ?>
                            "
                            ><?php echo e($incidencia->estados->last()->nome); ?></td>


                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#ver<?php echo e($contador); ?>" title="Ver Incidencia"><img
                                        style="width:25px" alt="Ver Incidencia" src="img\ver.png"></a>
                                <?php echo $__env->make('incidencias.ver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                            </td>
                            <td style="max-width: 30px;">
                                <?php if($incidencia->estado_actual < 3): ?>
                                <a href=# data-toggle="modal" data-target="#modificar<?php echo e($contador); ?>"
                                    title="Modificar Datos Incidencia"><img style="width:20px" alt="Modificar Datos Incidencia"
                                        src="img\editar.png"></a>
                                <?php echo $__env->make('incidencias.modificar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php else: ?>
                                    <img style="width:20px" alt="Esta incidencia non se pode modificar" title = "Esta incidencia non se pode modificar" src="img\editar_cancelada.png">
                                <?php endif; ?>

                            </td>
                            <td style="max-width: 30px;">
                                <?php if($incidencia->estado_actual < 3): ?>
                                <a href="#" data-toggle="modal" data-target="#planificar<?php echo e($contador); ?>"
                                    title="Planificar / Modificar Planificación Incidencia"><img style="width:20px"
                                        alt="Planificar / Modificar Planificación Incidencia" src="img\planificar.png"></a>
                                <?php echo $__env->make('incidencias.planificar_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php else: ?>
                                    <img style="width:20px" alt="Esta incidencia non se pode modificar" title = "Esta incidencia non se pode modificar" src="img\planificar_cancelada.png">
                                <?php endif; ?>
                            </td>
                            <td style="max-width: 30px;">
                                <?php if($incidencia->estado_actual < 3): ?>
                                <a href="#" data-toggle="modal" data-target="#cancelar_incidencia<?php echo e($contador); ?>"
                                    title="Cancelar Incidencia"><img style="width:15px"
                                        alt="Cancelar Incidencia" src="img\eliminar.png"></a>
                                <?php echo $__env->make('incidencias.cancelar_incidencia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php else: ?>
                                    <img style="width:15px" alt="Esta incidencia non se pode cancelar" title = "Esta incidencia non se pode cancelar" src="img\eliminar.png">
                                <?php endif; ?>
                            </td>
                            </tr>
                            <?php $contador++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>
            <?php echo e($incidencias->links('vendor.pagination.bootstrap-4')); ?>


        </div>
        <div class="row">
            <a href="<?php echo e(route('formRexistroIncidencia')); ?>"><button type="button" class="btn btn-primary">Rexistrar Nova
                    Incidencia</button></a>
        </div>
        <?php if($errors->any()): ?>
        <div class="row justify-content-start alert alert-danger col-md-6">
            <p>Non se puido completar a acción debido ao/-s seguinte/-s erro/-s:</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <p>Por favor, volva tentalo solventando os erros anteriores.</p>
        </div>
        <?php endif; ?>
    </div>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/incidencias/listar.blade.php ENDPATH**/ ?>