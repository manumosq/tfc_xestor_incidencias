<!--VENTANA MODAL CREAR PROXECTO-->

<div class="modal fade" id="crear">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">NOVO PROXECTO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <form method="POST" id="rexistrar_proxecto" action="<?php echo e(route('crearProxecto')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <h5>Datos Proxecto:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="nom_proxecto">Nome Proxecto:</label>
                                <input type="text" class="form-control form-control-sm" id="nom_proxecto"
                                    name="nom_proxecto" value="<?php echo e(old('nom_proxecto')); ?>" placeholder="Nome Proxecto">
                            </div>
                            <div class="col-md-6">
                                <label for="Cliente">Cliente:</label>
                                <select class="form-control form-control-sm" id="cliente_id" name="cliente_id">
                                    <option value="0">Cliente</option>
                                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cliente->id); ?>" <?php if($cliente->id == old('cliente_id')): ?> selected <?php endif; ?>><?php echo e($cliente->nom_comercial); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div> 
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Estado:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="data_inicio">Data Inicio:</label>
                                <input type="date" class="form-control form-control-sm" id="data_inicio" value="<?php echo e(old('data_inicio')); ?>" name="data_inicio">
                            </div>
                            <div class="col-md-6">
                                <label for="data_fin">Data Fin:</label>
                                <input type="date" class="form-control form-control-sm" id="data_fin" value="<?php echo e(old('data_fin')); ?>" name="data_fin" >
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-primary">Crear Proxecto</button>
                            &nbsp;&nbsp;&nbsp;
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/proxectos/crear.blade.php ENDPATH**/ ?>