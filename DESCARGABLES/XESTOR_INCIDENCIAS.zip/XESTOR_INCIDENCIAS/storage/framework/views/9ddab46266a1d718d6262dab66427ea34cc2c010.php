

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Peticionarios</span></a></li>
                </ol>
            </nav>
        </div>
        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Peticionarios</h5>
        </div>

        <form method="GET" action="<?php echo e(route('listadoPeticionarios')); ?>">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="nome">Nome Peticionario:</label>
                        <input type="text" class="form-control form-control-sm" id="nome" name="nome"
                            placeholder="Nome Peticionario">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="primeiro_apelido">Primeiro Apelido:</label>
                        <input type="text" class="form-control form-control-sm" id="primeiro_apelido" name="primeiro_apelido"
                            placeholder="Primeiro Apelido">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="Segundo Apelido">Segundo Apelido:</label>
                        <input type="text" class="form-control form-control-sm" id="segundo_apelido" name="segundo_apelido"
                            placeholder="Segundo Apelido">
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Proxecto" src="img\buscar.png"> Buscar Peticionario
                    </button>

                    <a href="<?php echo e(route('listadoPeticionarios')); ?>"><button class="btn btn-primary">Ver Todos</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS-->
        <div class="row">
            <h5>Peticionarios Rexistrados</h5>
        </div>

        <div class="row justify-content-center">
            <?php if(session('mensaxe')): ?>
                <div class="alert alert-success col-md-12">
                    <?php echo e(session('mensaxe')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="table-primary">Nome</th>
                            <th class="table-primary">Primeiro Apelido</th>
                            <th class="table-primary">Segundo Apelido</th>
                            <th class="table-primary">Email</th>
                            <th class="table-primary">Teléfono</th>
                            <th class="table-primary text-center" colspan="3">Accións</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($peticionarios->count()==0): ?> <td colspan="10">Non se atoparon peticionarios.</td>
                        <?php else: ?>
                            <?php $__currentLoopData = $peticionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peticionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($peticionario->nome); ?></td>
                            <td><?php echo e($peticionario->primeiro_apelido); ?></td>
                            <td><?php echo e($peticionario->segundo_apelido); ?></td>
                            <td><?php echo e($peticionario->email); ?></td>
                            <td><?php echo e($peticionario->telefono); ?></td>
                            <td style="max-width: 30px;">
                                <a href="#" data-toggle="modal" data-target="#ver<?php echo e($contador); ?>"
                                    title="Ver Peticionario"><img style="width:25px" alt="Ver Peticionario"
                                        src="img\ver.png"></a>
                                <?php echo $__env->make('peticionarios.ver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#modificar<?php echo e($contador); ?>"
                                    title="Modificar Peticionario"><img style="width:20px" alt="Modificar Peticionario"
                                        src="img\editar.png"></a>
                                        <?php echo $__env->make('peticionarios.modificar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                            <td style="max-width: 30px;">
                                <a href="#" data-toggle="modal" data-target="#eliminar<?php echo e($contador); ?>"
                                    title="Eliminar Peticionario"><img style="width:15px" alt="Eliminar Peticionario"
                                        src="img\eliminar.png"></a>
                                        <?php echo $__env->make('peticionarios.eliminar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                            </td>
                            </tr>
                            <?php $contador++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>
            <?php echo e($peticionarios->links('vendor.pagination.bootstrap-4')); ?>


        </div>
        <div class="row">
            <a href="#" data-toggle="modal" data-target="#crear" title="Crear Peticionarios">
                <button type="button" class="btn btn-primary">Engadir Novo
                    peticionario</button></a>
            <?php echo $__env->make('peticionarios.crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php if($errors->any()): ?>
        <div class="row justify-content-start alert alert-danger col-md-6">
            <p>Non se puido completar a acción debido ao/-s seguinte/-s erro/-s:</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <p>Por favor, volva tentalo solventando os erros anteriores.</p>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/peticionarios/listar.blade.php ENDPATH**/ ?>