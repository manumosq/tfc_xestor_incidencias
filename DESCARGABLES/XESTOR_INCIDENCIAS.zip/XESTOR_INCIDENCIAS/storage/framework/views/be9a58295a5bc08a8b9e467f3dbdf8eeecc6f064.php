

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Proxectos</span></a></li>
                </ol>
            </nav>
        </div>
        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Proxectos</h5>
        </div>

        <form method="GET" action="<?php echo e(route('listadoProxectos')); ?>">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="nom_proxecto">Nome Proxecto:</label>
                        <input type="text" class="form-control form-control-sm" id="nom_proxecto" name="nom_proxecto"
                            placeholder="Nome Proxecto">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="cliente">Cliente:</label>
                        <select class="form-control form-control-sm" id="cliente" name="cliente_id">
                            <option value="0">Seleccionar Cliente</option>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nom_comercial); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="Estado">Estado:</label>
                        <select class="form-control form-control-sm" id="estado" name="estado">
                            <option value="0">ESTADO</option>
                            <option value="1">EN PROCESO</option>
                            <option value="2">FINALIZADO</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Proxecto" src="img\buscar.png"> Buscar Proxecto
                    </button>

                    <a href="<?php echo e(route('listadoClientes')); ?>"><button class="btn btn-primary">Ver Todos</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS--> 
        <div class="row">
            <h5>Proxectos Rexistrados</h5>
        </div>

        <div class="row justify-content-center">
            <?php if(session('mensaxe')): ?>
                <div class="alert alert-success col-md-12">
                    <?php echo e(session('mensaxe')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="table-primary">Código Proxecto</th>
                            <th class="table-primary">Nome Proxecto</th>
                            <th class="table-primary">Cliente</th>
                            <th class="table-primary">Data Inicio</th>
                            <th class="table-primary">Data Fin</th>
                            <th class="table-primary text-center" colspan="3">Accións</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($proxectos->count()==0): ?> <td colspan="10">Non se atoparon proxectos.</td>
                        <?php else: ?>
                            <?php $__currentLoopData = $proxectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proxecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($proxecto->cod_proxecto); ?></td>
                            <td><?php echo e($proxecto->nom_proxecto); ?></td>
                            <td><?php echo e($proxecto->clientes->nom_comercial); ?></td>
                            <td><?php echo e($proxecto->data_inicio_formato); ?></td>
                            <td>
                            <?php if($proxecto->data_fin == null): ?> EN PROCESO <?php else: ?>
                                    <?php echo e($proxecto->data_fin_formato); ?> <?php endif; ?>
                            </td>
                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#ver<?php echo e($contador); ?>" title="Ver Proxecto"><img
                                        style="width:25px" alt="Ver Cliente" src="img\ver.png"></a>
                                <?php echo $__env->make('proxectos.ver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                            <td style="max-width: 30px;">
                                <a href=# data-toggle="modal" data-target="#modificar<?php echo e($contador); ?>"
                                    title="Modificar Proxecto"><img style="width:20px" alt="Editar Cliente"
                                        src="img\editar.png"></a>
                                <?php echo $__env->make('proxectos.modificar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                            </td>
                            <td style="max-width: 30px;">
                                <a href="#" data-toggle="modal" data-target="#eliminar<?php echo e($contador); ?>"
                                    title="Eliminar Proxecto"><img style="width:15px" alt="Eliminar Cliente"
                                        src="img\eliminar.png"></a>
                                <?php echo $__env->make('proxectos.eliminar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                            </tr>
                            <?php $contador++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>
            <?php echo e($proxectos->links('vendor.pagination.bootstrap-4')); ?>


        </div>
        <div class="row">
            <a href="#" data-toggle="modal" data-target="#crear" title="Crear Proxecto">
                <button type="button" class="btn btn-primary">Engadir Novo
                    Proxecto</button></a>
                <?php echo $__env->make('proxectos.crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php if($errors->any()): ?>
        <div class="row justify-content-start alert alert-danger col-md-6">
            <p>Non se puido completar a acción debido ao/-s seguinte/-s erro/-s:</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <p>Por favor, volva tentalo solventando os erros anteriores.</p>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/proxectos/listar.blade.php ENDPATH**/ ?>