<?php $__env->startSection('content'); ?>

    <div class="container">
        <p>Hola Hola Caraola</p>
    </div>

        
<thought-component></thought-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/welcome.blade.php ENDPATH**/ ?>