

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Incidencias</span></a></li>
                </ol>
            </nav>
        </div>
        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Incidencias</h5>
        </div>
        <form method="GET" action="<?php echo e(route('listadoIncidencias')); ?>">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="cod_inc">Código Incidencia:</label>
                        <input type="text" class="form-control form-control-sm" id="cod_inc" name="cod_inc"
                            placeholder="Código Incidencia">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="cod_inc_cliente">Código Incidencia Cliente:</label>
                        <input type="text" class="form-control form-control-sm" id="cod_inc_cliente" name="cod_inc_cliente"
                            placeholder="Código Incidencia Cliente">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="tecnico">Técnico Asignado:</label>
                        <select class="form-control form-control-sm" id="tecnico_id" name="tecnico_id"
                            placeholder="Técnico Asignado">
                            <option value="0">Seleccionar Técnico</option>
                            <?php $__currentLoopData = $tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tecnico->id); ?>"><?php echo e($tecnico->nome); ?> <?php echo e($tecnico->primeiro_apelido); ?> <?php echo e($tecnico->segundo_apelido); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="provincia">Provincia:</label>
                        <select class="form-control form-control-sm" id="provincia" name="provincia_id"
                            placeholder="Provincia">
                            <option value="0">Seleccionar Provincia</option>
                            <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($provincia->id); ?>"><?php echo e($provincia->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="estado">Estado:</label>
                        <select class="form-control form-control-sm" id="estado_actual" name="estado_actual"
                            placeholder="Estado">
                            <option value="0">Seleccionar Estado</option>
                            <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Incidencia" src="img\buscar.png"> Buscar Incidencia
                    </button>

                    <a href="<?php echo e(route('listadoIncidencias')); ?>"><button class="btn btn-primary">Ver Todas</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS-->
        <div class="row">
            <h5>Resultados atopados</h5>
        </div>

        <div class="row justify-content-center">
            <?php if(session('mensaxe')): ?>
                <div class="alert alert-success col-md-12" id="aviso">
                    <?php echo e(session('mensaxe')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>

                            <th class="table-primary">INC</th>
                            <th class="table-primary">INC Cliente</th>
                            <th class="table-primary">Técnico Asignado</th>
                            <th class="table-primary">Provincia</th>
                            <th class="table-primary">Estado</th>
                            <th class="table-primary text-center" colspan="3">Accións</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr  data-id="<?php echo e($incidencia->id); ?>" <?php if($contador % 2 != 0): ?> class="table-light" <?php endif; ?>>
                        <td><?php echo e($incidencia->cod_inc); ?></td>
                        <td><?php echo e($incidencia->cod_inc_cliente); ?></td>                      
                        <td><?php if($incidencia->tecnico_id == null): ?> PENDENTE ASIGNAR 
                            <?php else: ?> <?php echo e($incidencia->users->nome); ?> <?php echo e($incidencia->users->primeiro_apelido); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($incidencia->provincias->nome); ?></td>
                        <td><?php echo e($incidencia->estados->last()->nome); ?></td>
                        <td style="max-width: 30px;">
                            <a href=# data-toggle="modal" data-target="#ver<?php echo e($contador); ?>"
                            title="Ver Cliente"><img style="width:25px" alt="Ver Cliente"
                                src="img\ver.png"></a>
                                <?php echo $__env->make('incidencias.crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                            
                        </td>
                        <td style="max-width: 30px;">
                            <a href=# data-toggle="modal" data-target="#modificar<?php echo e($contador); ?>"
                                title="Modificar Cliente"><img style="width:20px" alt="Editar Cliente"
                                    src="img\editar.png"></a>
                                    <?php echo $__env->make('incidencias.crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                   
                        </td>
                        <td style="max-width: 30px;">
                        <a href="#" data-toggle="modal" data-target="#planificar<?php echo e($contador); ?>" 
                                title="Planificar Incidencia"><img style="width:24px" alt="Planificar Incidencia"
                                    src="img\planificar.png"></a>
                                    <?php echo $__env->make('incidencias.planificar_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                        </tr>
                        <?php $contador++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
            <?php echo e($incidencias->links('vendor.pagination.bootstrap-4')); ?>


        </div>
        <div class="row">
            <a href="<?php echo e(route('formRexistroIncidencia')); ?>"><button type="button" class="btn btn-primary">Rexistrar Nova
                    Incidencia</button></a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/incidencias/listar.blade.php ENDPATH**/ ?>