<!--VENTANA MODAL VER PROXECTO-->

<div class="modal fade" id="ver<?php echo e($contador); ?>">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">VER PETICIONARIO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row">
                        <h5>Datos Persoais:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <span class="text-difuminado">Nome:</span><br/><?php echo e($peticionario->nome); ?>

                        </div>
                        <div class="col-md-4">
                            <span class="text-difuminado">Primeiro Apelido:</span><br/><?php echo e($peticionario->primeiro_apelido); ?>

                        </div>
                        <div class="col-md-4">
                            <span class="text-difuminado">Segundo Apelido:</span><br/><?php echo e($peticionario->segundo_apelido); ?>

                        </div>
                    </div>
                    <div class="row">
                        &nbsp;
                    </div>
                    <div class="row">
                        <h5>Datos de Contacto:</h5>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <span class="text-difuminado">Teléfono:</span><br/><?php echo e($peticionario->telefono); ?>

                        </div>
                        <div class="col-md-6">
                            <span class="text-difuminado">Email: </span><br/><?php echo e($peticionario->email); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar Ventana</button>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/peticionarios/ver.blade.php ENDPATH**/ ?>