<!--VENTANA MODAL PLANIFICAR INCIDENCIA-->

<div class="modal fade" id="planificar<?php echo e($contador); ?>">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">PLANIFICANDO INCIDENCIA - <?php echo e($incidencia->cod_inc); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                <form method="POST" id = "planificar_incidencia<?php echo e($contador); ?>" class = "planificar_incidencia" action="<?php echo e(route('planificarIncidencia')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($incidencia->id); ?>">
                        <input type="hidden" name="data_peticion" value="<?php echo e($incidencia->data_peticion); ?>">
                        <div class="row">
                            <h5>Datos Incidencia:</h5>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <label for="nom_incidencia">Nome Incidencia:</label>
                                <input type="text" class="form-control form-control-sm" id="nom_comercial"
                                    name="nom_comercial" value="<?php echo e($incidencia->nom_incidencia); ?>"
                                    placeholder="Nome Comercial" readonly>
                            </div>
                            <div class="col-md-4">
                                <label for="nom_proxecto">Proxecto:</label>
                                <input type="text" class="form-control form-control-sm" id="nom_proxecto"
                                    name="nom_proxecto" value="<?php echo e($incidencia->proxectos->nom_proxecto); ?>"
                                    placeholder="Nome Proxecto" readonly>
                            </div>
                            <div class="col-md-4">
                                <label for="provincia">Provincia:</label>
                                <input type="text" class="form-control form-control-sm" id="provincia" name="provincia"
                                    value="<?php echo e($incidencia->provincias->nome); ?>" placeholder="Provincia" readonly>
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Planificación:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="data_planificada">Data Planificación:</label>
                                <input type="text" class="form-control form-control-sm" id="data_planificada"
                                    name="data_planificada" value="<?php if($incidencia->data_planificada == null): ?><?php else: ?> <?php echo e($incidencia->data_planificada_formato); ?> <?php endif; ?>" placeholder="DD/MM/AAAA HH:MM">

                                    
                            </div>
                            <div class="col-md-6">
                                <label for="tecnico_id">Técnico Asignado:</label>
                                <select class="form-control form-control-sm" id="tecnico_id"
                                    name="tecnico_id" placeholder="Técnico Asignado">
                                    <?php if($incidencia->tecnico_id != null): ?>
                                        <option value="<?php echo e($incidencia->users->id); ?>"><?php echo e($incidencia->users->nome); ?> <?php echo e($incidencia->users->primeiro_apelido); ?> <?php echo e($incidencia->users->segundo_apelido); ?></option>
                                    <?php else: ?>
                                    <option value="0">Seleccionar Técnico</option>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tecnico->id); ?>"><?php echo e($tecnico->nome); ?>

                                            <?php echo e($tecnico->primeiro_apelido); ?> <?php echo e($tecnico->segundo_apelido); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-primary">Planificar Incidencia</button>

                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/incidencias/planificar_modal.blade.php ENDPATH**/ ?>