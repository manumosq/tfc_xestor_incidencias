

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Técnicos</span></a></li>
                </ol>
            </nav>
        </div>
        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Técnicos</h5>
        </div>

        <form method="GET" action="<?php echo e(route('listadoTecnicos')); ?>">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="nome">Nome Técnico:</label>
                        <input type="text" class="form-control form-control-sm" id="nome" name="nome"
                            placeholder="Nome Tecnico">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="primeiro_apelido">Primeiro Apelido:</label>
                        <input type="text" class="form-control form-control-sm" id="primeiro_apelido" name="primeiro_apelido"
                            placeholder="Primeiro Apelido">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="Segundo Apelido">Segundo Apelido:</label>
                        <input type="text" class="form-control form-control-sm" id="segundo_apelido" name="segundo_apelido"
                            placeholder="Segundo Apelido">
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Proxecto" src="img\buscar.png"> Buscar Técnico
                    </button>

                    <a href="<?php echo e(route('listadoTecnicos')); ?>"><button class="btn btn-primary">Ver Todos</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS-->
        <div class="row">
            <h5>Resultados atopados</h5>
        </div>

        <div class="row justify-content-center">
            <?php if(session('mensaxe')): ?>
                <div class="alert alert-success col-md-12">
                    <?php echo e(session('mensaxe')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="table-primary">Código Técnico</th>
                            <th class="table-primary">Nome</th>
                            <th class="table-primary">Primeiro Apelido</th>
                            <th class="table-primary">Segundo Apelido</th>
                            <th class="table-primary">Email</th>
                            <th class="table-primary">Teléfono</th>
                            <th class="table-primary text-center" colspan="4">Accións</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr <?php if($contador % 2 != 0): ?> class="table-light"
                        <?php endif; ?>>
                        <td><?php echo e($tecnico->cod_tecnico); ?></td>
                        <td><?php echo e($tecnico->nome); ?></td>
                        <td><?php echo e($tecnico->primeiro_apelido); ?></td>
                        <td><?php echo e($tecnico->segundo_apelido); ?></td>
                        <td><?php echo e($tecnico->email); ?></td>
                        <td><?php echo e($tecnico->telefono); ?></td>
                        <td style="max-width: 30px;">
                            <a href="#" data-toggle="modal" data-target="#ver<?php echo e($contador); ?>"
                                title="Ver Técnico"><img style="width:25px" alt="Ver Técnico"
                                    src="img\ver.png"></a>
                            <?php echo $__env->make('tecnicos.ver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                        <td style="max-width: 30px;">
                            <a href=# data-toggle="modal" data-target="#modificar<?php echo e($contador); ?>"
                                title="Modificar Técnico"><img style="width:20px" alt="Modificar Técnico"
                                    src="img\editar.png"></a>
                                    <?php echo $__env->make('tecnicos.modificar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                        <td style="max-width: 30px;">
                            <a href="#" data-toggle="modal" data-target="#verIncidencias<?php echo e($contador); ?>"
                                title="Ver Incidencias Tecnico"><img style="width:20px" alt="Ver Incidencias Técnico"
                                    src="img\incidencias.png"></a>
      
                        </td>
                        <td style="max-width: 30px;">
                            <a href="#" data-toggle="modal" data-target="#eliminar<?php echo e($contador); ?>"
                                title="Eliminar Técnico"><img style="width:15px" alt="Eliminar Técnico"
                                    src="img\eliminar.png"></a>
                                    <?php echo $__env->make('tecnicos.eliminar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                        </td>
                        </tr>
                        <?php $contador++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
            <?php echo e($tecnicos->links('vendor.pagination.bootstrap-4')); ?>


        </div>
        <div class="row">
            <a href="#" data-toggle="modal" data-target="#crear" title="Crear Técnicos">
                <button type="button" class="btn btn-primary">Engadir Novo
                    Técnico</button></a>
                <?php echo $__env->make('tecnicos.crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/tecnicos/listar.blade.php ENDPATH**/ ?>