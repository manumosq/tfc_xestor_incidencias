<!--VENTANA MODAL CANCELAR INCIDENCIA-->

<div class="modal fade" id="cancelar_incidencia<?php echo e($contador); ?>">
    <div class="modal-dialog modal-md modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title">CANCELACIÓN DE INCIDENCIA - <?php echo e($incidencia->cod_inc); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <div class="row justify-content-center">
                <h6 class="text-center">Cancelando a incidencia <b style="text-decoration: underline"><?php echo e($incidencia->cod_inc); ?> <?php echo e($incidencia->nom_incidencia); ?></b></h6>
                    <h6 class="text-center">Esta operación non se poderá desfacer</h6>
                <h6 class="text-center">¿Está seguro de que quere continuar?</h6>
                <p>&nbsp;</p>
                    </div>
                    <form method="POST" action="<?php echo e(route('cancelarIncidencia')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($incidencia->id); ?>">
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-danger">Cancelar Incidencia</button>
                            &nbsp;&nbsp;&nbsp;
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/incidencias/cancelar_incidencia.blade.php ENDPATH**/ ?>