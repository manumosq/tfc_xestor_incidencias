

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="#"><span>Clientes</span></a></li>
                </ol>
            </nav>
        </div>
        <!--Buscador-->
        <div class="row">
            <h5>Buscador de Clientes</h5>
        </div>
        <form method="GET" action="<?php echo e(route('listadoClientes')); ?>">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="nom_comercial">Nome Comercial:</label>
                        <input type="text" class="form-control form-control-sm" id="nom_comercial" name="nom_comercial"
                            placeholder="Nome Comercial">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="text" class="form-control form-control-sm" id="email" name="email" placeholder="Email">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="provincia">Provincia:</label>
                        <select class="form-control form-control-sm" id="provincia" name="provincia_id"
                            placeholder="Provincia">
                            <option value="0">Seleccionar Provincia</option>
                            <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($provincia->id); ?>"><?php echo e($provincia->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <img style="width: 18px" alt="Buscar Cliente" src="img\buscar.png"> Buscar Cliente
                    </button>

                    <a href="<?php echo e(route('listadoClientes')); ?>"><button class="btn btn-primary">Ver Todos</button></a>
                </div>
            </div>
        </form>

        <!--TÁBOA DE RESULTADOS-->
        <div class="row">
            <h5>Resultados atopados</h5>
        </div>

        <div class="row justify-content-center">
            <?php if(session('mensaxe')): ?>
                <div class="alert alert-success col-md-12" id="aviso">
                    <?php echo e(session('mensaxe')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>

                            <th class="table-primary">Código Cliente</th>
                            <th class="table-primary">Nome Comercial</th>
                            <th class="table-primary">Teléfono</th>
                            <th class="table-primary">Email</th>
                            <th class="table-primary text-center" colspan="3">Accións</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr  data-id="<?php echo e($cliente->id); ?>" <?php if($contador % 2 != 0): ?> class="table-light" <?php endif; ?>>
                        <td><?php echo e($cliente->cod_cliente); ?></td>
                        <td><?php echo e($cliente->nom_comercial); ?></td>
                        <td><?php echo e($cliente->telefono); ?></td>
                        <td><?php echo e($cliente->email); ?></td>
                        <td style="max-width: 30px;">
                            <a href=# data-toggle="modal" data-target="#ver<?php echo e($contador); ?>"
                            title="Ver Cliente"><img style="width:25px" alt="Ver Cliente"
                                src="img\ver.png"></a>
                                <?php echo $__env->make('clientes.ver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                            
                        </td>
                        <td style="max-width: 30px;">
                            <a href=# data-toggle="modal" data-target="#modificar<?php echo e($contador); ?>"
                                title="Modificar Cliente"><img style="width:20px" alt="Editar Cliente"
                                    src="img\editar.png"></a>
                                    <?php echo $__env->make('clientes.modificar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                   
                        </td>
                        <td style="max-width: 30px;">
                        <a href="#" data-toggle="modal" data-target="#eliminar<?php echo e($contador); ?>" data-cliente="<?php echo e($cliente->id); ?>"
                                title="Eliminar Cliente"><img style="width:15px" alt="Eliminar Cliente"
                                    src="img\eliminar.png"></a>
                                    <?php echo $__env->make('clientes.eliminar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                        </tr>
                        <?php $contador++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
            <?php echo e($clientes->links('vendor.pagination.bootstrap-4')); ?>


        </div>
        <div class="row">
            <a href="<?php echo e(route('rexistrarCliente')); ?>"><button type="button" class="btn btn-primary">Rexistrar Novo
                    Cliente</button></a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/clientes/listado.blade.php ENDPATH**/ ?>