

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('listadoIncidencias')); ?>"><span>Incidencias</span></a><img
                            class="ml-md-3 ml-1" src="img/flecha.png " width="20" height="20"></li>
                    <li class="breadcrumb-item"><a href="#"><span>Rexistrar Incidencia</span></a></li>
                </ol>
            </nav>
        </div>
        <div class="row justify-content-left">
            <div class="col">
                <div class="card">
                    <div class="card-header bg-primary text-white">Rexistrar Incidencia</div>
                    <div class="card-body">
                        <div class="col-md-12">
                            <form method="POST" action="<?php echo e(route('rexistrarIncidencia')); ?>" id="rexistro">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <h5>Datos de Incidencia:</h5>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="cod_inc_cliente">Código Incidencia Cliente:</label>
                                        <input type="text"  class="form-control form-control-sm" id="cod_inc_cliente" name="cod_inc_cliente"
                                        value= "<?php echo e(old('cod_inc_cliente')); ?>" placeholder="Código Incidencia Cliente">
                                    </div>
                                    <div class="col-md-3">
                                        <label for="proxecto">Proxecto</label>
                                        <select class="form-control form-control-sm" id="proxecto" name="proxecto_id"
                                                placeholder="Proxecto">
                                                <option value="0">Seleccionar Proxecto</option>
                                                <?php $__currentLoopData = $proxectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proxecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($proxecto->id); ?>" <?php if($proxecto->id == old('proxecto_id')): ?> selected
                                                <?php endif; ?>><?php echo e($proxecto->nom_proxecto); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select> 
                                    </div>
                                    <div class="col-md-3"> 
                                        <label for="peticionario">Peticionario</label>
                                        <select class="form-control form-control-sm" id="peticionario" name="peticionario_id"
                                                placeholder="Peticionario">
                                                <option value="0">Seleccionar Peticionario</option>
                                                <?php $__currentLoopData = $peticionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peticionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($peticionario->id); ?>" <?php if($peticionario->id == old('peticionario_id')): ?> selected
                                                <?php endif; ?>><?php echo e($peticionario->nome); ?> <?php echo e($peticionario->primeiro_apelido); ?> <?php echo e($peticionario->segundo); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>   
                                    </div>
                                    <div class="col-md-3">
                                        <label for="data_peticion">Data da Petición</label>
                                        <input type="datetime-local" class="form-control form-control-sm" id="data_peticion" name="data_peticion"
                                        value= "<?php echo e(old('data_peticion')); ?>" placeholder="Data Petición">
                                    </div>
                                </div>
                                <div class="row">
                                    &nbsp;
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="nom_incidencia">Nome Incidencia</label>
                                        <input type="text" class="form-control form-control-sm" id="nom_incidencia" name="nom_incidencia"
                                        value= "<?php echo e(old('nom_incidencia')); ?>" placeholder="Nome Incidencia">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="descripcion">Descripción Incidencia:</label>
                                        <textarea class="form-control form-control-sm" id="descripcion" name="descripcion" rows="6"></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    &nbsp;
                                </div>
                                <div class="row">
                                    <h5>Datos de Asistencia:</h5>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                    <label for="persoa_contacto">Persoa de Contacto:</label>
                                    <input type="text" class=" form-control form-control-sm" id="persoa_contacto" name="persoa_contacto"
                                    value= "<?php echo e(old('persoa_contacto')); ?>" placeholder="Persoa de Contacto">
                                    </div>
                                    <div class="col-md-6">
                                    <label for="telefono_contacto">Teléfono de Contacto</label>
                                    <input type="tel" class="form-control form-control-sm" id="telefono_contacto" name="telefono_contacto"
                                    value="<?php echo e(old('telefono_contacto')); ?>" placeholder="Teléfono de Contacto">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="direccion_asistencia">Dirección de Asistencia:</label>
                                        <input type="text" class="form-control form-control-sm" id="direccion_asistencia"
                                        name="direccion_asistencia" value="<?php echo e(old('direccion_asistencia')); ?>" placeholder="Dirección de Asistencia">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="cod_postal">Código Postal</label>
                                        <input type="text" class="form-control form-control-sm" id="cod_postal"
                                            name="cod_postal" value="<?php echo e(old('cod_postal')); ?>" placeholder="Código postal">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="Provincia">Provincia</label>
                                        <select class="form-control form-control-sm" id="provincia" name="provincia_id"
                                            placeholder="Provincia">
                                            <option value="0">Seleccionar Provincia</option>
                                            <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($provincia->id); ?>" <?php if($provincia->id == old('provincia_id')): ?> selected
                                            <?php endif; ?>><?php echo e($provincia->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    &nbsp;
                                </div>
                                <div class="row justify-content-center">
                            
                                            <button type="submit" id="rexistrar" name = "rexistrar" value="rexistrar" class="btn btn-primary">Rexistrar Incidencia</button>
                                            <button type="submit" id="rexistrar" name = "rexistrar" value="rexistrar_planificar" class="btn btn-primary">Rexistrar e planificar</button>                                       
                                       
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/incidencias/rexistrar.blade.php ENDPATH**/ ?>