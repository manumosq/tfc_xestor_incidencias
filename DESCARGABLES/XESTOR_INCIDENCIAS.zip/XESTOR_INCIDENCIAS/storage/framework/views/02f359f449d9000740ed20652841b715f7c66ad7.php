<table>
    <thead>
        <tr>
            <th>Código Incidencia</th>
            <th>Provincia Asistencia</th>
            <th>Cliente</th>
            <th>Proxecto</th>
            <th>Técnico Asignado</th>
            <th>Data Petición</th>
            <th>Data Planificada</th>
            <th>Data Asistencia</th>
            <th>Data Finalizada</th>
            <th>Estado</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($incidencia->cod_inc); ?></td>
            <td><?php echo e($incidencia->provincias->nome); ?></td>
            <td><?php echo e($incidencia->proxectos->clientes->nom_comercial); ?></td>
            <td><?php echo e($incidencia->proxectos->nom_proxecto); ?></td>
            
            <td>
                <?php if($incidencia->tecnico_id == null): ?> PENDENTE ASIGNAR 
                <?php else: ?> <?php echo e($incidencia->users->nome); ?> <?php echo e($incidencia->users->primeiro_apelido); ?> <?php echo e($incidencia->users->segundo_apelido); ?>

                <?php endif; ?>
            </td>
            <td><?php echo e($incidencia->data_peticion_formato); ?></td>
            <td>
                <?php if($incidencia->data_planificada == null): ?> PENDENTE
                <?php else: ?> <?php echo e($incidencia->data_planificada_formato); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($incidencia->data_asistencia == null): ?> PENDENTE
                <?php else: ?> <?php echo e($incidencia->data_asistencia_formato); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($incidencia->data_finalizacion == null): ?> PENDENTE
                <?php else: ?> <?php echo e($incidencia->data_finalizacion_formato); ?>

                <?php endif; ?>
            </td>
            <td><?php echo e($incidencia->estados->last()->nome); ?></td>
        </tr>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/exports/incidenciasExport.blade.php ENDPATH**/ ?>