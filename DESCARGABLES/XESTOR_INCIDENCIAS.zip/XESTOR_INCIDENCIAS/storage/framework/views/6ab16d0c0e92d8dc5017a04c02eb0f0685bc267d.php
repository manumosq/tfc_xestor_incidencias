<!--TÁBOA DE RESULTADOS-->
<div class="row justify-content-center">
    <?php if(session('mensaxe')): ?>
        <div class="alert alert-success col-md-12" id="aviso">
            <?php echo e(session('mensaxe')); ?>

        </div>
    <?php endif; ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>

                    <th class="table-primary">INC</th>
                    <th class="table-primary">INC Cliente</th>
                    <th class="table-primary">Proxecto</th>
                    <th class="table-primary">Peticionario</th>
                    <th class="table-primary">Técnico Asignado</th>
                    <th class="table-primary">Provincia</th>
                    <th class="table-primary">Estado</th>
                    <th class="table-primary text-center" colspan="3">Accións</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr data-id="<?php echo e($incidencia->id); ?>" <?php if($contador % 2 != 0): ?> class="table-light"
                <?php endif; ?>>
                <td><?php echo e($incidencia->cod_inc); ?></td>
                <td><?php echo e($incidencia->cod_inc_cliente); ?></td>
                <td><?php echo e($incidencia->proxectos->nom_proxecto); ?></td>
                <td><?php echo e($incidencia->peticionarios->nome); ?> <?php echo e($incidencia->peticionarios->primeiro_apelido); ?></td>
                <td>
                    <?php if($incidencia->tecnico_id == null): ?> PENDENTE ASIGNAR
                    <?php else: ?> <?php echo e($incidencia->users->nome); ?> <?php echo e($incidencia->users->primeiro_apelido); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($incidencia->provincias->nome); ?></td>
                <td><?php echo e($incidencia->estados->last()->nome); ?></td>
                <td style="max-width: 30px;">
                    <a href=# data-toggle="modal" data-target="#ver<?php echo e($contador); ?>" title="Ver Incidencia"><img
                        style="width:25px" alt="Ver Cliente" src="img\ver.png"></a>
                <?php echo $__env->make('incidencias.ver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                </td>
                <td style="max-width: 30px;">
                    <a href=# data-toggle="modal" data-target="#modificar<?php echo e($contador); ?>"
                        title="Modificar Cliente"><img style="width:20px" alt="Editar Cliente"
                            src="img\editar.png"></a>
                    <?php echo $__env->make('incidencias.crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </td>
                <td style="max-width: 30px;">
                    <a href="#" data-toggle="modal" data-target="#planificar<?php echo e($contador); ?>"
                        title="Planificar Incidencia"><img style="width:24px" alt="Planificar Incidencia"
                            src="img\planificar.png"></a>
                    <?php echo $__env->make('incidencias.planificar_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </td>
                </tr>
                <?php $contador++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
    <?php echo e($incidencias->links('vendor.pagination.bootstrap-4')); ?>

    <div class="row">
        <a href="<?php echo e(route('listadoIncidencias')); ?>"><button type="button" class="btn btn-primary">Ver Tódalas Incidencias</button></a>
    </div>

</div>
<?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/listas_home/incidencias_hoy.blade.php ENDPATH**/ ?>