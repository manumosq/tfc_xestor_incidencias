

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="row justify-content-left">
        <div class="col">
          <div class="card">
            <div class="card-header bg-primary text-white">Rexistrar Cliente</div>
            <div class="card-body">
              <form method="POST" action="<?php echo e(route('novoCliente')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                  <div class="col-md-4">
                    <fieldset>
                      <legend class="col-form-label col-sm-12">Datos Fiscais</legend>
                        
                        <label for="nom_fiscal">Nome Fiscal</label>
                    <input type="text" class="form-control form-control-sm" id="nom_fiscal" name="nom_fiscal" value="<?php echo e(old('nom_fiscal')); ?>" placeholder="Nome Fiscal">
                  
                        <label for="nom_comercial">Nome Comercial</label>
                        <input type="text" class="form-control form-control-sm" id="nom_comercial" name="nom_comercial" value="<?php echo e(old('nom_comercial')); ?>" placeholder="Nome Comercial">
                  
                  
                        <label for="cif">CIF</label>
                        <input type="text" class="form-control form-control-sm" id="cif" name="cif" value="<?php echo e(old('cif')); ?>" placeholder="CIF">
                    </fieldset>
                  </div>

                  <div class="col-md-4">
                    <fieldset>
                      <legend class="col-form-label col-sm-12">Dirección:</legend>

                        <label for="direccion">Dirección</label>
                        <input type="text" class="form-control form-control-sm" id="direccion" name="direccion" value="<?php echo e(old('direccion')); ?>" placeholder="Dirección">

                        <label for="cod_postal">Código Postal</label>
                        <input type="text" class="form-control form-control-sm" id="cod_postal" name="cod_postal" value="<?php echo e(old('cod_postal')); ?>" placeholder="código postal">
                        
                        <label for="Localidad">Localidade</label>
                        <input type="text" class="form-control form-control-sm" id="localidade" name="localidade" value="<?php echo e(old('localidade')); ?>" placeholder="Localidade">                        

                        <label for="Provincia">Provincia</label>
                        <select class="form-control form-control-sm" id="provincia" name="provincia_id" placeholder="Provincia">
                          <option value="0">Seleccionar Provincia</option>
                          <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($provincia->id); ?>" <?php if($provincia->id == old('provincia_id')): ?> selected <?php endif; ?>><?php echo e($provincia->nome); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </fieldset>
                  </div>
                  
                  <div class="col-md-4">
                    <fieldset>
                      <legend class="col-form-label col-sm-12">Contacto:</legend>
                        <label for="Teléfono">Teléfono</label>
                        <input type="tel" class="form-control form-control-sm" id="telefono" name="telefono" value="<?php echo e(old('telefono')); ?>" placeholder="Teléfono">

                        <label for="email">Email</label>
                        <input type="email" class="form-control form-control-sm" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
                    </fieldset>
                  </div>

                </div>

                <div class="row">
                  <div class="col-md-12">
                       <?php if(count($errors)>0): ?>
                       &nbsp;
                       <div class="alert alert-danger">
                         <ul>
                           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <li><?php echo e($error); ?></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </ul>
                       </div>
                       <?php else: ?>
                       &nbsp;
                       <?php endif; ?>
                  </div>
                
                <div class="row">
                  <div class="col-md-12">
                    <button type="submit" class="btn btn-primary">Rexistrar</button>
                  </div>
                  
                </div>
                
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/clientes/rexistro.blade.php ENDPATH**/ ?>