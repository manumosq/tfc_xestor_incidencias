<table>
    <thead>
        <tr>
            <th>Nome</th>
            <th>Primeiro Apelido</th>
            <th>Segundo Apelido</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Rol</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($usuario->nome); ?></td>
            <td><?php echo e($usuario->primeiro_apelido); ?></td>
            <td><?php echo e($usuario->segundo_apelido); ?></td>
            <td><?php echo e($usuario->email); ?></td>
            <td><?php echo e($usuario->telefono); ?></td>
            <td><?php echo e($usuario->rol); ?></td>
        </tr>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/exports/usersExport.blade.php ENDPATH**/ ?>