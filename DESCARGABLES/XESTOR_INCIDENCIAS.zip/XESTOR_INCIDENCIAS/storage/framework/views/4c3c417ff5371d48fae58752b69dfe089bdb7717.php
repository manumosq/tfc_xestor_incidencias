

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="row justify-content-left">
        <div class="col">
          <div class="card">
            <div class="card-header bg-primary text-white">Rexistrar Cliente</div>
            <div class="card-body">
              <form method="POST" action="">
                <div class="row">
                  <div class="col-md-4">
                    <fieldset>
                      <legend class="col-form-label col-sm-12">Datos Fiscais</legend>
                        
                        <label for="nom_fiscal">Nome Fiscal</label>
                        <input type="text" class="form-control form-control-sm" id="nom_fiscal" placeholder="Nome Fiscal">
                  
                        <label for="nom_comercial">Nome Comercial</label>
                        <input type="text" class="form-control form-control-sm" id="nom_comercial" placeholder="Nome Comercial">
                  
                  
                        <label for="cif">CIF</label>
                        <input type="text" class="form-control form-control-sm" id="cif" placeholder="CIF">
                    </fieldset>
                  </div>

                  <div class="col-md-4">
                    <fieldset>
                      <legend class="col-form-label col-sm-12">Dirección:</legend>

                        <label for="direccion">Dirección</label>
                        <input type="text" class="form-control form-control-sm" id="direccion" placeholder="Dirección">

                        <label for="cod_postal">Código Postal</label>
                        <input type="text" class="form-control form-control-sm" id="cod_postal" placeholder="código postal">
                        
                        <label for="Localidad">Localidade</label>
                        <input type="text" class="form-control form-control-sm" id="localidad" placeholder="Localidad">                        

                        <label for="Provincia">Provincia</label>
                        <input type="text" class="form-control form-control-sm" id="provincia" placeholder="Provincia">
                    </fieldset>
                  </div>
                  
                  <div class="col-md-4">
                    <fieldset>
                      <legend class="col-form-label col-sm-12">Contacto:</legend>
                        <label for="Teléfono">Teléfono</label>
                        <input type="tel" class="form-control form-control-sm" id="telefono" placeholder="Teléfono">

                        <label for="email">Email</label>
                        <input type="email" class="form-control form-control-sm" id="email" placeholder="Email">
                    </fieldset>
                  </div>

                </div>

                <div class="row">
                  <div class="col-md-12">
                       &nbsp;
                  </div>
                
                <div class="row">
                  <div class="col-md-12">
                    <button type="submit" class="btn btn-primary">Rexistrar</button>
                  </div>
                  
                </div>
                
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/rexistro_clientes.blade.php ENDPATH**/ ?>