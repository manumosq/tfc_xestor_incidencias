<?php $__env->startSection('content'); ?>
    <div class="container">
    
        <?php if(auth()->user()->rol == 'ADMINISTRADOR'): ?>
            <div class="row">
                <div class="col-md-12">
                
                <h6>INCIDENCIAS PLANIFICADAS HOXE</h6>
                    <div class="card-body">
                        <?php echo $__env->make('listas_home.incidencias_hoxe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                &nbsp;&nbsp;
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-12">
                
                <h5>Incidencias Planificadas <?php echo e(auth()->user()->nome); ?> <?php echo e(auth()->user()->primeiro_apelido); ?> <?php echo e(auth()->user()->segundo_apelido); ?></h5>
                    <div class="card-body">
                        <?php echo $__env->make('listas_home.incidencias_tecnico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\PROYECTO_FINAL_DAW_MMS\a17manuelms\XESTOR_INCIDENCIAS\resources\views/home.blade.php ENDPATH**/ ?>