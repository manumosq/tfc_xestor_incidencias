<!--VENTANA MODAL ACTUALIZAR PROXECTO-->

<div class="modal fade" id="modificar<?php echo e($contador); ?>">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">MODIFICANDO TÉCNICO - <?php echo e($tecnico->cod_tecnico); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container col-md-12">
                    <form method="POST" action="<?php echo e(route('modificarTecnico')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($tecnico->id); ?>">
                        <div class="row">
                            <h5>Datos Persoais:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label for="nome">Nome</label>
                                <input type="text" class="form-control form-control-sm" id="nome"
                                    name="nome" value="<?php echo e($tecnico->nome); ?>">
                            </div>
                            <div class="col-md-4">
                                <label for="primeiro_apelido">Primeiro Apelido</label>
                                <input type="text" class="form-control form-control-sm" id="primeiro_apelido"
                                name="primeiro_apelido" value="<?php echo e($tecnico->primeiro_apelido); ?>">
                            </div>
                            <div class="col-md-4">
                                <label for="segundo_apelido">Segundo Apelido</label>
                                <input type="text" class="form-control form-control-sm" id="segundo_apelido"
                                    name="segundo_apelido" value="<?php echo e($tecnico->segundo_apelido); ?>">
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row">
                            <h5>Datos de Contacto:</h5>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="telefono">Teléfono: </label>
                            <input type="tel" class="form-control form-control-sm" id="telefono" name="telefono" value="<?php echo e($tecnico->telefono); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control form-control-sm" id="email"
                                    name="email" value="<?php echo e($tecnico->email); ?>">
                            </div>
                        </div>
                        <div class="row">
                            &nbsp;
                        </div>
                        <div class="row justify-content-center">
                            <button type="submit" class="btn btn-primary">Modificar Técnico</button>
                            &nbsp;&nbsp;&nbsp;
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/tecnicos/modificar.blade.php ENDPATH**/ ?>