

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!--BREADCRUMB-->
        <div class="row">
            <nav aria-label="breadcrumb" class="first d-md-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><img alt="inicio" src="img/inicio.png"
                                width="20" height="19"></a><img class="ml-md-3 ml-1" src="img/flecha.png " width="20"
                            height="20"> </li>
                    <li class="breadcrumb-item"><a
                            href="<?php echo e(route('listadoIncidencias')); ?>"><span>Incidencias</span></a><img class="ml-md-3 ml-1"
                            src="img/flecha.png " width="20" height="20"></li>
                    <li class="breadcrumb-item"><a href="#"><span>Planificar Incidencia</span></a></li>
                </ol>
            </nav>
        </div>
        <div class="row justify-content-left">
            <div class="col">
                <div class="card">
                    <div class="card-header bg-primary text-white">PLANIFICANDO INCIDENCIA - <?php echo e($incidencias->cod_inc); ?></div>
                    <div class="card-body">
                        <div class="col-md-12">
                            <form method="POST" action="<?php echo e(route('planificarIncidencia')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($incidencias->id); ?>">
                                <div class="row">
                                    <h5>Datos Incidencia:</h5>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="nom_incidencia">Nome Incidencia</label>
                                        <input type="text" class="form-control form-control-sm" id="nom_comercial"
                                            name="nom_comercial" value="<?php echo e($incidencias->nom_incidencia); ?>"
                                            placeholder="Nome Comercial" readonly>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="nom_proxecto">Proxecto</label>
                                        <input type="text" class="form-control form-control-sm" id="nom_proxecto"
                                            name="nom_proxecto" value="<?php echo e($incidencias->proxectos->nom_proxecto); ?>"
                                            placeholder="Nome Proxecto" readonly>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="provincia">Provincia</label>
                                        <input type="text" class="form-control form-control-sm" id="provincia"
                                            name="provincia" value="<?php echo e($incidencias->provincias->nome); ?>"
                                            placeholder="Provincia" readonly>
                                    </div>
                                </div>
                                <div class="row">
                                    &nbsp;
                                </div>
                                <div class="row">
                                    <h5>Planificación:</h5>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="data_planificada">Data Planificación</label>
                                        <input type="datetime-local" class="form-control form-control-sm"
                                            id="data_planificada" name="data_planificada" placeholder="Data Planificación">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="tecnico_id">Técnico Asignado</label>
                                        <select class="form-control form-control-sm" id="tecnico_id"
                                            name="tecnico_id" placeholder="Técnico Asignado">
                                            <option value="0">Seleccionar Técnico</option>
                                            <?php $__currentLoopData = $tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tecnico->id); ?>"><?php echo e($tecnico->nome); ?>

                                                    <?php echo e($tecnico->primeiro_apelido); ?> <?php echo e($tecnico->segundo_apelido); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    &nbsp;
                                </div>
                                <div class="row justify-content-center">
                                    <button type="submit" class="btn btn-primary">Planificar Incidencia</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestion-incidencias\resources\views/incidencias/planificar.blade.php ENDPATH**/ ?>